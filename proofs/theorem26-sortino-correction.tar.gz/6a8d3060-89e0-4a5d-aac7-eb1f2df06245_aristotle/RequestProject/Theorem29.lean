import Mathlib

/-!
# Theorem 29: Statistical Significance of Win Rate with Finite Trade Count

We formalize claims about confidence intervals for binomial proportions,
minimum trade counts for significance, and per-symbol vs portfolio significance.
-/

open Real

noncomputable section

/-! ## Definitions -/

/-- The width of a 95% CI for a binomial proportion using the normal approximation. -/
def ciWidth (w_hat : ℝ) (T : ℝ) : ℝ :=
  2 * 1.96 * Real.sqrt (w_hat * (1 - w_hat) / T)

/-- The margin of error (half-width) of the 95% CI. -/
def ciMargin (w_hat : ℝ) (T : ℝ) : ℝ :=
  1.96 * Real.sqrt (w_hat * (1 - w_hat) / T)

/-- The lower bound of the 95% CI. -/
def ciLower (w_hat : ℝ) (T : ℝ) : ℝ :=
  w_hat - ciMargin w_hat T

/-- The upper bound of the 95% CI. -/
def ciUpper (w_hat : ℝ) (T : ℝ) : ℝ :=
  w_hat + ciMargin w_hat T

/-- Minimum number of trades needed for significance at 95% level against H0: w = 0.50. -/
def tMin (w_hat : ℝ) : ℝ :=
  (1.96) ^ 2 * w_hat * (1 - w_hat) / (w_hat - 0.50) ^ 2

/-! ## Part A: Confidence Interval Properties -/

/-- The CI width equals 2 * 1.96 * sqrt(w_hat * (1 - w_hat) / T). -/
theorem ciWidth_eq (w_hat T : ℝ) :
    ciWidth w_hat T = 2 * (1.96 * Real.sqrt (w_hat * (1 - w_hat) / T)) := by
  unfold ciWidth
  ring

/-- The CI width equals 2 * margin. -/
theorem ciWidth_eq_twice_margin (w_hat T : ℝ) :
    ciWidth w_hat T = 2 * ciMargin w_hat T := by
  unfold ciWidth ciMargin
  ring

/-
PROBLEM
Width decreases with T: if T₁ < T₂ (both positive), width at T₂ < width at T₁,
    provided 0 < w_hat < 1.

PROVIDED SOLUTION
The width is 2 * 1.96 * sqrt(w*(1-w)/T). Since 0 < w < 1, we have w*(1-w) > 0. Since T₁ < T₂ and both positive, w*(1-w)/T₂ < w*(1-w)/T₁, so sqrt is smaller, so width is smaller. Use mul_lt_mul_of_pos_left and Real.sqrt_lt_sqrt for monotonicity of sqrt.
-/
theorem ciWidth_decreasing {w_hat T₁ T₂ : ℝ}
    (hw0 : 0 < w_hat) (hw1 : w_hat < 1) (hT1 : 0 < T₁) (hT2 : T₁ < T₂) :
    ciWidth w_hat T₂ < ciWidth w_hat T₁ := by
  exact mul_lt_mul_of_pos_left ( Real.sqrt_lt_sqrt ( div_nonneg ( mul_nonneg hw0.le ( sub_nonneg.2 hw1.le ) ) ( by linarith ) ) ( by rw [ div_lt_div_iff₀ ] <;> nlinarith [ mul_pos hw0 ( sub_pos.2 hw1 ) ] ) ) ( by norm_num )

/-! ## Part A, Claim 2: Numerical bounds for w_hat = 0.597 -/

/-- Helper: 0.597 * 0.403 = 0.240591 -/
private lemma product_597 : (0.597 : ℝ) * (1 - 0.597) = 0.240591 := by norm_num

/-
PROBLEM
T = 36: width > 0.31

PROVIDED SOLUTION
ciWidth 0.597 36 = 2 * 1.96 * sqrt(0.597 * 0.403 / 36). We need this > 0.31. It suffices to show sqrt(0.240591/36) > 0.31/(2*1.96) = 0.31/3.92. Since 0.240591/36 = 0.00668308... and (0.31/3.92)^2 = 0.0961/15.3664 = 0.00625..., and 0.00668... > 0.00625..., we get the sqrt bound. Use Real.lt_sqrt (or sq_lt_sq') to convert sqrt inequality to squaring.
-/
theorem width_36_gt : ciWidth 0.597 36 > 0.31 := by
  unfold ciWidth ; norm_num [ Real.lt_sqrt ] at *; ring_nf at *; norm_num at *;
  nlinarith [ Real.sqrt_nonneg 80197, Real.sqrt_nonneg 12000000, Real.sq_sqrt ( show 0 ≤ 80197 by norm_num ), Real.sq_sqrt ( show 0 ≤ 12000000 by norm_num ), inv_pos.2 ( Real.sqrt_pos.2 ( show 0 < 12000000 by norm_num ) ), mul_inv_cancel₀ ( ne_of_gt ( Real.sqrt_pos.2 ( show 0 < 12000000 by norm_num ) ) ) ]

/-
PROBLEM
T = 36: CI lower bound < 0.50 (cannot reject H0)

PROVIDED SOLUTION
ciLower 0.597 36 = 0.597 - 1.96 * sqrt(0.597*0.403/36). We need this < 0.50, i.e., 1.96 * sqrt(0.240591/36) > 0.097. Equivalently sqrt(0.00668308..) > 0.097/1.96 = 0.04948..., which follows since 0.00668.. > (0.04948..)^2 = 0.00244... Use Real.lt_sqrt to convert.
-/
theorem ci_36_lower_lt_half : ciLower 0.597 36 < 0.50 := by
  rw [ show ciLower = fun w_hat T => w_hat - 1.96 * Real.sqrt ( w_hat * ( 1 - w_hat ) / T ) from funext fun w_hat => funext fun T => rfl ] ; norm_num [ Real.sqrt_lt' ] ; ring_nf ; norm_num;
  nlinarith [ Real.sqrt_nonneg 80197, Real.sqrt_nonneg 12000000, Real.sq_sqrt ( show 0 ≤ 80197 by norm_num ), Real.sq_sqrt ( show 0 ≤ 12000000 by norm_num ), inv_pos.2 ( Real.sqrt_pos.2 ( show 0 < 12000000 by norm_num ) ), mul_inv_cancel₀ ( ne_of_gt ( Real.sqrt_pos.2 ( show 0 < 12000000 by norm_num ) ) ) ]

/-
PROBLEM
T = 100: width < 0.192 + 0.001 (approximately 0.192)

PROVIDED SOLUTION
ciWidth 0.597 100 = 2 * 1.96 * sqrt(0.240591/100) = 3.92 * sqrt(0.00240591). We need 0.19 < this < 0.194. For the lower bound: 0.19/3.92 < sqrt(0.00240591), i.e., (0.19/3.92)^2 < 0.00240591, i.e., 0.0361/15.3664 < 0.00240591, i.e., 0.002348.. < 0.002405.. ✓. For the upper bound: sqrt(0.00240591) < 0.194/3.92, i.e., 0.00240591 < (0.194/3.92)^2 = 0.037636/15.3664 = 0.002449.. ✓. Use Real.lt_sqrt and Real.sqrt_lt'.
-/
theorem width_100_bound : ciWidth 0.597 100 > 0.19 ∧ ciWidth 0.597 100 < 0.194 := by
  unfold ciWidth; norm_num;
  constructor <;> nlinarith [ Real.sqrt_nonneg 240591, Real.sq_sqrt ( show 0 ≤ 240591 by norm_num ) ]

/-
PROBLEM
T = 100: CI lower bound > 0.50 (barely excludes 0.50)

PROVIDED SOLUTION
ciLower 0.597 100 = 0.597 - 1.96 * sqrt(0.00240591). We need this > 0.50, i.e., 1.96 * sqrt(0.00240591) < 0.097. So sqrt(0.00240591) < 0.097/1.96 = 0.0494897..., i.e., 0.00240591 < (0.0494897)^2 = 0.002449... ✓. Use Real.sqrt_lt' to convert sqrt upper bound to squared comparison.
-/
theorem ci_100_lower_gt_half : ciLower 0.597 100 > 0.50 := by
  unfold ciLower;
  unfold ciMargin; norm_num; ring_nf; norm_num;
  nlinarith [ Real.sqrt_nonneg 240591, Real.sq_sqrt ( show 0 ≤ 240591 by norm_num ) ]

/-
PROBLEM
T = 200: width bound

PROVIDED SOLUTION
ciWidth 0.597 200 = 2 * 1.96 * sqrt(0.240591/200) = 3.92 * sqrt(0.00120295..). For the bounds, use nlinarith with Real.sq_sqrt and Real.sqrt_nonneg as in the width_100_bound proof. Unfold ciWidth, norm_num, constructor, then nlinarith with sqrt lemmas.
-/
theorem width_200_bound : ciWidth 0.597 200 > 0.135 ∧ ciWidth 0.597 200 < 0.137 := by
  unfold ciWidth; norm_num; constructor ;
  · rw [ ← mul_div_assoc, lt_div_iff₀ ] <;> nlinarith [ Real.sqrt_nonneg 240591, Real.sqrt_nonneg 200000000, Real.sq_sqrt ( show 0 ≤ 240591 by norm_num ), Real.sq_sqrt ( show 0 ≤ 200000000 by norm_num ) ];
  · rw [ ← Real.sqrt_div ( by norm_num ) ] ; nlinarith [ Real.sqrt_nonneg ( 240591 / 200000000 ), Real.mul_self_sqrt ( show 0 ≤ 240591 / 200000000 by norm_num ) ] ;

/-
PROBLEM
T = 200: CI lower bound > 0.50

PROVIDED SOLUTION
Unfold ciLower and ciMargin, norm_num, then nlinarith with Real.sqrt_nonneg and Real.sq_sqrt as in ci_100_lower_gt_half proof.
-/
theorem ci_200_lower_gt_half : ciLower 0.597 200 > 0.529 := by
  unfold ciLower;
  unfold ciMargin;
  nlinarith [ Real.mul_self_sqrt ( show 0 ≤ 0.597 * ( 1 - 0.597 ) / 200 by norm_num ) ]

/-
PROBLEM
T = 500: width bound

PROVIDED SOLUTION
Unfold ciWidth, norm_num, constructor, then nlinarith with Real.sqrt_nonneg and Real.sq_sqrt as in width_100_bound proof.
-/
theorem width_500_bound : ciWidth 0.597 500 > 0.085 ∧ ciWidth 0.597 500 < 0.087 := by
  unfold ciWidth;
  constructor <;> nlinarith [ Real.sqrt_nonneg ( 240591 / 500000000 ), Real.mul_self_sqrt ( show 0 ≤ 240591 / 500000000 by norm_num ) ]

/-
PROBLEM
T = 900: width bound

PROVIDED SOLUTION
Unfold ciWidth, norm_num, constructor, then nlinarith with Real.sqrt_nonneg and Real.sq_sqrt as in width_100_bound proof.
-/
theorem width_900_bound : ciWidth 0.597 900 > 0.063 ∧ ciWidth 0.597 900 < 0.065 := by
  constructor <;> ring_nf <;> norm_num [ Real.lt_sqrt, Real.sqrt_lt' ];
  · unfold ciWidth ; ring ; norm_num;
    rw [ div_mul_eq_mul_div, lt_div_iff₀ ] <;> nlinarith [ Real.sqrt_nonneg 80197, Real.sqrt_nonneg 300000000, Real.sq_sqrt ( show 0 ≤ 80197 by norm_num ), Real.sq_sqrt ( show 0 ≤ 300000000 by norm_num ) ];
  · unfold ciWidth;
    nlinarith [ Real.mul_self_sqrt ( show 0 ≤ 597 / 1000 * ( 1 - 597 / 1000 ) / 900 by norm_num ) ]

/-
PROBLEM
T = 900: CI bounds. The exact CI is approximately [0.5650, 0.6290].
    The user's claim [0.565, 0.629] is extremely tight; we verify the slightly
    wider but still informative bounds [0.564, 0.630].

PROVIDED SOLUTION
Split into two parts. For ciLower > 0.564: unfold ciLower, ciMargin, then use nlinarith with Real.mul_self_sqrt. For ciUpper < 0.630: unfold ciUpper, ciMargin, then use nlinarith with Real.mul_self_sqrt. The key fact is Real.mul_self_sqrt (show 0 ≤ 0.597 * (1 - 0.597) / 900 by norm_num).
-/
theorem ci_900_bounds : ciLower 0.597 900 > 0.564 ∧ ciUpper 0.597 900 < 0.630 := by
  unfold ciLower ciUpper ciMargin; norm_num [ Real.lt_sqrt, Real.sqrt_lt ] ;
  constructor <;> nlinarith [ Real.sqrt_nonneg 80197, Real.sqrt_nonneg 300000000, Real.sq_sqrt ( show 0 ≤ 80197 by norm_num ), Real.sq_sqrt ( show 0 ≤ 300000000 by norm_num ), mul_pos ( Real.sqrt_pos.mpr ( show 0 < 80197 by norm_num ) ) ( Real.sqrt_pos.mpr ( show 0 < 300000000 by norm_num ) ), mul_div_cancel₀ ( Real.sqrt 80197 ) ( ne_of_gt ( Real.sqrt_pos.mpr ( show 0 < 300000000 by norm_num ) ) ) ]

/-! ## Part B: Minimum Trades for Significance -/

/-
PROBLEM
The condition for rejecting H0: w = 0.50 is equivalent to T > tMin.

PROVIDED SOLUTION
ciLower w_hat T > 0.50 means w_hat - 1.96 * sqrt(w_hat*(1-w_hat)/T) > 0.50, i.e., 1.96 * sqrt(w_hat*(1-w_hat)/T) < w_hat - 0.50. Since w_hat > 0.50, we have w_hat - 0.50 > 0. So this is equivalent to sqrt(w_hat*(1-w_hat)/T) < (w_hat - 0.50)/1.96. Since w_hat*(1-w_hat)/T ≥ 0 (all positive), this is equivalent to w_hat*(1-w_hat)/T < ((w_hat-0.50)/1.96)^2 = (w_hat-0.50)^2/(1.96)^2. Since T > 0, multiply both sides by T: w_hat*(1-w_hat) < T*(w_hat-0.50)^2/(1.96)^2. So T > (1.96)^2 * w_hat*(1-w_hat)/(w_hat-0.50)^2 = tMin w_hat. Use Real.sqrt_lt' for the sqrt ↔ square conversion.
-/
theorem reject_iff_T_gt_tMin {w_hat T : ℝ} (hw0 : 0 < w_hat) (hw1 : w_hat < 1)
    (hT : 0 < T) (hedge : w_hat > 0.50) :
    ciLower w_hat T > 0.50 ↔
      T > tMin w_hat := by
  -- Rewrite the inequality in terms of square roots.
  have h_sqrt : ciMargin w_hat T < w_hat - 0.50 ↔ Real.sqrt (w_hat * (1 - w_hat) / T) < (w_hat - 0.50) / 1.96 := by
    unfold ciMargin; constructor <;> intro <;> ring_nf at * <;> linarith;
  -- Apply the square root inequality equivalence to rewrite the goal.
  have h_goal : ciLower w_hat T > 0.50 ↔ Real.sqrt (w_hat * (1 - w_hat) / T) < (w_hat - 0.50) / 1.96 := by
    convert h_sqrt using 1;
    unfold ciLower; constructor <;> intro <;> linarith;
  rw [ h_goal, Real.sqrt_lt' ] <;> norm_num at *;
  · rw [ div_lt_iff₀ ( by positivity ) ] ; ring_nf ; norm_num [ tMin ] ;
    exact ⟨ fun h => by rw [ div_lt_iff₀ ] <;> nlinarith, fun h => by rw [ div_lt_iff₀ ] at h <;> nlinarith ⟩;
  · linarith

/-
PROBLEM
For w_hat = 0.597: T_min > 98

PROVIDED SOLUTION
tMin 0.597 = (1.96)^2 * 0.597 * 0.403 / (0.097)^2 which is a rational number. Unfold tMin and use norm_num.
-/
theorem tMin_597_gt_98 : tMin 0.597 > 98 := by
  unfold tMin; norm_num;

/-
PROBLEM
For w_hat = 0.597: T_min < 100

PROVIDED SOLUTION
Unfold tMin and use norm_num.
-/
theorem tMin_597_lt_100 : tMin 0.597 < 100 := by
  exact show ( 1.96 : ℝ ) ^ 2 * 0.597 * ( 1 - 0.597 ) / ( 0.597 - 0.50 ) ^ 2 < 100 by norm_num;

/-
PROBLEM
For w_hat = 0.55: T_min > 380

PROVIDED SOLUTION
Unfold tMin and use norm_num.
-/
theorem tMin_55_gt_380 : tMin 0.55 > 380 := by
  unfold tMin; norm_num;

/-
PROBLEM
For w_hat = 0.52: T_min > 2396

PROVIDED SOLUTION
Unfold tMin and use norm_num.
-/
theorem tMin_52_gt_2396 : tMin 0.52 > 2396 := by
  unfold tMin; norm_num;

/-! ## Part C: Per-Symbol vs Portfolio Significance -/

/-- Pooled CI is narrower: if T₂ > T₁ and both positive, then width at T₂ < width at T₁. -/
theorem pooled_ci_narrower {w_hat T₁ T₂ : ℝ}
    (hw0 : 0 < w_hat) (hw1 : w_hat < 1) (hT1 : 0 < T₁) (hT2 : T₁ < T₂) :
    ciWidth w_hat T₂ < ciWidth w_hat T₁ :=
  ciWidth_decreasing hw0 hw1 hT1 hT2

/-- Heterogeneous win rates: A strategy with 5 symbols at w=0.70 and 20 at w=0.50
    has pooled win rate 0.54 (weighted average). -/
theorem pooled_winrate_heterogeneous :
    (5 * 0.70 + 20 * 0.50) / (5 + 20 : ℝ) = 0.54 := by
  norm_num

/-- With w_hat ≈ 0.60, each symbol needs ~100 trades.
    At 36 trades per symbol over 20 days (1.8 trades/day/symbol),
    reaching 100 trades requires 100/1.8 ≈ 55.6 days, so at least 56 days.
    56 trading days ≈ 56/20 = 2.8 months ≈ 3 months. -/
theorem days_for_100_trades :
    (100 : ℝ) / (36 / 20) > 55 ∧ (100 : ℝ) / (36 / 20) < 56 := by
  constructor <;> norm_num

/-- 56 trading days is approximately 2.8 calendar months (at ~20 trading days/month). -/
theorem trading_days_to_months :
    (56 : ℝ) / 20 = 2.8 := by
  norm_num

end