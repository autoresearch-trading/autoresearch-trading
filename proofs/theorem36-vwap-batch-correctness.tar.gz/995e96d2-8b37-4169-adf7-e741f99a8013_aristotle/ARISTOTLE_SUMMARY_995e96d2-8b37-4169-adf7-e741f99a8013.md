# Summary of changes

# VWAP Batch Computation Correctness — Complete Lean 4 Formalization

All 10 claims have been formalized and machine-verified in Lean 4 with Mathlib. The project is organized into 5 files:

## File Structure

- **`RequestProject/VWAPDefs.lean`** — Core definitions: `VWAP`, `vwapWeight`, `Vbuy`, `Vsell`, `TFI`, `logReturn`
- **`RequestProject/PartA.lean`** — Claims 1–4: VWAP properties (8 theorems)
- **`RequestProject/PartB.lean`** — Claims 5–7: TFI properties (6 theorems)
- **`RequestProject/PartC.lean`** — Claims 8–9: Return computation (3 theorems)
- **`RequestProject/PartD.lean`** — Claim 10: Batching consistency (3 theorems)

## Summary of Results

### Part A: VWAP Properties
1. **Weighted mean**: `vwap_weighted_mean` — VWAP = Σ wᵢpᵢ; `vwap_weights_sum_one` — Σ wᵢ = 1; `vwap_weight_pos` — wᵢ > 0
   - **Bounds**: `vwap_lower_bound` and `vwap_upper_bound` — VWAP lies within the price range
2. **Price shift**: `vwap_price_shift` — VWAP(p+δ, q) = VWAP(p,q) + δ (requires B > 0)
3. **Quantity scaling invariance**: `vwap_quantity_scale` — VWAP(p, c·q) = VWAP(p, q) for c > 0
4. **Equal quantities**: `vwap_equal_quantities` — VWAP reduces to arithmetic mean when all qᵢ are equal

### Part B: TFI Properties
5. **Boundedness**: `tfi_bounded` — -1 ≤ TFI ≤ 1; `tfi_eq_one_iff` — TFI=1 ⟺ V_sell=0; `tfi_eq_neg_one_iff` — TFI=-1 ⟺ V_buy=0; `tfi_eq_zero_iff` — TFI=0 ⟺ V_buy=V_sell
6. **Buy fraction**: `tfi_eq_two_f_minus_one` — TFI = 2f - 1
7. **Signed notional**: `signed_notional_decomp` — V_buy - V_sell = TFI × (V_buy + V_sell)

### Part C: Return Computation
8. **Additivity**: `log_return_additive` — r₁→₃ = r₁→₂ + r₂→₃; `log_return_eq_log_div` — logReturn = log(v₃/v₁)
9. **Zero movement**: `log_return_zero_of_eq` — equal VWAPs ⟹ zero return

### Part D: Batching Consistency
10. **Partition invariance**: `vwap_partition` — combined VWAP = quantity-weighted average of sub-batch VWAPs; `vwap_simple_avg_neq` — simple average ≠ weighted average in general (counterexample); `vwap_combined_eq_avg_of_equal_qty` — equality holds when Q₁ = Q₂

### Note on `vwap_price_shift`
The original statement without `0 < B` was false (when B=0, VWAP is 0/0). The corrected version adds `hB : 0 < B` as a hypothesis, which is natural since a batch must contain at least one trade.

All proofs compile without `sorry` and use only standard axioms (`propext`, `Classical.choice`, `Quot.sound`).
