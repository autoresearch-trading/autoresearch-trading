import Mathlib
import RequestProject.VWAPDefs

/-!
# Part A: VWAP Properties
-/

open Finset BigOperators Real

noncomputable section

variable {B : ℕ} (p q : Fin B → ℝ)

/-! ### Claim 1: VWAP is a weighted mean of prices -/

/-
PROBLEM
VWAP equals the weighted sum of prices with weights w_i = q_i / total_qty.

PROVIDED SOLUTION
Unfold VWAP and vwapWeight, then show ∑ (q i / ∑ q j) * p i = (∑ p i * q i) / (∑ q j) by pulling the common denominator out of the sum.
-/
theorem vwap_weighted_mean (hq : ∀ i, 0 < q i) :
    VWAP p q = ∑ i, vwapWeight q i * p i := by
      unfold VWAP vwapWeight; ring;
      simp +decide only [mul_comm, Finset.mul_sum _ _ _, mul_assoc]

/-
PROBLEM
The VWAP weights sum to 1.

PROVIDED SOLUTION
Unfold vwapWeight. Sum of q i / (∑ q j) = (∑ q i) / (∑ q j) = 1 since ∑ q j > 0 (all q i > 0 and B > 0 so the sum is positive).
-/
theorem vwap_weights_sum_one (hB : 0 < B) (hq : ∀ i, 0 < q i) :
    ∑ i, vwapWeight q i = 1 := by
      unfold vwapWeight; rw [ ← Finset.sum_div _ _ _, div_self <| ne_of_gt <| Finset.sum_pos ( fun _ _ => hq _ ) ⟨ ⟨ 0, hB ⟩, Finset.mem_univ _ ⟩ ] ;

/-
PROBLEM
Each VWAP weight is positive.

PROVIDED SOLUTION
Unfold vwapWeight. q i > 0 and ∑ q j > 0 (sum of positives), so q i / ∑ q j > 0.
-/
theorem vwap_weight_pos (hq : ∀ i, 0 < q i) (i : Fin B) :
    0 < vwapWeight q i := by
      exact div_pos ( hq i ) ( Finset.sum_pos ( fun _ _ => hq _ ) ⟨ i, Finset.mem_univ _ ⟩ )

/-
PROBLEM
VWAP is bounded below: if m ≤ p i for all i, then m ≤ VWAP.

PROVIDED SOLUTION
Use vwap_weighted_mean to write VWAP = ∑ w_i * p_i. Since w_i > 0, w_i sums to 1, and p_i ≥ m, we get VWAP = ∑ w_i * p_i ≥ ∑ w_i * m = m * ∑ w_i = m. Use Finset.sum_le_sum with the bound w_i * p_i ≥ w_i * m from mul_le_mul_of_nonneg_left.
-/
theorem vwap_lower_bound (hB : 0 < B) (hq : ∀ i, 0 < q i) (m : ℝ)
    (hm : ∀ i, m ≤ p i) : m ≤ VWAP p q := by
      -- By definition of VWAP, we have VWAP p q = ∑ i, vwapWeight q i * p i.
      have hvwap : VWAP p q = ∑ i, vwapWeight q i * p i := by
        exact?;
      -- Since each term in the sum is non-negative, the sum of these terms is at least m times the sum of the weights.
      have h_sum_ge_m : ∑ i, vwapWeight q i * p i ≥ m * ∑ i, vwapWeight q i := by
        rw [ Finset.mul_sum _ _ _ ] ; exact Finset.sum_le_sum fun i _ => by nlinarith [ hm i, show 0 ≤ vwapWeight q i from div_nonneg ( le_of_lt ( hq i ) ) ( Finset.sum_nonneg fun _ _ => le_of_lt ( hq _ ) ) ] ;
      have h_sum_weights : ∑ i, vwapWeight q i = 1 := by
        exact?;
      aesop

/-
PROBLEM
VWAP is bounded above: if p i ≤ M for all i, then VWAP ≤ M.

PROVIDED SOLUTION
Use vwap_weighted_mean to write VWAP = ∑ w_i * p_i. Since w_i > 0, w_i sums to 1, and p_i ≤ M, we get VWAP = ∑ w_i * p_i ≤ ∑ w_i * M = M * ∑ w_i = M. Use Finset.sum_le_sum.
-/
theorem vwap_upper_bound (hB : 0 < B) (hq : ∀ i, 0 < q i) (M : ℝ)
    (hM : ∀ i, p i ≤ M) : VWAP p q ≤ M := by
      rw [ VWAP ];
      rw [ div_le_iff₀ ] <;> nlinarith [ Finset.sum_pos ( fun i _ => hq i ) ⟨ ⟨ 0, hB ⟩, Finset.mem_univ _ ⟩, show ∑ i, p i * q i ≤ M * ∑ i, q i by simpa only [ Finset.mul_sum _ _ _ ] using Finset.sum_le_sum fun i _ => mul_le_mul_of_nonneg_right ( hM i ) ( le_of_lt ( hq i ) ) ]

/-! ### Claim 2: VWAP is monotone in prices -/

/-
PROBLEM
Shifting all prices by delta shifts VWAP by delta.

PROVIDED SOLUTION
Unfold VWAP. Numerator: ∑ (p i + delta) * q i = ∑ p i * q i + delta * ∑ q i (by Finset.sum_add_const or distributing). Denominator is ∑ q i. So the result is (∑ pq + delta * ∑ q) / ∑ q = ∑ pq / ∑ q + delta. Use add_div and mul_div_cancel_right₀ with the fact that ∑ q i > 0 (from hB and hq).
-/
theorem vwap_price_shift (hB : 0 < B) (hq : ∀ i, 0 < q i) (delta : ℝ) :
    VWAP (fun i => p i + delta) q = VWAP p q + delta := by
      unfold VWAP;
      simp +decide [ add_mul, Finset.sum_add_distrib, div_add' ];
      rw [ ← Finset.mul_sum _ _ _, add_div, mul_div_cancel_right₀ _ ( ne_of_gt <| Finset.sum_pos ( fun _ _ => hq _ ) ⟨ ⟨ 0, hB ⟩, Finset.mem_univ _ ⟩ ) ]

/-! ### Claim 3: VWAP is invariant to quantity scaling -/

/-
PROBLEM
Scaling all quantities by c > 0 leaves VWAP unchanged.

PROVIDED SOLUTION
Unfold VWAP. Numerator: ∑ p i * (c * q i) = c * ∑ p i * q i. Denominator: ∑ c * q i = c * ∑ q i. So (c * num) / (c * den) = num / den since c > 0, hence c ≠ 0. Use mul_div_mul_left.
-/
theorem vwap_quantity_scale (hc : 0 < c) :
    VWAP p (fun i => c * q i) = VWAP p q := by
      unfold VWAP; ring;
      simp +decide only [mul_comm, mul_left_comm, ← Finset.mul_sum _ _ _];
      simp +decide [ mul_assoc, mul_comm, mul_left_comm, hc.ne' ]

/-! ### Claim 4: VWAP with equal quantities reduces to arithmetic mean -/

/-
PROBLEM
When all quantities equal q₀, VWAP = arithmetic mean of prices.

PROVIDED SOLUTION
Unfold VWAP. Numerator: ∑ p i * q₀ = q₀ * ∑ p i. Denominator: ∑ q₀ = B * q₀ (using Finset.sum_const and Finset.card_fin). So (q₀ * ∑ p) / (B * q₀) = ∑ p / B. Cancel q₀ using hq₀ > 0.
-/
theorem vwap_equal_quantities (hB : 0 < B) (q₀ : ℝ) (hq₀ : 0 < q₀) :
    VWAP p (fun _ => q₀) = (∑ i : Fin B, p i) / B := by
      unfold VWAP; ring;
      norm_num [ ← Finset.sum_mul _ _ _, hq₀.ne' ];
      norm_num [ mul_assoc, hq₀.ne' ]

end