import Mathlib
import RequestProject.VWAPDefs

/-!
# Part B: TFI Properties
-/

open Finset BigOperators Real

noncomputable section

variable {B : ℕ} (p q : Fin B → ℝ) (side : Fin B → Bool)

/-! ### Claim 5: TFI is bounded -/

/-
PROBLEM
TFI is between -1 and 1 when both V_buy and V_sell are nonneg.

PROVIDED SOLUTION
Unfold TFI. Let S = Vb + Vs > 0. We need -1 ≤ (Vb - Vs)/S ≤ 1. Since Vb ≥ 0 and Vs ≥ 0, we have -S = -(Vb+Vs) ≤ Vb - Vs ≤ Vb + Vs = S. Dividing by S > 0 gives -1 ≤ (Vb-Vs)/S ≤ 1. Use div_le_one and le_div_iff.
-/
theorem tfi_bounded (hVb : 0 ≤ Vbuy p q side) (hVs : 0 ≤ Vsell p q side)
    (hV : 0 < Vbuy p q side + Vsell p q side) :
    -1 ≤ TFI p q side ∧ TFI p q side ≤ 1 := by
      unfold TFI; constructor <;> nlinarith [ mul_div_cancel₀ ( Vbuy p q side - Vsell p q side ) hV.ne' ] ;

/-
PROBLEM
TFI = 1 iff V_sell = 0 (given positive total volume and nonneg components).

PROVIDED SOLUTION
Unfold TFI. (Vb - Vs)/(Vb + Vs) = 1 iff Vb - Vs = Vb + Vs (since Vb+Vs > 0, so ≠ 0), iff -Vs = Vs, iff 2*Vs = 0, iff Vs = 0 (since Vs ≥ 0). Use div_eq_one_iff_eq and linarith.
-/
theorem tfi_eq_one_iff (hVb : 0 ≤ Vbuy p q side) (hVs : 0 ≤ Vsell p q side)
    (hV : 0 < Vbuy p q side + Vsell p q side) :
    TFI p q side = 1 ↔ Vsell p q side = 0 := by
      constructor <;> intros <;> unfold TFI at * <;> rw [ div_eq_iff ] at * <;> linarith

/-
PROBLEM
TFI = -1 iff V_buy = 0 (given positive total volume and nonneg components).

PROVIDED SOLUTION
Unfold TFI. (Vb - Vs)/(Vb + Vs) = -1 iff Vb - Vs = -(Vb + Vs) (since Vb+Vs > 0, so ≠ 0), iff 2*Vb = 0, iff Vb = 0 (since Vb ≥ 0). Use div_eq_iff and linarith.
-/
theorem tfi_eq_neg_one_iff (hVb : 0 ≤ Vbuy p q side) (hVs : 0 ≤ Vsell p q side)
    (hV : 0 < Vbuy p q side + Vsell p q side) :
    TFI p q side = -1 ↔ Vbuy p q side = 0 := by
      unfold TFI;
      constructor <;> intro h <;> rw [ div_eq_iff ] at * <;> linarith

/-
PROBLEM
TFI = 0 iff V_buy = V_sell (given positive total volume).

PROVIDED SOLUTION
Unfold TFI. (Vb - Vs) / (Vb + Vs) = 0 iff Vb - Vs = 0 (since Vb + Vs > 0), iff Vb = Vs. Use div_eq_zero_iff and the fact that Vb + Vs ≠ 0.
-/
theorem tfi_eq_zero_iff (hV : 0 < Vbuy p q side + Vsell p q side) :
    TFI p q side = 0 ↔ Vbuy p q side = Vsell p q side := by
      exact ⟨ fun h => by unfold TFI at h; rw [ div_eq_iff ] at h <;> linarith, fun h => by unfold TFI; simp +decide [ h, sub_eq_zero ] ⟩

/-! ### Claim 6: TFI is a function of the buy fraction -/

/-
PROBLEM
TFI = 2 * (V_buy / (V_buy + V_sell)) - 1.

PROVIDED SOLUTION
Unfold TFI. We need (Vb - Vs)/(Vb + Vs) = 2*Vb/(Vb+Vs) - 1. Since Vb + Vs > 0, multiply both sides by (Vb+Vs): Vb - Vs = 2*Vb - (Vb+Vs) = Vb - Vs. Use field_simp and ring.
-/
theorem tfi_eq_two_f_minus_one (hV : 0 < Vbuy p q side + Vsell p q side) :
    TFI p q side = 2 * (Vbuy p q side / (Vbuy p q side + Vsell p q side)) - 1 := by
      unfold TFI; ring;
      linarith [ inv_mul_cancel₀ hV.ne' ]

/-! ### Claim 7: Signed notional decomposition -/

/-
PROBLEM
V_buy - V_sell = TFI * (V_buy + V_sell).

PROVIDED SOLUTION
Unfold TFI. TFI * (Vb + Vs) = ((Vb - Vs)/(Vb + Vs)) * (Vb + Vs) = Vb - Vs since Vb + Vs > 0. Use div_mul_cancel₀ and ne_of_gt hV.
-/
theorem signed_notional_decomp (hV : 0 < Vbuy p q side + Vsell p q side) :
    Vbuy p q side - Vsell p q side = TFI p q side * (Vbuy p q side + Vsell p q side) := by
      -- By definition of TFI, we have TFI = (Vbuy - Vsell) / (Vbuy + Vsell).
      have h_TFI : TFI p q side = (Vbuy p q side - Vsell p q side) / (Vbuy p q side + Vsell p q side) := by
        rfl;
      rw [ h_TFI, div_mul_cancel₀ _ hV.ne' ]

end