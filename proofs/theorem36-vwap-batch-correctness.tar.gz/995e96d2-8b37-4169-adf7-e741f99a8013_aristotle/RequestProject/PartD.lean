import Mathlib
import RequestProject.VWAPDefs

/-!
# Part D: Batching Consistency
-/

open Finset BigOperators Real

noncomputable section

/-! ### Claim 10: Partitioning invariance -/

/-
PROBLEM
VWAP of combined 2B trades equals quantity-weighted average of sub-batch VWAPs.
    We model this with two sets of B trades: (p₁, q₁) and (p₂, q₂).

PROVIDED SOLUTION
Unfold VWAP on v₁ and v₂. Then Q₁ * v₁ = Q₁ * (∑ p₁*q₁ / Q₁) = ∑ p₁*q₁ (since Q₁ > 0), similarly Q₂ * v₂ = ∑ p₂*q₂. So Q₁*v₁ + Q₂*v₂ = ∑ p₁*q₁ + ∑ p₂*q₂. Both sides divided by Q₁+Q₂ are equal.
-/
theorem vwap_partition {B : ℕ} (p₁ q₁ p₂ q₂ : Fin B → ℝ)
    (hq₁ : ∀ i, 0 < q₁ i) (hq₂ : ∀ i, 0 < q₂ i) :
    let Q₁ := ∑ i, q₁ i
    let Q₂ := ∑ i, q₂ i
    let v₁ := VWAP p₁ q₁
    let v₂ := VWAP p₂ q₂
    (∑ i, p₁ i * q₁ i + ∑ i, p₂ i * q₂ i) / (Q₁ + Q₂) =
      (Q₁ * v₁ + Q₂ * v₂) / (Q₁ + Q₂) := by
        by_cases H : ∑ i, q₁ i = 0 <;> by_cases H' : ∑ i, q₂ i = 0 <;> simp_all +decide [ mul_div_cancel₀, VWAP ];
        · rw [ Finset.sum_eq_zero_iff_of_nonneg fun _ _ => le_of_lt ( hq₁ _ ) ] at H ; aesop;
        · exact absurd H' <| ne_of_gt <| Finset.sum_pos ( fun _ _ => hq₂ _ ) ⟨ ⟨ 0, Nat.pos_of_ne_zero <| by aesop_cat ⟩, Finset.mem_univ _ ⟩

/-
PROBLEM
The simple average (v₁ + v₂)/2 does NOT generally equal the quantity-weighted VWAP.
    We show this by exhibiting a counterexample.

PROVIDED SOLUTION
Construct a counterexample with B=1. Let p₁ = ![10], q₁ = ![1], p₂ = ![10], q₂ = ![2]. Then v₁ = 10, v₂ = 10, Q₁ = 1, Q₂ = 2. Combined = (1*10 + 2*10)/(1+2) = 10 and (10+10)/2 = 10. Hmm that's equal. Let me pick different prices: p₁ = ![10], q₁ = ![1], p₂ = ![20], q₂ = ![3]. Then v₁ = 10, v₂ = 20. Combined = (10 + 60)/4 = 17.5 ≠ 15 = (10+20)/2. Use refine ⟨![10], ![1], ![20], ![3], ...⟩ and norm_num.
-/
theorem vwap_simple_avg_neq :
    ∃ (p₁ q₁ p₂ q₂ : Fin 1 → ℝ),
      (∀ i, 0 < q₁ i) ∧ (∀ i, 0 < q₂ i) ∧
      (∀ i, 0 < p₁ i) ∧ (∀ i, 0 < p₂ i) ∧
      let Q₁ := ∑ i, q₁ i
      let Q₂ := ∑ i, q₂ i
      let v₁ := VWAP p₁ q₁
      let v₂ := VWAP p₂ q₂
      (Q₁ * v₁ + Q₂ * v₂) / (Q₁ + Q₂) ≠ (v₁ + v₂) / 2 := by
        -- Choose different prices and document volumes for the two batches.
        use ![10.0], ![1.0], ![20.0], ![3.0];
        norm_num [ Fin.forall_fin_one, VWAP ]

/-
PROBLEM
When Q₁ = Q₂, the quantity-weighted average equals the simple average.

PROVIDED SOLUTION
Substitute Q₂ = Q₁. Then (Q₁*v₁ + Q₁*v₂)/(Q₁ + Q₁) = Q₁*(v₁+v₂)/(2*Q₁) = (v₁+v₂)/2. Use field_simp and ring, with hQ and hQpos to clear denominators.
-/
theorem vwap_combined_eq_avg_of_equal_qty
    (Q₁ Q₂ v₁ v₂ : ℝ) (hQ : Q₁ = Q₂) (hQpos : 0 < Q₁) :
    (Q₁ * v₁ + Q₂ * v₂) / (Q₁ + Q₂) = (v₁ + v₂) / 2 := by
      grind +ring

end