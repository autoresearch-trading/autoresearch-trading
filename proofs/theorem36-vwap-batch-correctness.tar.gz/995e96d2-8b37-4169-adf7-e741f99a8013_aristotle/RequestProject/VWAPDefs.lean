import Mathlib

/-!
# VWAP Batch Computation Correctness

Formalizes properties of Volume Weighted Average Price (VWAP),
Trade Flow Imbalance (TFI), and log returns over batches of trades.
-/

open Finset BigOperators Real

noncomputable section

/-! ## Core Definitions -/

/-- VWAP (Volume Weighted Average Price) of a batch of trades. -/
def VWAP {B : ℕ} (p q : Fin B → ℝ) : ℝ :=
  (∑ i, p i * q i) / (∑ i, q i)

/-- Weight of trade i in the VWAP computation. -/
def vwapWeight {B : ℕ} (q : Fin B → ℝ) (i : Fin B) : ℝ :=
  q i / (∑ j, q j)

/-- V_buy: total notional of buy-side trades. -/
def Vbuy {B : ℕ} (p q : Fin B → ℝ) (side : Fin B → Bool) : ℝ :=
  ∑ i ∈ Finset.univ.filter (fun i => side i = true), p i * q i

/-- V_sell: total notional of sell-side trades. -/
def Vsell {B : ℕ} (p q : Fin B → ℝ) (side : Fin B → Bool) : ℝ :=
  ∑ i ∈ Finset.univ.filter (fun i => side i = false), p i * q i

/-- Trade Flow Imbalance. -/
def TFI {B : ℕ} (p q : Fin B → ℝ) (side : Fin B → Bool) : ℝ :=
  (Vbuy p q side - Vsell p q side) / (Vbuy p q side + Vsell p q side)

/-- Log return between two VWAPs. -/
def logReturn (v_prev v_curr : ℝ) : ℝ :=
  Real.log v_curr - Real.log v_prev

end
