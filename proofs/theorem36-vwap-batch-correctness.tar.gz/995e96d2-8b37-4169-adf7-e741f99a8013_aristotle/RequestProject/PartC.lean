import Mathlib
import RequestProject.VWAPDefs

/-!
# Part C: Return Computation
-/

open Finset BigOperators Real

noncomputable section

/-! ### Claim 8: Log return additivity -/

/-
PROBLEM
Multi-period log returns are additive: r_{1→3} = r_{1→2} + r_{2→3}.

PROVIDED SOLUTION
Unfold logReturn. (log v₃ - log v₁) = (log v₂ - log v₁) + (log v₃ - log v₂). This is just ring/linarith.
-/
theorem log_return_additive (v₁ v₂ v₃ : ℝ) :
    logReturn v₁ v₃ = logReturn v₁ v₂ + logReturn v₂ v₃ := by
      unfold logReturn; ring;

/-
PROBLEM
The combined log return equals log(v₃/v₁).

PROVIDED SOLUTION
Unfold logReturn. Use Real.log_div (ne_of_gt hv₃) (ne_of_gt hv₁) to rewrite log(v₃/v₁) = log v₃ - log v₁.
-/
theorem log_return_eq_log_div (v₁ v₃ : ℝ) (hv₁ : 0 < v₁) (hv₃ : 0 < v₃) :
    logReturn v₁ v₃ = Real.log (v₃ / v₁) := by
      unfold logReturn; rw [ Real.log_div ] <;> linarith;

/-! ### Claim 9: Return from zero-movement batch -/

/-
PROBLEM
If VWAPs are equal, the log return is 0.

PROVIDED SOLUTION
Unfold logReturn. log v - log v = 0 by ring.
-/
theorem log_return_zero_of_eq (v : ℝ) :
    logReturn v v = 0 := by
      exact sub_self _

end