import Mathlib

/-!
# Theorem 21: LossClusterCounterexample (corrected statement)

We formalize the standard financial definitions (Profit Factor, win rate, Sortino ratio)
and prove five claims about their interrelationship, showing that the naive claim
"PF > 1 ∧ Sortino ≤ 0" is impossible under standard definitions, but Sortino can be
made arbitrarily small. We also prove permutation invariance of these quantities and
contrast with path-dependent measures like max drawdown.

## Main results

1. **Impossibility** (`pf_gt_one_imp_sortino_pos`): PF > 1 with at least one loss
   implies Sortino > 0 under standard definitions.

2. **No positive lower bound** (`no_positive_lower_bound`): For every ε > 0, there exists
   a return sequence with PF > 1, w > 1/2, and 0 < Sortino < ε.

3. **Explicit six-trade family** (`sixTrades_*`): The family (1/2+δ, 1/2+δ, 1/2+δ, 1/2+δ, -1, -1)
   has PF = 1+2δ, w = 2/3, and Sortino = (2/√3)·δ·√m → 0⁺ as δ → 0⁺.

4. **Permutation invariance** (`*_perm`): PF, win rate, mean return, downside std, and Sortino
   are all invariant under permutation of the return sequence.

5. **Path-dependent drawdown** (`sortino_perm_invariant_drawdown_path_dependent`):
   Two permutations of the same multiset can have equal Sortino but different max drawdown.
-/

noncomputable section

open Real Finset BigOperators List

/-! ## Definitions -/

/-- Gross wins: sum of positive returns. -/
def grossWins (rs : List ℝ) : ℝ :=
  (rs.filter (· > 0)).sum

/-- Gross losses: sum of absolute values of negative returns (a positive quantity). -/
def grossLosses (rs : List ℝ) : ℝ :=
  ((rs.filter (· < 0)).map (|·|)).sum

/-- Profit Factor: gross wins divided by gross losses. -/
def profitFactor (rs : List ℝ) : ℝ :=
  grossWins rs / grossLosses rs

/-- Number of winning trades. -/
def numWins (rs : List ℝ) : ℕ :=
  (rs.filter (· > 0)).length

/-- Win rate: fraction of trades that are winners. -/
def winRate (rs : List ℝ) : ℝ :=
  (numWins rs : ℝ) / (rs.length : ℝ)

/-- Mean return of a return sequence. -/
def meanReturn (rs : List ℝ) : ℝ :=
  rs.sum / (rs.length : ℝ)

/-- Sum of squares of negative returns (downside sum of squares). -/
def downsideSumSq (rs : List ℝ) : ℝ :=
  ((rs.filter (· < 0)).map (· ^ 2)).sum

/-- Downside semideviation (using full n in denominator, target = 0). -/
def downsideStd (rs : List ℝ) : ℝ :=
  Real.sqrt (downsideSumSq rs / (rs.length : ℝ))

/-- Sortino ratio with annualization factor √m. -/
def sortinoRatio (rs : List ℝ) (m : ℝ) : ℝ :=
  meanReturn rs / downsideStd rs * Real.sqrt m

/-- A return sequence has "at least one loss". -/
def hasLoss (rs : List ℝ) : Prop :=
  ∃ r ∈ rs, r < 0

/-- A return sequence has "no zero returns" (all returns are strictly positive or negative). -/
def noZeroReturns (rs : List ℝ) : Prop :=
  ∀ r ∈ rs, r ≠ 0

/-- Cumulative sums (partial sums) of a return sequence, starting from 0. -/
def cumSums (rs : List ℝ) : List ℝ :=
  rs.scanl (· + ·) 0

/-- Max drawdown auxiliary: tracks running peak and maximum drawdown. -/
def maxDrawdownAux : ℝ → ℝ → List ℝ → ℝ
  | _, maxDD, [] => maxDD
  | peak, maxDD, (x :: xs) =>
    let newPeak := max peak x
    let dd := newPeak - x
    maxDrawdownAux newPeak (max maxDD dd) xs

/-- Max drawdown: maximum peak-to-trough decline in cumulative returns. -/
def maxDrawdown' (rs : List ℝ) : ℝ :=
  let cs := cumSums rs
  match cs with
  | [] => 0
  | (c :: cs') => maxDrawdownAux c 0 cs'

/-! ## Part 1: Impossibility

For any finite return sequence with no zero returns and at least one loss,
PF > 1 implies mean return > 0, hence Sortino > 0. Therefore PF > 1 ∧ Sortino ≤ 0
is impossible under the standard definition. -/

/-- The sum of a return sequence equals grossWins minus grossLosses
    (when there are no zero returns). -/
theorem sum_eq_grossWins_sub_grossLosses (rs : List ℝ) (h : noZeroReturns rs) :
    rs.sum = grossWins rs - grossLosses rs := by
  induction' rs using List.reverseRecOn with r rs ih <;> simp +decide [ *, List.filter_cons ] at *;
  · unfold grossWins grossLosses; norm_num;
  · simp +decide [ *, grossWins, grossLosses ] at *;
    by_cases h' : 0 < rs <;> by_cases h'' : rs < 0 <;> simp +decide [ h', h'', ih ] at h ⊢ <;> ring_nf at *;
    · linarith;
    · linarith [ ih fun x hx => h x ( List.mem_append_left _ hx ) ];
    · linarith [ ih fun x hx => h x ( List.mem_append_left _ hx ), abs_of_neg h'' ];
    · exact absurd ( h rs ( by aesop ) ) ( by norm_num; linarith )

/-- If PF > 1 and there is at least one loss, then mean return > 0. -/
theorem pf_gt_one_imp_mean_pos (rs : List ℝ) (hlen : rs.length > 0)
    (hnz : noZeroReturns rs) (hloss : hasLoss rs)
    (hpf : profitFactor rs > 1) :
    meanReturn rs > 0 := by
  have h_sum : rs.sum = grossWins rs - grossLosses rs := by
    exact?;
  have h_profit : profitFactor rs = grossWins rs / grossLosses rs := by
    rfl;
  have h_grossWins_gt_grossLosses : grossWins rs > grossLosses rs := by
    contrapose! hpf;
    exact h_profit ▸ div_le_one_of_le₀ hpf ( by exact List.sum_nonneg fun x hx => by aesop );
  exact div_pos ( by linarith [ show 0 ≤ grossLosses rs from List.sum_nonneg ( by aesop ) ] ) ( Nat.cast_pos.mpr hlen )

/-- If there is at least one loss, the downside std is strictly positive. -/
theorem hasLoss_imp_downsideStd_pos (rs : List ℝ) (hlen : rs.length > 0)
    (hloss : hasLoss rs) :
    downsideStd rs > 0 := by
  have h_downsideSumSq_pos : downsideSumSq rs > 0 := by
    have h_downsideSumSq_pos : (rs.filter (· < 0)).map (· ^ 2) ≠ [] := by
      aesop;
    have h_downsideSumSq_pos : ∀ {l : List ℝ}, l ≠ [] → (∀ x ∈ l, 0 < x) → 0 < List.sum l := by
      exact?;
    exact h_downsideSumSq_pos ‹_› fun x hx => by obtain ⟨ y, hy, rfl ⟩ := List.mem_map.mp hx; exact sq_pos_of_neg <| by aesop;
  exact Real.sqrt_pos.mpr ( div_pos h_downsideSumSq_pos ( Nat.cast_pos.mpr hlen ) )

/-- **Part 1 main result**: PF > 1 with at least one loss implies Sortino > 0. -/
theorem pf_gt_one_imp_sortino_pos (rs : List ℝ) (hlen : rs.length > 0)
    (hnz : noZeroReturns rs) (hloss : hasLoss rs) (m : ℝ) (hm : m > 0)
    (hpf : profitFactor rs > 1) :
    sortinoRatio rs m > 0 := by
  refine' mul_pos _ ( Real.sqrt_pos.mpr hm );
  apply div_pos; exact pf_gt_one_imp_mean_pos rs hlen hnz hloss hpf; exact hasLoss_imp_downsideStd_pos rs hlen hloss;

/-! ## Part 2: No positive lower bound

For every ε > 0, there exists a return sequence with PF > 1, w > 1/2,
and 0 < Sortino < ε. We use the six-trade family from Part 3. -/

/-- **Part 2**: For every ε > 0, there exists a return sequence with PF > 1, w > 1/2,
    and 0 < Sortino < ε. -/
theorem no_positive_lower_bound (ε : ℝ) (hε : ε > 0) (m : ℝ) (hm : m > 0) :
    ∃ rs : List ℝ,
      rs.length > 0 ∧
      noZeroReturns rs ∧
      hasLoss rs ∧
      profitFactor rs > 1 ∧
      winRate rs > 1 / 2 ∧
      0 < sortinoRatio rs m ∧
      sortinoRatio rs m < ε := by
  obtain ⟨δ, hδ_pos, hδ⟩ : ∃ δ > 0, δ < ε * Real.sqrt 3 / (4 * Real.sqrt m) ∧ δ < 1 / 2 := by
    exact ⟨ Min.min ( ε * Real.sqrt 3 / ( 4 * Real.sqrt m ) ) ( 1 / 2 ) / 2, by positivity, by linarith [ show 0 < Min.min ( ε * Real.sqrt 3 / ( 4 * Real.sqrt m ) ) ( 1 / 2 ) by positivity, min_le_left ( ε * Real.sqrt 3 / ( 4 * Real.sqrt m ) ) ( 1 / 2 ), min_le_right ( ε * Real.sqrt 3 / ( 4 * Real.sqrt m ) ) ( 1 / 2 ) ], by linarith [ show 0 < Min.min ( ε * Real.sqrt 3 / ( 4 * Real.sqrt m ) ) ( 1 / 2 ) by positivity, min_le_left ( ε * Real.sqrt 3 / ( 4 * Real.sqrt m ) ) ( 1 / 2 ), min_le_right ( ε * Real.sqrt 3 / ( 4 * Real.sqrt m ) ) ( 1 / 2 ) ] ⟩;
  refine' ⟨ [ 1 / 2 + δ, 1 / 2 + δ, 1 / 2 + δ, 1 / 2 + δ, -1, -1 ], _, _, _, _, _, _ ⟩ <;> norm_num [ List.filter_cons, List.map ] at *;
  · exact fun x hx => by rw [ List.mem_cons, List.mem_cons, List.mem_cons, List.mem_cons, List.mem_cons, List.mem_singleton ] at hx; rcases hx with ( rfl | rfl | rfl | rfl | rfl | rfl ) <;> linarith;
  · exact ⟨ -1, by norm_num ⟩;
  · unfold profitFactor ; ring_nf ; norm_num [ hδ_pos ] ;
    unfold grossWins grossLosses; norm_num [ List.filter_cons, List.map ] ; ring_nf ; norm_num [ hδ_pos ] ;
    split_ifs <;> norm_num <;> linarith;
  · unfold winRate; norm_num [ hδ_pos, hδ ] ; ring_nf; norm_num [ hm.le, hm.ne', hδ_pos.ne' ] ;
    unfold numWins; norm_num [ List.filter_cons, hδ_pos ] ; ring_nf; norm_num [ hm.le, hm.ne', hδ_pos.ne' ] ;
    split_ifs <;> norm_num ; linarith;
  · unfold sortinoRatio;
    unfold meanReturn downsideStd;
    norm_num [ downsideSumSq ] at *;
    norm_num [ List.filter_cons, List.map ] at *;
    split_ifs <;> norm_num at * <;> try linarith;
    rw [ lt_div_iff₀ ( by positivity ) ] at *;
    rw [ show ( 6 : ℝ ) = 3 * 2 by norm_num, Real.sqrt_mul ] <;> ring_nf <;> norm_num;
    exact ⟨ by positivity, by nlinarith [ Real.sqrt_nonneg 3, Real.sqrt_nonneg m, Real.sq_sqrt ( show 0 ≤ 3 by norm_num ), Real.sq_sqrt ( show 0 ≤ m by positivity ) ] ⟩

/-! ## Part 3: Explicit six-trade family

Let δ > 0 and consider (1/2+δ, 1/2+δ, 1/2+δ, 1/2+δ, -1, -1). -/

/-- The explicit six-trade return sequence. -/
def sixTrades (δ : ℝ) : List ℝ :=
  [1/2 + δ, 1/2 + δ, 1/2 + δ, 1/2 + δ, -1, -1]

theorem sixTrades_grossWins (δ : ℝ) (hδ : δ > 0) :
    grossWins (sixTrades δ) = 4 * (1/2 + δ) := by
  unfold sixTrades grossWins; norm_num [ List.filter_cons ] ; ring;
  split_ifs <;> norm_num <;> linarith

theorem sixTrades_grossLosses (δ : ℝ) (hδ : δ > 0) :
    grossLosses (sixTrades δ) = 2 := by
  unfold sixTrades grossLosses; norm_num [ hδ, List.filter_cons ] ;
  split_ifs <;> norm_num ; linarith

/-- PF = 1 + 2δ. -/
theorem sixTrades_pf (δ : ℝ) (hδ : δ > 0) :
    profitFactor (sixTrades δ) = 1 + 2 * δ := by
  unfold profitFactor; rw [ sixTrades_grossWins δ hδ, sixTrades_grossLosses δ hδ ] ; ring;

/-- Win rate = 2/3. -/
theorem sixTrades_winRate (δ : ℝ) (hδ : δ > 0) :
    winRate (sixTrades δ) = 2 / 3 := by
  unfold winRate sixTrades;
  unfold numWins; norm_num [ List.filter_cons, hδ ] ; ring; norm_num;
  split_ifs <;> norm_num ; linarith

/-- Mean return = 2δ/3. -/
theorem sixTrades_meanReturn (δ : ℝ) (hδ : δ > 0) :
    meanReturn (sixTrades δ) = 2 * δ / 3 := by
  unfold sixTrades meanReturn; norm_num; ring;

/-- Downside std = 1/√3. -/
theorem sixTrades_downsideStd (δ : ℝ) (hδ : δ > 0) :
    downsideStd (sixTrades δ) = 1 / Real.sqrt 3 := by
  unfold sixTrades downsideStd; norm_num [ List.filter_cons ] ; ring; norm_num [ hδ.le ] ;
  unfold downsideSumSq; norm_num [ List.filter_cons ] ; ring_nf; norm_num;
  split_ifs <;> norm_num <;> try linarith;
  rw [ show ( 6 : ℝ ) = 2 * 3 by norm_num, Real.sqrt_mul ] <;> ring <;> norm_num

/-- Sortino = (2/√3) · δ · √m, which → 0⁺ as δ → 0⁺. -/
theorem sixTrades_sortino (δ : ℝ) (hδ : δ > 0) (m : ℝ) (hm : m > 0) :
    sortinoRatio (sixTrades δ) m = 2 / Real.sqrt 3 * δ * Real.sqrt m := by
  unfold sortinoRatio; rw [ sixTrades_meanReturn δ hδ, sixTrades_downsideStd δ hδ ] ; ring; norm_num [ hδ.le, hm.le ] ; ring;
  rw [ ← Real.sqrt_div_self ] ; ring;

/-! ## Part 4: Permutation invariance

PF, win rate, mean return, downside semideviation, and Sortino ratio of a finite return
sequence depend only on the multiset of returns, not on their temporal order. -/

/-- grossWins is invariant under permutation. -/
theorem grossWins_perm {rs₁ rs₂ : List ℝ} (h : rs₁.Perm rs₂) :
    grossWins rs₁ = grossWins rs₂ := by
  apply List.Perm.sum_eq; exact h.filter _;

/-- grossLosses is invariant under permutation. -/
theorem grossLosses_perm {rs₁ rs₂ : List ℝ} (h : rs₁.Perm rs₂) :
    grossLosses rs₁ = grossLosses rs₂ := by
  simp [grossLosses];
  rw [ List.Perm.sum_eq ] ; exact List.Perm.map _ ( h.filter _ ) ;

/-- profitFactor is invariant under permutation. -/
theorem profitFactor_perm {rs₁ rs₂ : List ℝ} (h : rs₁.Perm rs₂) :
    profitFactor rs₁ = profitFactor rs₂ := by
  exact congr_arg₂ _ ( grossWins_perm h ) ( grossLosses_perm h )

/-- winRate is invariant under permutation. -/
theorem winRate_perm {rs₁ rs₂ : List ℝ} (h : rs₁.Perm rs₂) :
    winRate rs₁ = winRate rs₂ := by
  unfold winRate;
  rw [ h.length_eq, show numWins rs₁ = numWins rs₂ from ?_ ];
  exact h.filter _ |> List.Perm.length_eq

/-- meanReturn is invariant under permutation. -/
theorem meanReturn_perm {rs₁ rs₂ : List ℝ} (h : rs₁.Perm rs₂) :
    meanReturn rs₁ = meanReturn rs₂ := by
  have h_sum : rs₁.sum = rs₂.sum := h.sum_eq
  have h_len : rs₁.length = rs₂.length := h.length_eq
  simp [meanReturn, h_sum, h_len]

/-- downsideStd is invariant under permutation. -/
theorem downsideStd_perm {rs₁ rs₂ : List ℝ} (h : rs₁.Perm rs₂) :
    downsideStd rs₁ = downsideStd rs₂ := by
  unfold downsideStd;
  have h_downsideSumSq : downsideSumSq rs₁ = downsideSumSq rs₂ := by
    apply List.Perm.sum_eq;
    exact List.Perm.map _ ( h.filter _ );
  rw [ h_downsideSumSq, h.length_eq ]

/-- sortinoRatio is invariant under permutation. -/
theorem sortinoRatio_perm {rs₁ rs₂ : List ℝ} (h : rs₁.Perm rs₂) (m : ℝ) :
    sortinoRatio rs₁ m = sortinoRatio rs₂ m := by
  unfold sortinoRatio; rw [ meanReturn_perm h, downsideStd_perm h ] ;

/-! ## Part 5: Path-dependent drawdown

Two return sequences with the same multiset of returns have the same PF, win rate,
mean return, and Sortino, but can have different max drawdown. This shows that standard
Sortino is permutation-invariant, while drawdown-based objectives are path-dependent. -/

/-- The two example sequences from Part 5. -/
def seqA : List ℝ := [1, 1, -1, -1]
def seqB : List ℝ := [1, -1, 1, -1]

/-- seqA and seqB are permutations of each other. -/
theorem seqAB_perm : seqA.Perm seqB := by
  rw [ List.perm_iff_count ];
  unfold seqA seqB;intros; simp +decide [ List.count_cons ] ; aesop;

theorem seqAB_same_pf : profitFactor seqA = profitFactor seqB := by
  apply profitFactor_perm; exact seqAB_perm

theorem seqAB_same_winRate : winRate seqA = winRate seqB := by
  apply winRate_perm; exact seqAB_perm;

theorem seqAB_same_meanReturn : meanReturn seqA = meanReturn seqB := by
  unfold meanReturn; unfold seqA; unfold seqB; norm_num;

theorem seqAB_same_sortino (m : ℝ) : sortinoRatio seqA m = sortinoRatio seqB m := by
  apply sortinoRatio_perm; exact seqAB_perm

theorem cumSums_seqA : cumSums seqA = [0, 1, 2, 1, 0] := by
  unfold seqA; norm_num [cumSums]

theorem cumSums_seqB : cumSums seqB = [0, 1, 0, 1, 0] := by
  norm_num [ cumSums, seqB ]

/-- Max drawdown of (1, 1, -1, -1) is 2. -/
theorem maxDrawdown_seqA : maxDrawdown' seqA = 2 := by
  have h_drawdown_seqA : maxDrawdown' seqA = 2 := by
    unfold maxDrawdown'
    norm_num [seqA, cumSums]
    simp [maxDrawdownAux];
  exact h_drawdown_seqA

/-- Max drawdown of (1, -1, 1, -1) is 1. -/
theorem maxDrawdown_seqB : maxDrawdown' seqB = 1 := by
  unfold seqB maxDrawdown' maxDrawdownAux; norm_num;
  unfold cumSums; norm_num [ maxDrawdownAux ] ;

/-- seqA and seqB have different max drawdown (2 ≠ 1). -/
theorem seqAB_diff_maxDrawdown : maxDrawdown' seqA ≠ maxDrawdown' seqB := by
  simp [maxDrawdown_seqA, maxDrawdown_seqB]

/-- **Part 5 capstone**: Standard Sortino is permutation-invariant, but max drawdown is
    path-dependent: there exist two permutations of the same multiset with equal Sortino
    but different drawdown. -/
theorem sortino_perm_invariant_drawdown_path_dependent :
    ∃ (rs₁ rs₂ : List ℝ),
      rs₁.Perm rs₂ ∧
      (∀ m, sortinoRatio rs₁ m = sortinoRatio rs₂ m) ∧
      maxDrawdown' rs₁ ≠ maxDrawdown' rs₂ := by
  use seqA, seqB;
  exact ⟨ seqAB_perm, fun m => seqAB_same_sortino m, seqAB_diff_maxDrawdown ⟩

end
