# Summary of changes
Successfully formalized and proved all five parts of Theorem 21 (LossClusterCounterexample) in `RequestProject/LossClusterCounterexample.lean`. The file builds cleanly with no `sorry` statements and uses only standard axioms (`propext`, `Classical.choice`, `Quot.sound`).

## Definitions formalized
- `grossWins`, `grossLosses`, `profitFactor` (PF = gross_wins / gross_losses)
- `numWins`, `winRate` (w = wins / total)
- `meanReturn`, `downsideSumSq`, `downsideStd` (downside semideviation with full-n denominator, target = 0)
- `sortinoRatio` (= meanReturn / downsideStd × √m)
- `cumSums`, `maxDrawdownAux`, `maxDrawdown'` (max peak-to-trough decline in cumulative returns)

## Theorems proved

**Part 1 — Impossibility** (`pf_gt_one_imp_sortino_pos`):
For any return sequence with no zero returns and at least one loss, PF > 1 implies mean return > 0 (since sum = grossWins − grossLosses > 0), hence Sortino > 0. The conjunction PF > 1 ∧ Sortino ≤ 0 is impossible.

**Part 2 — No positive lower bound** (`no_positive_lower_bound`):
For every ε > 0 and m > 0, there exists a return sequence with PF > 1, w > 1/2, and 0 < Sortino < ε. The proof constructs such a sequence from the six-trade family with sufficiently small δ.

**Part 3 — Explicit six-trade family** (`sixTrades_*`):
For the sequence (1/2+δ, 1/2+δ, 1/2+δ, 1/2+δ, −1, −1) with δ > 0:
- PF = 1 + 2δ
- Win rate = 2/3
- Mean return = 2δ/3
- Downside std = 1/√3
- Sortino = (2/√3) · δ · √m → 0⁺ as δ → 0⁺

**Part 4 — Permutation invariance** (`grossWins_perm`, `grossLosses_perm`, `profitFactor_perm`, `winRate_perm`, `meanReturn_perm`, `downsideStd_perm`, `sortinoRatio_perm`):
All these quantities depend only on the multiset of returns, not on temporal order.

**Part 5 — Path-dependent drawdown** (`sortino_perm_invariant_drawdown_path_dependent`):
The sequences (1,1,−1,−1) and (1,−1,1,−1) are permutations with identical PF, win rate, mean return, and Sortino, but different max drawdown (2 vs 1). This demonstrates that standard Sortino is permutation-invariant while drawdown-based objectives are genuinely path-dependent.