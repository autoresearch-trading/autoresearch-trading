# Summary of changes
All four claims of Theorem 19 (ApproximationGainVsEstimationCost) have been formalized and proved in Lean 4 in `RequestProject/ApproximationGainVsEstimationCost.lean`. The file builds successfully with no `sorry` and only standard axioms.

**Summary of formalization:**

- **Definitions:** `expectedLoss B V n = B + V/n`, `varianceTerm V n = V/n`, `nCritical B_s B_c V_s V_c = (V_c - V_s)/(B_s - B_c)`.

- **Claim 1** (`claim1_loss_decomposition`): The loss decomposes as bias² + variance term. This holds by definitional unfolding (`rfl`).

- **Claim 2** (`claim2_bias_variance_tradeoff`): H_complex has lower bias but higher variance. Direct from hypotheses.

- **Claim 3** (`claim3_critical_sample_size`): `L_complex(n) < L_simple(n) ↔ n > n_critical`. Proved via algebraic manipulation with `div_lt_iff`, `ring_nf`, and `nlinarith`.

- **Claim 4** (four sub-theorems):
  - `claim4a_critical_formula`: Under the parameterization V_simple = λd, V_complex = λ(d+Δ), n_critical = λΔ/g.
  - `claim4b_critical_formula_ratio`: λΔ/g = λd(Δ/d)/g (algebraic identity).
  - `claim4c_linear_in_Delta`: n_critical grows linearly in Δ (witnessed by constant c = λ/g > 0).
  - `claim4d_linear_in_ratio`: n_critical grows linearly in Δ/d (witnessed by constant c = λd/g > 0).