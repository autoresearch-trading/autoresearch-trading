import Mathlib

/-!
# Theorem 19: ApproximationGainVsEstimationCost

We formalize the bias–variance tradeoff between a simple and a complex hypothesis class.
-/

open Real

/-! ## Claim 1: Loss decomposition

Under the stylized model, the expected loss decomposes as bias² + V/n.
This is definitional: we *define* the loss and variance this way. -/

/-- The expected loss under the bias-variance model. -/
noncomputable def expectedLoss (B V : ℝ) (n : ℝ) : ℝ := B + V / n

/-- The variance term. -/
noncomputable def varianceTerm (V : ℝ) (n : ℝ) : ℝ := V / n

/-- Claim 1: The expected loss decomposes as bias² + variance(H, n). -/
theorem claim1_loss_decomposition (B V n : ℝ) :
    expectedLoss B V n = B + varianceTerm V n := by
  rfl

/-! ## Claim 2: The complex class has lower bias but higher variance. -/

/-- Claim 2: H_complex has lower approximation error but higher variance. -/
theorem claim2_bias_variance_tradeoff
    (B_simple B_complex V_simple V_complex : ℝ)
    (hB : B_complex < B_simple)
    (hV : V_complex > V_simple) :
    B_complex < B_simple ∧ V_complex > V_simple :=
  ⟨hB, hV⟩

/-! ## Claim 3: Critical sample size characterization -/

/-- The critical sample size. -/
noncomputable def nCritical (B_simple B_complex V_simple V_complex : ℝ) : ℝ :=
  (V_complex - V_simple) / (B_simple - B_complex)

/-
PROBLEM
Claim 3: L_complex(n) < L_simple(n) iff n > n_critical.

PROVIDED SOLUTION
Unfold expectedLoss and nCritical. We need to show B_complex + V_complex/n < B_simple + V_simple/n ↔ n > (V_complex - V_simple)/(B_simple - B_complex). Since n > 0 and B_simple - B_complex > 0, multiply through by n and rearrange. The key algebraic step: B_complex + V_complex/n < B_simple + V_simple/n ↔ (V_complex - V_simple)/n < B_simple - B_complex ↔ V_complex - V_simple < n * (B_simple - B_complex) ↔ (V_complex - V_simple)/(B_simple - B_complex) < n. Use field_simp and then manipulate with positivity/linarith.
-/
theorem claim3_critical_sample_size
    (B_simple B_complex V_simple V_complex n : ℝ)
    (hB : B_complex < B_simple)
    (hV : V_complex > V_simple)
    (hn : n > 0) :
    expectedLoss B_complex V_complex n < expectedLoss B_simple V_simple n ↔
    n > nCritical B_simple B_complex V_simple V_complex := by
  norm_num +zetaDelta at *;
  unfold expectedLoss nCritical;
  rw [ div_lt_iff₀ ] <;> ring_nf <;> try linarith;
  constructor <;> intro <;> nlinarith [ mul_inv_cancel₀ hn.ne' ]

/-! ## Claim 4: MLP vs MLP+TCN specialization -/

/-
PROBLEM
Claim 4a: n_critical = λ * Δ / g under the parameterization
    V_simple = λ * d, V_complex = λ * (d + Δ), g = B_simple - B_complex.

PROVIDED SOLUTION
Unfold nCritical. We need (lam*(d+Delta) - lam*d) / (B_simple - B_complex) = lam*Delta/g. The numerator simplifies to lam*Delta, and B_simple - B_complex = g by hg. So it's lam*Delta/g = lam*Delta/g. Use field_simp and ring, or just subst hg and ring_nf after unfolding.
-/
theorem claim4a_critical_formula
    (lam d Delta g B_simple B_complex : ℝ)
    (hd : d > 0) (hDelta : Delta > 0) (hlam : lam > 0)
    (hg : g = B_simple - B_complex)
    (hg_pos : g > 0)
    (hVs : V_simple = lam * d)
    (hVc : V_complex = lam * (d + Delta)) :
    nCritical B_simple B_complex (lam * d) (lam * (d + Delta)) = lam * Delta / g := by
  unfold nCritical; ring; aesop;

/-
PROBLEM
Claim 4b: n_critical = λ * d * (Δ / d) / g.

PROVIDED SOLUTION
This is just algebra: lam * Delta / g = lam * d * (Delta / d) / g because d * (Delta/d) = Delta when d ≠ 0 (which follows from hd : d > 0). Use field_simp and ring.
-/
theorem claim4b_critical_formula_ratio
    (lam d Delta g : ℝ)
    (hd : d > 0) (hDelta : Delta > 0) (hlam : lam > 0)
    (hg_pos : g > 0) :
    lam * Delta / g = lam * d * (Delta / d) / g := by
  rw [ mul_assoc, mul_div_cancel₀ _ hd.ne' ]

/-
PROBLEM
Claim 4c: n_critical grows linearly in Δ (with d, g, λ fixed).

PROVIDED SOLUTION
Take c = lam / g. Then c > 0 since lam > 0 and g > 0. For any Delta > 0, lam * Delta / g = (lam/g) * Delta = c * Delta. Use exact ⟨lam/g, by positivity, fun Delta _ => by ring⟩ or similar.
-/
theorem claim4c_linear_in_Delta
    (lam d g : ℝ)
    (hd : d > 0) (hlam : lam > 0) (hg_pos : g > 0) :
    ∃ c : ℝ, c > 0 ∧ ∀ Delta : ℝ, Delta > 0 →
      lam * Delta / g = c * Delta := by
  exact ⟨ lam / g, div_pos hlam hg_pos, fun Delta hDelta => by ring ⟩

/-
PROBLEM
Claim 4d: n_critical grows linearly in the complexity ratio Δ/d
    (with d, g, λ fixed).

PROVIDED SOLUTION
Take c = lam * d / g. Then c > 0 since lam, d, g > 0. For any Delta > 0, lam * d * (Delta/d) / g = (lam*d/g) * (Delta/d) = c * (Delta/d). Use exact ⟨lam*d/g, by positivity, fun Delta _ => by ring⟩.
-/
theorem claim4d_linear_in_ratio
    (lam d g : ℝ)
    (hd : d > 0) (hlam : lam > 0) (hg_pos : g > 0) :
    ∃ c : ℝ, c > 0 ∧ ∀ Delta : ℝ, Delta > 0 →
      lam * d * (Delta / d) / g = c * (Delta / d) := by
  exact ⟨ lam * d / g, by positivity, fun Delta hDelta => by ring ⟩