# Summary of changes
## Completed Formalization: Optimal Feature Count Under Bias-Variance Tradeoff

All five claims have been formalized in `RequestProject/BiasVarianceTradeoff.lean`. The file compiles with no sorries and all proofs use only standard axioms (`propext`, `Classical.choice`, `Quot.sound`).

### Results Summary

**Claims 1–3: Proved ✓**

1. **Unique minimizer (Claim 1)**: Proved that `k* = (1/(2α)) · log(2αnB₀²/λ)` is the unique minimizer of `L(k) = B₀²·exp(-2αk) + λk/n`, via:
   - `loss_hasDerivAt`: the derivative of L is `-2αB₀²exp(-2αk) + λ/n`
   - `deriv_zero_at_optimalK`: the first-order condition L'(k*) = 0
   - `second_deriv_pos`: the second derivative `4α²B₀²exp(-2αk) > 0` (strict convexity)
   - `optimalK_unique_minimizer`: for all k ≠ k*, L(k*) < L(k)

2. **Logarithmic growth (Claim 2)**: Proved that:
   - `optimalK_eq_log_n`: k* = (1/(2α))·log(n) + constant, showing logarithmic dependence on n
   - `optimalK_strictMono_n`: k* is strictly increasing in n (for positive n)
   - `optimalK_strictAnti_lam`: k* is strictly decreasing in λ (for positive λ)

3. **Monotonicity around k* (Claim 3)**: Proved that:
   - `lossDeriv_neg_below`: L'(k) < 0 for k < k* (bias reduction dominates)
   - `lossDeriv_pos_above`: L'(k) > 0 for k > k* (variance increase dominates)

**Claim 4: DISPROVED ✗**

The claim that k* ∈ [10, 20] with n=250000, B₀=0.30, α=0.10, λ=0.005 is **false**. With these parameters:
- 2αnB₀²/λ = 900,000
- k* = 5·ln(900000) ≈ 68.55

This is formally proved as `claim4_disproof : 20 < optimalK 0.30 0.10 0.005 250000`. The original false claim is preserved in a comment.

**Claim 5: DISPROVED ✗**

The claim that relative efficiency RE(k) = L(k*)/L(k) is symmetric around k* on a log scale is **false**. The loss function L is NOT symmetric around its minimum because:
- The third derivative L'''(k) = -8α³B₀²exp(-2αk) < 0 everywhere (proved as `third_deriv_neg`), while symmetry would require all odd derivatives at k* to vanish.
- More precisely, L(k*+u) < L(k*-u) for all u > 0 (proved as `claim5_disproof`): the exponential bias term decays faster above k* than it grows below k*, creating a systematic asymmetry.

### File Structure
- **Core definitions**: `lossFunction`, `lossDeriv`, `optimalK`
- **15 formally verified theorems** covering all claims
- **Documented disproofs** with the original false claims preserved in comments