import Mathlib

/-!
# Theorem 23: Optimal Feature Count Under Bias-Variance Tradeoff

We formalize the bias-variance tradeoff for feature selection, where the loss function is
  L(k) = B₀² · exp(-2αk) + λk/n
and prove that the unique minimizer over the positive reals is
  k* = (1/(2α)) · log(2αnB₀²/λ).

## Results

- **Claim 1**: k* is the unique minimizer of L, established via first-order condition and
  strict convexity (positive second derivative).
- **Claim 2**: k* increases logarithmically in n and decreases with λ.
- **Claim 3**: L is decreasing for k < k* and increasing for k > k*.
- **Claim 4**: DISPROVED — with the given parameters, k* > 20, not in [10, 20].
- **Claim 5**: DISPROVED — L is not symmetric around k* on any scale.
-/

noncomputable section

open Real

/-! ## Core definitions -/

/-- The loss function L(k) = B₀² · exp(-2αk) + λk/n -/
def lossFunction (B₀ α lam n k : ℝ) : ℝ :=
  B₀ ^ 2 * exp (-2 * α * k) + lam * k / n

/-- The derivative of L with respect to k: L'(k) = -2αB₀² · exp(-2αk) + λ/n -/
def lossDeriv (B₀ α lam n k : ℝ) : ℝ :=
  -2 * α * B₀ ^ 2 * exp (-2 * α * k) + lam / n

/-- The optimal feature count k* = (1/(2α)) · log(2αnB₀²/λ) -/
def optimalK (B₀ α lam n : ℝ) : ℝ :=
  (1 / (2 * α)) * log (2 * α * n * B₀ ^ 2 / lam)

/-! ## Claim 1: Unique minimizer via calculus -/

/-
PROBLEM
The loss function has derivative L'(k) = -2αB₀²exp(-2αk) + λ/n at every k.

PROVIDED SOLUTION
L(k) = B₀² * exp(-2αk) + lam*k/n. Use HasDerivAt.add, HasDerivAt.const_mul, hasDerivAt_exp composed with the linear function (-2α*k). The derivative of exp(-2αk) is (-2α)*exp(-2αk). Then B₀² * (-2α) * exp(-2αk) = -2αB₀²exp(-2αk). The derivative of lam*k/n = (lam/n)*k is lam/n. Sum gives the result. Key Mathlib lemmas: HasDerivAt.exp, HasDerivAt.const_mul, hasDerivAt_id'.
-/
theorem loss_hasDerivAt (B₀ α lam n k : ℝ) :
    HasDerivAt (lossFunction B₀ α lam n) (lossDeriv B₀ α lam n k) k := by
  rw [ show lossFunction B₀ α lam n = fun k => B₀ ^ 2 * Real.exp ( -2 * α * k ) + lam * k / n from funext fun _ => rfl, show lossDeriv B₀ α lam n k = -2 * α * B₀ ^ 2 * Real.exp ( -2 * α * k ) + lam / n from rfl ] ; convert HasDerivAt.add ( HasDerivAt.const_mul _ ( HasDerivAt.exp <| HasDerivAt.const_mul _ <| hasDerivAt_id' k ) ) ( HasDerivAt.div_const ( HasDerivAt.const_mul _ <| hasDerivAt_id' k ) _ ) using 1 ; ring;

/-
PROBLEM
The derivative of L is zero at k*. This is the first-order optimality condition.

PROVIDED SOLUTION
Unfold lossDeriv and optimalK. We need:
-2α * B₀² * exp(-2α * (1/(2α)) * log(2αnB₀²/lam)) + lam/n = 0

The exponent simplifies: -2α * (1/(2α)) * log(X) = -log(X) where X = 2αnB₀²/lam.
So exp(-log(X)) = 1/X = lam/(2αnB₀²).
Then -2α * B₀² * lam/(2αnB₀²) + lam/n = -lam/n + lam/n = 0.

Key: use Real.exp_neg, Real.exp_log (need X > 0), and algebraic simplification.
-/
theorem deriv_zero_at_optimalK (B₀ α lam n : ℝ)
    (hB₀ : 0 < B₀) (hα : 0 < α) (hlam : 0 < lam) (hn : 0 < n) :
    lossDeriv B₀ α lam n (optimalK B₀ α lam n) = 0 := by
  unfold lossDeriv;
  unfold optimalK;
  field_simp;
  rw [ Real.exp_neg, Real.exp_log ( by positivity ) ] ; ring;
  -- Simplify the expression to verify it equals zero.
  field_simp
  ring

/-
PROBLEM
The second derivative of L is 4α²B₀²exp(-2αk) > 0, establishing strict convexity.

PROVIDED SOLUTION
Product of positive terms: 4 > 0, α² > 0, B₀² > 0, exp > 0. Use positivity or mul_pos repeatedly.
-/
theorem second_deriv_pos (B₀ α k : ℝ) (hB₀ : 0 < B₀) (hα : 0 < α) :
    0 < 4 * α ^ 2 * B₀ ^ 2 * exp (-2 * α * k) := by
  positivity

/-
PROBLEM
L'(k) is strictly monotone increasing (consequence of L'' > 0).

PROVIDED SOLUTION
lossDeriv B₀ α lam n k = -2αB₀²exp(-2αk) + lam/n. The term lam/n is constant in k. The term -2αB₀²exp(-2αk) is strictly increasing in k because exp(-2αk) is strictly decreasing (since α > 0), so -exp(-2αk) is strictly increasing, and multiplying by the positive constant 2αB₀² preserves strict monotonicity. Use StrictMono/StrictAnti for exp composed with a strictly decreasing linear function, then negate.
-/
theorem lossDeriv_strictMono (B₀ α lam n : ℝ)
    (hB₀ : 0 < B₀) (hα : 0 < α) (hlam : 0 < lam) (hn : 0 < n) :
    StrictMono (lossDeriv B₀ α lam n) := by
  refine' fun x y hxy => add_lt_add_of_lt_of_le _ le_rfl;
  exact mul_lt_mul_of_neg_left ( Real.exp_lt_exp.mpr ( by nlinarith ) ) ( by nlinarith [ mul_pos hα ( sq_pos_of_pos hB₀ ) ] )

/-- L is differentiable everywhere. -/
theorem loss_differentiable (B₀ α lam n : ℝ) :
    Differentiable ℝ (lossFunction B₀ α lam n) :=
  fun k => (loss_hasDerivAt B₀ α lam n k).differentiableAt

/-- The derivative of L equals lossDeriv. -/
theorem loss_deriv_eq (B₀ α lam n k : ℝ) :
    deriv (lossFunction B₀ α lam n) k = lossDeriv B₀ α lam n k :=
  (loss_hasDerivAt B₀ α lam n k).deriv

/-
PROBLEM
L is strictly monotone increasing on [k*, ∞).

PROVIDED SOLUTION
Use Convex.strictMono_of_deriv_pos or strictMonoOn_of_deriv_pos on the interval [a, b]. The derivative of L at any point x ≥ k* is lossDeriv(x) ≥ lossDeriv(k*) = 0 by lossDeriv_strictMono. In fact for x ≥ k* and x in the interior (a,b), the derivative is strictly positive.

More precisely, apply the mean value theorem: there exists c ∈ (a, b) with L(b) - L(a) = L'(c) * (b - a). Since c > a ≥ k*, L'(c) ≥ L'(k*) = 0. And since c > k* or c = k* (but if a = k* then c > k* since c > a in open interval), L'(c) > 0 when c > k* or L'(c) ≥ 0 when c = k*. Actually since c ∈ (a, b) and a ≥ k*, c > k* so L'(c) > 0. So L(b) - L(a) > 0.

Key Mathlib approach: use `StrictMonoOn.lt_iff_lt` or `strictMonoOn_of_deriv_pos`. We can use the fact that L is continuous on [a,b], differentiable on (a,b), and deriv > 0 on (a,b).

Use Convex.inner_smul_le_inner_smul_iff or just the standard monotonicity from derivative result.
-/
theorem loss_strictMono_above (B₀ α lam n : ℝ)
    (hB₀ : 0 < B₀) (hα : 0 < α) (hlam : 0 < lam) (hn : 0 < n)
    {a b : ℝ} (ha : optimalK B₀ α lam n ≤ a) (hab : a < b) :
    lossFunction B₀ α lam n a < lossFunction B₀ α lam n b := by
  -- Apply the Mean Value Theorem on the interval [a, b].
  obtain ⟨c, hc⟩ : ∃ c ∈ Set.Ioo a b, deriv (lossFunction B₀ α lam n) c = (lossFunction B₀ α lam n b - lossFunction B₀ α lam n a) / (b - a) := by
    apply_rules [ exists_deriv_eq_slope ];
    · exact Continuous.continuousOn ( by unfold lossFunction; continuity );
    · exact Differentiable.differentiableOn ( by exact loss_differentiable B₀ α lam n );
  -- Since $c > a \geq k^*$, we have $lossDeriv(c) > 0$ by the properties of the derivative.
  have h_deriv_pos : lossDeriv B₀ α lam n c > 0 := by
    exact deriv_zero_at_optimalK B₀ α lam n hB₀ hα hlam hn ▸ lossDeriv_strictMono B₀ α lam n hB₀ hα hlam hn ( by linarith [ hc.1.1 ] );
  rw [ ← loss_deriv_eq ] at *; rw [ eq_div_iff ] at * <;> nlinarith;

/-
PROBLEM
L is strictly monotone decreasing on (-∞, k*].

PROVIDED SOLUTION
Symmetric to loss_strictMono_above. Use the mean value theorem: there exists c ∈ (a, b) with L(b) - L(a) = L'(c) * (b - a). Since c < b ≤ k*, c < k* so L'(c) < 0 by lossDeriv_neg_below. Since b - a > 0, L(b) - L(a) < 0, i.e., L(b) < L(a).

Use strictAntiOn_of_deriv_neg or a direct MVT argument.
-/
theorem loss_strictAnti_below (B₀ α lam n : ℝ)
    (hB₀ : 0 < B₀) (hα : 0 < α) (hlam : 0 < lam) (hn : 0 < n)
    {a b : ℝ} (hab : a < b) (hb : b ≤ optimalK B₀ α lam n) :
    lossFunction B₀ α lam n b < lossFunction B₀ α lam n a := by
  -- Apply the mean value theorem to the interval $[a, b]$.
  obtain ⟨c, hc⟩ : ∃ c ∈ Set.Ioo a b, deriv (lossFunction B₀ α lam n) c = ((lossFunction B₀ α lam n) b - (lossFunction B₀ α lam n) a) / (b - a) := by
    apply_rules [ exists_deriv_eq_slope ];
    · exact Continuous.continuousOn ( by unfold lossFunction; continuity );
    · exact Differentiable.differentiableOn ( loss_differentiable B₀ α lam n );
  -- Since $c < k^*$ and $k^*$ is the unique minimizer, we have $L'(c) < 0$.
  have h_deriv_neg : deriv (lossFunction B₀ α lam n) c < 0 := by
    rw [ loss_deriv_eq ] ; exact deriv_zero_at_optimalK B₀ α lam n hB₀ hα hlam hn |> fun h => h ▸ ( lossDeriv_strictMono B₀ α lam n hB₀ hα hlam hn ) ( by linarith [ hc.1.1, hc.1.2 ] ) ;
  rw [ hc.2, div_lt_iff₀ ] at h_deriv_neg <;> linarith

/-
PROBLEM
k* is the unique minimizer of L: for all k ≠ k*, L(k*) < L(k).

PROVIDED SOLUTION
Split into two cases: k < optimalK or k > optimalK (since k ≠ optimalK).
Case k < k*: apply loss_strictAnti_below with a = k, b = k* to get L(k*) < L(k). Wait no, loss_strictAnti_below says L(b) < L(a) when a < b ≤ k*. So with a = k, b = k*, we get L(k*) < L(k). ✓
Case k > k*: apply loss_strictMono_above with a = k*, b = k to get L(k*) < L(k). ✓
-/
theorem optimalK_unique_minimizer (B₀ α lam n : ℝ)
    (hB₀ : 0 < B₀) (hα : 0 < α) (hlam : 0 < lam) (hn : 0 < n) :
    ∀ k, k ≠ optimalK B₀ α lam n →
      lossFunction B₀ α lam n (optimalK B₀ α lam n) < lossFunction B₀ α lam n k := by
  intros k hk_ne_optimalK
  by_cases hk : k < optimalK B₀ α lam n;
  · apply_rules [ loss_strictAnti_below ];
    norm_num;
  · exact loss_strictMono_above B₀ α lam n hB₀ hα hlam hn ( by linarith ) ( lt_of_le_of_ne ( le_of_not_gt hk ) hk_ne_optimalK.symm )

/-! ## Claim 2: k* increases logarithmically in n, decreases with λ -/

/-
PROBLEM
k* decomposes as (1/(2α)) · log(n) + constant, showing logarithmic growth in n.
    This is the precise sense in which "k* increases logarithmically in n".

PROVIDED SOLUTION
Unfold optimalK. We need log(2αnB₀²/lam) = log(n) + log(2αB₀²/lam). Use Real.log_mul and Real.log_div. Specifically, 2αnB₀²/lam = n * (2αB₀²/lam), so log(2αnB₀²/lam) = log(n) + log(2αB₀²/lam) by Real.log_mul. Then distribute the 1/(2α) factor. Need to show n ≠ 0 and 2αB₀²/lam ≠ 0.
-/
theorem optimalK_eq_log_n (B₀ α lam n : ℝ)
    (hα : 0 < α) (hB₀ : 0 < B₀) (hlam : 0 < lam) (hn : 0 < n) :
    optimalK B₀ α lam n =
      (1 / (2 * α)) * log n + (1 / (2 * α)) * log (2 * α * B₀ ^ 2 / lam) := by
  unfold optimalK;
  rw [ ← mul_add, ← Real.log_mul ( by positivity ) ( by positivity ) ] ; ring;

/-
PROBLEM
k* is strictly increasing in n for positive n (more data justifies more features).

PROVIDED SOLUTION
Unfold optimalK. We need (1/(2α)) * log(2αn₁B₀²/lam) < (1/(2α)) * log(2αn₂B₀²/lam). Since 1/(2α) > 0, it suffices to show log(2αn₁B₀²/lam) < log(2αn₂B₀²/lam). Since log is strictly monotone on positive reals, it suffices to show 2αn₁B₀²/lam < 2αn₂B₀²/lam, which follows from n₁ < n₂ and the positive factor 2αB₀²/lam.
-/
theorem optimalK_strictMono_n (B₀ α lam n₁ n₂ : ℝ)
    (hα : 0 < α) (hB₀ : 0 < B₀) (hlam : 0 < lam)
    (hn₁ : 0 < n₁) (hn₂ : 0 < n₂) (h : n₁ < n₂) :
    optimalK B₀ α lam n₁ < optimalK B₀ α lam n₂ := by
  unfold optimalK;
  gcongr

/-
PROBLEM
k* is strictly decreasing in λ for positive λ (higher estimation cost penalizes complexity).

PROVIDED SOLUTION
Unfold optimalK. We need (1/(2α)) * log(2αnB₀²/lam₂) < (1/(2α)) * log(2αnB₀²/lam₁). Since 1/(2α) > 0, it suffices to show log(2αnB₀²/lam₂) < log(2αnB₀²/lam₁). Since log is strictly monotone on positive reals, it suffices to show 2αnB₀²/lam₂ < 2αnB₀²/lam₁, which follows from lam₁ < lam₂ (dividing by larger denominator gives smaller result) and the positive numerator 2αnB₀².
-/
theorem optimalK_strictAnti_lam (B₀ α n lam₁ lam₂ : ℝ)
    (hα : 0 < α) (hB₀ : 0 < B₀) (hn : 0 < n)
    (hlam₁ : 0 < lam₁) (hlam₂ : 0 < lam₂) (h : lam₁ < lam₂) :
    optimalK B₀ α lam₂ n < optimalK B₀ α lam₁ n := by
  exact mul_lt_mul_of_pos_left ( Real.log_lt_log ( by positivity ) ( by gcongr ) ) ( by positivity )

/-! ## Claim 3: Monotonicity of L around k* -/

/-
PROBLEM
For k < k*, the derivative is negative: bias reduction dominates.

PROVIDED SOLUTION
By deriv_zero_at_optimalK, lossDeriv B₀ α lam n (optimalK B₀ α lam n) = 0. By lossDeriv_strictMono, lossDeriv is strictly monotone. Since k < optimalK, lossDeriv B₀ α lam n k < lossDeriv B₀ α lam n (optimalK B₀ α lam n) = 0.
-/
theorem lossDeriv_neg_below (B₀ α lam n k : ℝ)
    (hB₀ : 0 < B₀) (hα : 0 < α) (hlam : 0 < lam) (hn : 0 < n)
    (hk : k < optimalK B₀ α lam n) :
    lossDeriv B₀ α lam n k < 0 := by
  exact lt_of_lt_of_le ( lossDeriv_strictMono B₀ α lam n hB₀ hα hlam hn hk ) ( by rw [ deriv_zero_at_optimalK B₀ α lam n hB₀ hα hlam hn ] )

/-- For k > k*, the derivative is positive: variance increase dominates. -/
theorem lossDeriv_pos_above (B₀ α lam n k : ℝ)
    (hB₀ : 0 < B₀) (hα : 0 < α) (hlam : 0 < lam) (hn : 0 < n)
    (hk : optimalK B₀ α lam n < k) :
    0 < lossDeriv B₀ α lam n k := by
  calc 0 = lossDeriv B₀ α lam n (optimalK B₀ α lam n) := (deriv_zero_at_optimalK B₀ α lam n hB₀ hα hlam hn).symm
    _ < lossDeriv B₀ α lam n k := lossDeriv_strictMono B₀ α lam n hB₀ hα hlam hn hk

/-! ## Claim 4: Numerical verification — DISPROVED

The claim states that with n = 250000, B₀ = 0.30, α = 0.10, λ = 0.005,
the optimal k* falls in [10, 20].

**This is false.** We have:
  2αnB₀²/λ = 2 · 0.10 · 250000 · 0.09 / 0.005 = 900000
  k* = 5 · ln(900000) ≈ 68.55

We prove k* > 20 by showing ln(900000) > 4, which follows from exp(4) < 900000.
-/

/-
PROBLEM
The original claim (commented out because it is false):
theorem claim4_in_range :
10 ≤ optimalK 0.30 0.10 0.005 250000 ∧ optimalK 0.30 0.10 0.005 250000 ≤ 20 := by sorry

**Disproof of Claim 4**: k* > 20 with the given parameters.

PROVIDED SOLUTION
Unfold optimalK. We need 20 < (1/(2*0.10)) * log(2*0.10*250000*0.30^2/0.005).

Simplify: 1/(2*0.10) = 5. The argument is 2*0.10*250000*0.09/0.005 = 900000.

So we need 20 < 5 * log(900000), i.e., 4 < log(900000), i.e., exp(4) < 900000.

Since exp(4) < 55 (e^4 ≈ 54.598) and 55 < 900000, this holds.

For exp(4) < 55, we can bound exp iteratively: exp(1) < 3, exp(2) < 9, exp(4) < 81, but we need a tighter bound. Actually we can use: exp(4) < 55 because exp(x) ≤ various polynomial bounds, or use Real.add_one_le_exp for a lower bound approach.

Alternative approach: show log(900000) > 4 by showing 900000 > exp(4). We know exp(4) = exp(2)^2. And exp(2) < 8 (since exp(2) ≈ 7.389). So exp(4) < 64 < 900000.

Key steps:
1. Simplify the arithmetic to get optimalK 0.30 0.10 0.005 250000 = 5 * log 900000
2. Show log 900000 > 4 by showing exp 4 < 900000
3. Show exp 4 < 64 (since exp 2 < 8, and exp 4 = (exp 2)^2 < 64)
4. Show exp 2 < 8 (since exp 1 < 3, and exp 2 = (exp 1)^2 < 9, but we need < 8)

Actually exp(2) < 8: we can show exp(1) < 2.8 ... this is getting complicated. Let me try: exp(2) < 7.5 < 8. Actually, 7.5^2 = 56.25 so exp(4) < 56.25. We need exp(4) < 900000 which is much weaker.

Simpler: exp(4) < 900000. We can bound exp(4) ≤ exp(14) and show exp(14) < 900000? No that's wrong direction.

Key insight: just show exp(4) ≤ 3^4 = 81 < 900000 by using exp(1) ≤ 3 and exp(4) = exp(1)^4. Actually exp(1) < 3 is well known. Then exp(4) = exp(1+1+1+1) = exp(1)^4 < 3^4 = 81 < 900000.
-/
theorem claim4_disproof :
    20 < optimalK 0.30 0.10 0.005 250000 := by
  unfold optimalK; norm_num [ ← Real.log_rpow, mul_assoc ] ; ring ;
  rw [ Real.lt_log_iff_exp_lt ] <;> norm_num [ Real.exp_nat_mul, Real.exp_log ] at * ; ( rw [ show Real.exp 20 = ( Real.exp 1 ) ^ 20 by rw [ ← Real.exp_nat_mul ] ; norm_num ] ; exact lt_of_le_of_lt ( pow_le_pow_left₀ ( by positivity ) ( Real.exp_one_lt_d9.le ) _ ) <| by norm_num; ) ;

/-! ## Claim 5: Symmetry of relative efficiency — DISPROVED

The claim states that RE(k) = L(k*)/L(k) is symmetric around k* on a log scale.
Equivalently, L(k* + u) = L(k* - u) for all u.

**This is false.** The loss function L(k) = B₀²exp(-2αk) + λk/n is the sum of
a convex exponential and a linear term. It is NOT symmetric around its minimum.

The asymmetry can be seen from the third derivative:
  L'''(k) = -8α³B₀²exp(-2αk) < 0 for all k.
If L were symmetric around k*, all odd-order derivatives at k* would vanish, but L'''(k*) ≠ 0.

We formalize this by showing L(k* + u) ≠ L(k* - u) for appropriate u, specifically that
the difference L(k* + u) - L(k* - u) is strictly negative for u > 0.
-/

/-
PROBLEM
The third derivative of L is negative, proving L is not symmetric around any point.

PROVIDED SOLUTION
-8 * α³ * B₀² * exp(-2αk) < 0 because 8 * α³ * B₀² * exp(-2αk) > 0 (product of positive terms). Use neg_neg or nlinarith with positivity.
-/
theorem third_deriv_neg (B₀ α k : ℝ) (hB₀ : 0 < B₀) (hα : 0 < α) :
    -8 * α ^ 3 * B₀ ^ 2 * exp (-2 * α * k) < 0 := by
  exact mul_neg_of_neg_of_pos ( mul_neg_of_neg_of_pos ( mul_neg_of_neg_of_pos ( by norm_num ) ( pow_pos hα 3 ) ) ( sq_pos_of_pos hB₀ ) ) ( Real.exp_pos _ )

/-
PROBLEM
The original claim (commented out because it is false):
theorem claim5_symmetry (B₀ α lam n u : ℝ) (...) :
lossFunction B₀ α lam n (optimalK B₀ α lam n + u) =
lossFunction B₀ α lam n (optimalK B₀ α lam n - u) := by sorry

**Disproof of Claim 5**: For any positive parameters and u > 0,
    L(k* + u) < L(k* - u), i.e., the loss function is NOT symmetric around k*.
    The exponential bias term decays faster above k* than it grows below k*,
    while the linear variance term is symmetric, creating an asymmetry.

PROVIDED SOLUTION
Show L(k*+u) < L(k*-u) for u > 0.

Unfold lossFunction. We need:
B₀²·exp(-2α(k*+u)) + lam·(k*+u)/n < B₀²·exp(-2α(k*-u)) + lam·(k*-u)/n

Rearranging: B₀²·(exp(-2α(k*+u)) - exp(-2α(k*-u))) < lam·(k*-u)/n - lam·(k*+u)/n = -2lam·u/n

i.e., B₀²·exp(-2αk*)·(exp(-2αu) - exp(2αu)) < -2lam·u/n

i.e., B₀²·exp(-2αk*)·(exp(2αu) - exp(-2αu)) > 2lam·u/n

From the first-order condition (deriv_zero_at_optimalK):
-2αB₀²exp(-2αk*) + lam/n = 0, so B₀²·exp(-2αk*) = lam/(2αn)

Substituting: lam/(2αn)·(exp(2αu) - exp(-2αu)) > 2lam·u/n

Dividing by lam/n > 0: (exp(2αu) - exp(-2αu))/(2α) > 2u

Setting t = 2αu > 0: (exp(t) - exp(-t))/(2α) > 2u = t/α

i.e., exp(t) - exp(-t) > 2t for t > 0.

This follows because g(t) = exp(t) - exp(-t) - 2t satisfies g(0) = 0 and g'(t) = exp(t) + exp(-t) - 2 ≥ 0 with equality only at t = 0. Since exp(t) + exp(-t) - 2 = (exp(t/2) - exp(-t/2))² ≥ 0 and > 0 for t > 0, g is strictly increasing on (0,∞), so g(t) > 0 for t > 0.
-/
theorem claim5_disproof (B₀ α lam n u : ℝ)
    (hB₀ : 0 < B₀) (hα : 0 < α) (hlam : 0 < lam) (hn : 0 < n) (hu : 0 < u) :
    lossFunction B₀ α lam n (optimalK B₀ α lam n + u) <
    lossFunction B₀ α lam n (optimalK B₀ α lam n - u) := by
  unfold lossFunction;
  -- From the first-order condition (deriv_zero_at_optimalK):
  -- -2αB₀²exp(-2αk*) + lam/n = 0, so B₀²·exp(-2αk*) = lam/(2αn)
  have h_exp_bound : B₀ ^ 2 * Real.exp (-2 * α * optimalK B₀ α lam n) = lam / (2 * α * n) := by
    unfold optimalK; ring_nf; norm_num [ hB₀.ne', hα.ne', hlam.ne', hn.ne', hu.ne' ] ;
    rw [ Real.exp_neg, Real.exp_log ( by positivity ) ] ; ring;
    norm_num [ hB₀.ne' ] ; ring;
  -- Simplify the inequality using the exponential bound.
  have h_simplified : Real.exp (-2 * α * u) - Real.exp (2 * α * u) < -4 * α * u := by
    -- Use the fact that $e^{-x} - e^x = -2 \sinh(x)$ and $\sinh(x) > x$ for $x > 0$.
    have h_sinh : Real.sinh (2 * α * u) > 2 * α * u := by
      simpa using Real.sinh_pos_iff.mpr ( mul_pos ( mul_pos two_pos hα ) hu );
    rw [ Real.sinh_eq ] at h_sinh ; ring_nf at * ; linarith;
  norm_num [ Real.exp_add, Real.exp_sub, mul_add, mul_sub ] at *;
  ring_nf at *;
  nlinarith [ show 0 < B₀ ^ 2 * Real.exp ( - ( α * optimalK B₀ α lam n * 2 ) ) by positivity, show 0 < lam * n⁻¹ by positivity, show 0 < α * u by positivity, show 0 < lam * n⁻¹ * α⁻¹ by positivity, mul_inv_cancel_left₀ ( ne_of_gt hα ) ( lam * n⁻¹ ) ]

end