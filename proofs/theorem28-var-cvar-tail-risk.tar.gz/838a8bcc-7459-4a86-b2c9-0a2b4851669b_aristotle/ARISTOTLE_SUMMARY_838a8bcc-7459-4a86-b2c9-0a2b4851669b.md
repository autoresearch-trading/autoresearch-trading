# Summary of changes
Successfully formalized and proved all parts of Theorem 27 (Sharpe, Sortino, and Calmar Ratio Relationships) in `RequestProject/Theorem27.lean`. All proofs compile without `sorry` and use only standard axioms.

## What was proved:

### Part A: Sharpe-Sortino Relationship
- **`min_sq_le_deviation_sq`**: Pointwise inequality `min(x,0)² ≤ (x-μ)²` when `μ ≥ 0`
- **`tddSq_le_variance`**: TDD² ≤ σ² when mean return μ ≥ 0
- **`tdd_le_stdDev`**: TDD ≤ σ when μ ≥ 0, hence Sortino ≥ Sharpe for profitable strategies

### Part B: Permutation Invariance
- **`sum_perm_invariant`**, **`meanReturn_perm_invariant`**, **`variance_perm_invariant`**, **`tddSq_perm_invariant`**: Sharpe and Sortino ratios are permutation-invariant (they depend only on the multiset of returns)
- **`calmar_not_perm_invariant`**: Concrete counterexample showing [1, -1, -1] and [-1, 1, -1] have different maximum drawdowns (2 vs 1), proving Calmar ratio is NOT permutation-invariant (verified by `native_decide`)

### Part C: Omega-PF Equivalence
- **`omega_eq_profitFactor`**: Omega ratio (threshold 0) equals Profit Factor (definitional)
- **`max_sub_max_neg`**: Key identity max(x,0) - max(-x,0) = x
- **`grossWins_sub_grossLosses`**: ∑ max(Rᵢ,0) - ∑ max(-Rᵢ,0) = ∑ Rᵢ
- **`omega_gt_one_iff_positive_sum`**: Omega > 1 ⟺ ∑ Rᵢ > 0 (positive mean return)

### Part D: Cross-Metric Consistency
- **`implied_sharpe_approx`**: Under normality, Sharpe ≈ Sortino/√2 ≈ 0.24/√2 ∈ (0.16, 0.18), verified numerically