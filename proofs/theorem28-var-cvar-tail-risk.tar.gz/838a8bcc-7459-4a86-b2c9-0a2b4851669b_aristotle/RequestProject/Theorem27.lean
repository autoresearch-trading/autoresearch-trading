import Mathlib

/-!
# Theorem 27: Sharpe, Sortino, and Calmar Ratio Relationships

We formalize key relationships between financial performance ratios:
- Part A: TDD ≤ σ when μ ≥ 0, hence Sortino ≥ Sharpe
- Part C: Omega ratio equals Profit Factor; Omega > 1 iff μ > 0
- Part B: Sharpe/Sortino are permutation-invariant; Calmar is not
-/

open Finset BigOperators

noncomputable section

variable {N : ℕ} (R : Fin N → ℝ)

/-- Mean return: μ = (1/N) * ∑ Rᵢ -/
def meanReturn : ℝ := (1 / N) * ∑ i, R i

/-- Variance (population): σ² = (1/N) * ∑ (Rᵢ - μ)² -/
def variance : ℝ := (1 / N) * ∑ i, (R i - meanReturn R) ^ 2

/-- Standard deviation: σ = √(variance) -/
def stdDev : ℝ := Real.sqrt (variance R)

/-- Target downside deviation squared: TDD² = (1/N) * ∑ min(Rᵢ, 0)² -/
def tddSq : ℝ := (1 / N) * ∑ i, (min (R i) 0) ^ 2

/-- Target downside deviation: TDD = √(TDD²) -/
def tdd : ℝ := Real.sqrt (tddSq R)

/-- Gross wins: ∑ max(Rᵢ, 0) -/
def grossWins : ℝ := ∑ i, max (R i) 0

/-- Gross losses: ∑ max(-Rᵢ, 0) -/
def grossLosses : ℝ := ∑ i, max (-(R i)) 0

/-- Profit factor: PF = grossWins / grossLosses -/
def profitFactor : ℝ := grossWins R / grossLosses R

/-- Omega ratio (at threshold 0): Omega = grossWins / grossLosses -/
def omegaRatio : ℝ := grossWins R / grossLosses R

/-! ## Part A: TDD ≤ σ when μ ≥ 0 -/

/-
PROBLEM
Key pointwise lemma: min(x, 0)² ≤ (x - μ)² when μ ≥ 0.
    For x ≥ 0: min(x,0)² = 0 ≤ (x-μ)².
    For x < 0: min(x,0)² = x² ≤ x² - 2μx + μ² = (x-μ)² since -2μx ≥ 0.

PROVIDED SOLUTION
Case split on whether x ≥ 0 or x < 0. If x ≥ 0: min(x,0) = 0, so LHS = 0 ≤ (x-mu)². If x < 0: min(x,0) = x, so LHS = x². RHS = (x-mu)² = x² - 2*mu*x + mu². Since mu ≥ 0 and x < 0, -2*mu*x ≥ 0 and mu² ≥ 0, so RHS ≥ x² = LHS.
-/
theorem min_sq_le_deviation_sq (x mu : ℝ) (hmu : 0 ≤ mu) :
    (min x 0) ^ 2 ≤ (x - mu) ^ 2 := by
      cases le_total x 0 <;> simp +decide [ * ] <;> nlinarith [ sq_nonneg ( x - mu ) ] ;

/-
PROBLEM
TDD² ≤ σ² when mean return μ ≥ 0.
    Follows from pointwise inequality summed over all returns.

PROVIDED SOLUTION
Unfold tddSq and variance. Both are (1/N) * sum. Since 1/N ≥ 0 (from hN), it suffices to show ∑ min(R i, 0)² ≤ ∑ (R i - meanReturn R)². This follows from the pointwise inequality min_sq_le_deviation_sq applied with mu = meanReturn R and hmu.
-/
theorem tddSq_le_variance (hN : 0 < (N : ℝ)) (hmu : 0 ≤ meanReturn R) :
    tddSq R ≤ variance R := by
      exact mul_le_mul_of_nonneg_left ( Finset.sum_le_sum fun i _ => by cases min_cases ( R i ) 0 <;> nlinarith ) ( by positivity )

/-
PROBLEM
TDD ≤ σ when μ ≥ 0. Consequence of TDD² ≤ σ².

PROVIDED SOLUTION
Unfold tdd and stdDev. Apply Real.sqrt_le_sqrt to tddSq_le_variance.
-/
theorem tdd_le_stdDev (hN : 0 < (N : ℝ)) (hmu : 0 ≤ meanReturn R) :
    tdd R ≤ stdDev R := by
      exact Real.sqrt_le_sqrt <| tddSq_le_variance R hN hmu

/-! ## Part C: Omega-PF Equivalence -/

/-- Omega ratio equals profit factor — they are definitionally the same quantity. -/
theorem omega_eq_profitFactor : omegaRatio R = profitFactor R := rfl

/-
PROBLEM
Key identity: max(x, 0) - max(-x, 0) = x for all x ∈ ℝ.

PROVIDED SOLUTION
Case split on x ≥ 0 vs x < 0. If x ≥ 0: max(x,0) = x, max(-x,0) = 0, so x - 0 = x. If x < 0: max(x,0) = 0, max(-x,0) = -x, so 0 - (-x) = x. Use `by rcases le_or_lt 0 x with h|h <;> simp [h]`.
-/
theorem max_sub_max_neg (x : ℝ) : max x 0 - max (-x) 0 = x := by
  grind +splitIndPred

/-
PROBLEM
Sum of max(Rᵢ, 0) - sum of max(-Rᵢ, 0) = sum of Rᵢ.

PROVIDED SOLUTION
Unfold grossWins and grossLosses. Use Finset.sum_sub_distrib to get ∑(max(Ri,0) - max(-Ri,0)). Then apply max_sub_max_neg pointwise via congr/funext to get ∑ R i.
-/
theorem grossWins_sub_grossLosses :
    grossWins R - grossLosses R = ∑ i, R i := by
      unfold grossWins grossLosses; rw [ ← Finset.sum_sub_distrib ] ; exact Finset.sum_congr rfl fun _ _ => by cases max_cases ( R _ ) 0 <;> cases max_cases ( -R _ ) 0 <;> linarith;

/-
PROBLEM
Omega > 1 iff mean return > 0 (assuming positive gross losses).
    Since Omega = GW/GL, Omega > 1 iff GW > GL iff ∑Rᵢ > 0 iff μ > 0.

PROVIDED SOLUTION
Unfold omegaRatio and grossWins/grossLosses. We have 1 < GW/GL iff GL < GW (since GL > 0). And GW - GL = ∑ R i by grossWins_sub_grossLosses. So GW > GL iff GW - GL > 0 iff ∑ R i > 0.
-/
theorem omega_gt_one_iff_positive_sum (hGL : 0 < grossLosses R) :
    1 < omegaRatio R ↔ 0 < ∑ i, R i := by
      rw [ show omegaRatio R = grossWins R / grossLosses R from ?_ ];
      · rw [ lt_div_iff₀ ];
        · rw [ ← grossWins_sub_grossLosses ] ; constructor <;> intro <;> linarith;
        · assumption;
      · rfl

/-! ## Part B: Permutation Invariance -/

/-
PROBLEM
Sum is invariant under permutation of function values.

PROVIDED SOLUTION
Use Equiv.sum_comp or Fintype.sum_equiv for permutations of Fin N. The key lemma is `Equiv.Perm.sum_comp` or `Finset.sum_equiv`.
-/
theorem sum_perm_invariant (e : Equiv.Perm (Fin N)) :
    ∑ i, R (e i) = ∑ i, R i := by
      exact Equiv.sum_comp e R

/-
PROBLEM
Mean is invariant under permutation of returns.

PROVIDED SOLUTION
Unfold meanReturn, show ∑ i, (R ∘ e) i = ∑ i, R i using sum_perm_invariant (or Equiv.sum_comp).
-/
theorem meanReturn_perm_invariant (e : Equiv.Perm (Fin N)) :
    meanReturn (R ∘ e) = meanReturn R := by
      unfold meanReturn;
      erw [ Equiv.sum_comp e ]

/-
PROBLEM
Variance is invariant under permutation of returns.

PROVIDED SOLUTION
Unfold variance. Use meanReturn_perm_invariant to replace meanReturn (R ∘ e) with meanReturn R. Then the sum ∑ i, ((R ∘ e) i - meanReturn R)^2 = ∑ i, (R (e i) - meanReturn R)^2 = ∑ i, (R i - meanReturn R)^2 by Equiv.sum_comp.
-/
theorem variance_perm_invariant (e : Equiv.Perm (Fin N)) :
    variance (R ∘ e) = variance R := by
      unfold variance;
      rw [ meanReturn_perm_invariant ];
      erw [ Equiv.sum_comp e fun i => ( R i - meanReturn R ) ^ 2 ]

/-
PROBLEM
TDD² is invariant under permutation of returns.

PROVIDED SOLUTION
Unfold tddSq. The sum ∑ i, (min ((R ∘ e) i) 0)^2 = ∑ i, (min (R (e i)) 0)^2 = ∑ i, (min (R i) 0)^2 by Equiv.sum_comp.
-/
theorem tddSq_perm_invariant (e : Equiv.Perm (Fin N)) :
    tddSq (R ∘ e) = tddSq R := by
      unfold tddSq;
      exact congrArg _ ( Equiv.sum_comp e fun i => min ( R i ) 0 ^ 2 )

/-- Maximum drawdown for a concrete sequence, defined as max over i ≤ j of (E_i - E_j)
    where E_k = ∑_{t<k} R_t is the cumulative sum (equity curve). -/
def maxDrawdownOfList (l : List ℚ) : ℚ :=
  let cumsums := l.scanl (· + ·) 0
  let peak := cumsums.scanl max 0
  (peak.zip cumsums).foldl (fun acc (p, c) => max acc (p - c)) 0

/-- The sequence [1, -1, -1] has a different maximum drawdown than [-1, 1, -1],
    even though one is a permutation of the other (same multiset of returns).
    This proves Calmar ratio is NOT permutation-invariant. -/
theorem calmar_not_perm_invariant :
    maxDrawdownOfList [1, -1, -1] ≠ maxDrawdownOfList [-1, 1, -1] := by native_decide

/-! ## Part D: Cross-Metric Consistency

Given empirical values: Sortino ≈ 0.24, PF = 1.34, WR = 0.597, N = 900, D = 20, MDD = 0.336.
Under normality: Sharpe ≈ Sortino / √2 ≈ 0.24 / 1.414 ≈ 0.17. -/

/-
PROBLEM
Implied Sharpe from Sortino under normality assumption.

PROVIDED SOLUTION
Use norm_num and bounds on sqrt(2). We know sqrt(2) > 1.414 and sqrt(2) < 1.415. So 0.24/1.415 < 0.24/sqrt(2) < 0.24/1.414. Compute: 0.24/1.415 ≈ 0.1696 > 0.16 and 0.24/1.414 ≈ 0.1697 < 0.18. Use Real.sq_sqrt and bound sqrt(2) via sq_lt_sq'.
-/
theorem implied_sharpe_approx :
    (0.24 : ℝ) / Real.sqrt 2 > 0.16 ∧ (0.24 : ℝ) / Real.sqrt 2 < 0.18 := by
      exact ⟨ by rw [ gt_iff_lt ] ; rw [ lt_div_iff₀ ] <;> norm_num ; nlinarith [ Real.sqrt_nonneg 2, Real.sq_sqrt zero_le_two ], by rw [ div_lt_iff₀ ] <;> norm_num ; nlinarith [ Real.sqrt_nonneg 2, Real.sq_sqrt zero_le_two ] ⟩

end