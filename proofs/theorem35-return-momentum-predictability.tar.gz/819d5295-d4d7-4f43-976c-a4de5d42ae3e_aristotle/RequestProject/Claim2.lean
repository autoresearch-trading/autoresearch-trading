/-
# Claim 2: Multi-step Aggregation and sqrt(k) Amplification

For an AR(1) process with parameter β, using k-step cumulative returns
amplifies the correlation with the next return by approximately √k
when β is small.

We prove the exact covariance formula and the amplification result.
-/
import Mathlib

open Finset BigOperators Real

/-- For AR(1) with parameter β and variance σ², the autocovariance at lag h is β^h * σ².
    The covariance of the k-step cumulative return with r_{t+1} is:
      Cov(r_t^(k), r_{t+1}) = σ² * Σ_{i=0}^{k-1} β^{i+1} = σ² * β * (1 - β^k) / (1 - β)
    We prove the sum identity for the geometric series. -/
theorem geom_sum_shift (β : ℝ) (hβ : β ≠ 1) (k : ℕ) :
    ∑ i ∈ range k, β ^ (i + 1) = β * (1 - β ^ k) / (1 - β) := by
  simp +decide [ pow_succ', geom_sum_eq, mul_div_assoc, hβ ]
  rw [ ← Finset.mul_sum _ _ _, ← neg_div_neg_eq, geom_sum_eq ] <;> ring ; contrapose! hβ ; linarith

/-- The covariance Cov(r_t^(k), r_{t+1}) = σ² * β * (1 - β^k) / (1 - β). -/
theorem multistep_covariance (β σ2 : ℝ) (hβ : β ≠ 1) (k : ℕ) :
    σ2 * ∑ i ∈ range k, β ^ (i + 1) = σ2 * β * (1 - β ^ k) / (1 - β) := by
  rw [ geom_sum_shift β hβ ] ; ring

/-
PROBLEM
For small β (first-order approximation), the correlation of the k-step
    return with the next return is approximately β * √k.

    More precisely: if Cov(r_t^(k), r_{t+1}) ≈ k * β * σ² and
    Var(r_t^(k)) ≈ k * σ², then:
    Corr = Cov / √(Var_X * Var_Y) = (k * β * σ²) / √(k * σ² * σ²)
         = (k * β * σ²) / (√k * σ²) = β * √k.

    We prove this using R² = Cov² / (Var_X * Var_Y), avoiding square roots.

PROVIDED SOLUTION
(k * β * σ2)^2 / (k * σ2 * σ2) = k^2 * β^2 * σ2^2 / (k * σ2^2) = k * β^2 = β^2 * k. Since k > 0 and σ2 > 0, k * σ2 * σ2 ≠ 0. Use field_simp and ring.
-/
theorem sqrt_k_amplification_rsquared (β σ2 : ℝ) (k : ℕ) (hσ2_pos : 0 < σ2) (hk_pos : 0 < k) :
    (↑k * β * σ2) ^ 2 / (↑k * σ2 * σ2) = β ^ 2 * ↑k := by
  rw [ div_eq_iff ] <;> ring ; positivity;

/-
PROBLEM
The correlation version: Corr = Cov / √(Var_X * Var_Y) = β * √k.
    Here Var_X = k * σ² and Var_Y = σ², so √(Var_X * Var_Y) = √(k * σ² * σ²).

PROVIDED SOLUTION
We have k * σ2 * σ2 = k * σ2^2. Since k > 0 and σ2 > 0, this is positive, so sqrt(k * σ2^2) = sqrt(k) * σ2 (since σ2 > 0). Then (k * β * σ2) / (sqrt(k) * σ2) = k * β / sqrt(k) = β * (k / sqrt(k)) = β * sqrt(k). Use Real.sqrt_mul, Real.sqrt_sq, mul_div_cancel, etc. Key: sqrt(k * σ2^2) = sqrt(k) * sqrt(σ2^2) = sqrt(k) * σ2 (since σ2 ≥ 0).
-/
theorem sqrt_k_amplification_corr (β σ2 : ℝ) (k : ℕ) (hσ2_pos : 0 < σ2) (hk_pos : 0 < k) :
    (↑k * β * σ2) / Real.sqrt (↑k * σ2 * σ2) = β * Real.sqrt ↑k := by
  -- Simplify the denominator by taking the square root of the product.
  field_simp [mul_comm, mul_assoc, mul_left_comm] at *; ring_nf at *; norm_num [hk_pos.le, hσ2_pos.le] at *; (
  ring ; norm_num [ hk_pos.le ] ; ring;)

/-- The R² improvement from k-step lookback (small β approximation):
    R²(k) ≈ β² * k, showing k-fold improvement over single-step R² = β². -/
theorem rsquared_k_approx (β : ℝ) (k : ℕ) (hk_pos : 0 < k) :
    (↑k * β) ^ 2 / (↑k * 1) = β ^ 2 * ↑k := by
  grind