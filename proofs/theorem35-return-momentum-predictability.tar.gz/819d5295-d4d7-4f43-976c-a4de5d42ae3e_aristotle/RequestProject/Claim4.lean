/-
# Claim 4: Complementarity — Adding Regressors Cannot Decrease R²

Standard result from linear regression: R² of a model with predictors {X₁, X₂}
is at least as large as R² with either predictor alone.
-/
import Mathlib

open Real

/-
PROBLEM
Via Frisch-Waugh-Lovell decomposition:
    R²_full = R²_partial + (1 - R²_partial) * R²_residual
    where R²_residual ≥ 0. So R²_full ≥ R²_partial.

PROVIDED SOLUTION
We need R2_partial ≤ R2_partial + (1 - R2_partial) * R2_residual. This is equivalent to 0 ≤ (1 - R2_partial) * R2_residual. Since R2_partial ≤ 1 and R2_residual ≥ 0, both factors are nonneg. Use mul_nonneg and linarith/nlinarith.
-/
theorem rsquared_monotone_frisch_waugh (R2_partial R2_residual : ℝ)
    (h1 : 0 ≤ R2_partial) (h2 : R2_partial ≤ 1) (h3 : 0 ≤ R2_residual) :
    R2_partial ≤ R2_partial + (1 - R2_partial) * R2_residual := by
  nlinarith

/-
PROBLEM
The improvement is strictly positive when R²_residual > 0.

PROVIDED SOLUTION
We need R2_partial < R2_partial + (1 - R2_partial) * R2_residual. Equivalent to 0 < (1 - R2_partial) * R2_residual. Since R2_partial < 1 (so 1 - R2_partial > 0) and R2_residual > 0, use mul_pos and linarith.
-/
theorem rsquared_strict_improvement (R2_partial R2_residual : ℝ)
    (h1 : 0 ≤ R2_partial) (h2 : R2_partial < 1) (h3 : 0 < R2_residual) :
    R2_partial < R2_partial + (1 - R2_partial) * R2_residual := by
  nlinarith

/-
PROBLEM
Direct algebraic proof that R²(X₁, X₂) ≥ ρ₁² (partial R²).
    Using the formula:
    R²_full = (ρ₁² + ρ₂² - 2*ρ₁*ρ₂*ρ₁₂) / (1 - ρ₁₂²)

PROVIDED SOLUTION
We need ρ1² ≤ (ρ1² + ρ2² - 2ρ1ρ2ρ12) / (1 - ρ12²). Since 1 - ρ12² > 0, multiply both sides: ρ1²(1 - ρ12²) ≤ ρ1² + ρ2² - 2ρ1ρ2ρ12. This simplifies to 0 ≤ ρ2² - 2ρ1ρ2ρ12 + ρ1²ρ12² = (ρ2 - ρ1*ρ12)². Use rw [div_le_iff (by linarith)], then nlinarith [sq_nonneg (ρ2 - ρ1 * ρ12)].
-/
theorem multiple_rsquared_ge_partial (ρ1 ρ2 ρ12 : ℝ)
    (h_corr12 : ρ12 ^ 2 < 1)
    (h_ρ1_le : ρ1 ^ 2 ≤ 1) (h_ρ2_le : ρ2 ^ 2 ≤ 1) :
    ρ1 ^ 2 ≤ (ρ1 ^ 2 + ρ2 ^ 2 - 2 * ρ1 * ρ2 * ρ12) / (1 - ρ12 ^ 2) := by
  rw [ le_div_iff₀ ] <;> nlinarith [ sq_nonneg ( ρ2 - ρ1 * ρ12 ) ] ;

/-
PROBLEM
Application: R²(r₂₀, OFI) ≥ max(R²(r₂₀), R²(OFI)).

PROVIDED SOLUTION
Use max_le. For the first part, apply multiple_rsquared_ge_partial with ρ1=ρ_r20, ρ2=ρ_ofi, ρ12=ρ_cross. For the second part, note that the formula is symmetric: (ρ1² + ρ2² - 2ρ1ρ2ρ12)/(1-ρ12²) is symmetric in ρ1 and ρ2, so apply multiple_rsquared_ge_partial with roles swapped. Use le_div_iff and nlinarith [sq_nonneg (ρ_r20 - ρ_ofi * ρ_cross)].
-/
theorem complementarity_returns_ofi (ρ_r20 ρ_ofi ρ_cross : ℝ)
    (h_cross : ρ_cross ^ 2 < 1)
    (h_r20 : ρ_r20 ^ 2 ≤ 1) (h_ofi : ρ_ofi ^ 2 ≤ 1) :
    max (ρ_r20 ^ 2) (ρ_ofi ^ 2) ≤
      (ρ_r20 ^ 2 + ρ_ofi ^ 2 - 2 * ρ_r20 * ρ_ofi * ρ_cross) / (1 - ρ_cross ^ 2) := by
  have := multiple_rsquared_ge_partial ρ_r20 ρ_ofi ρ_cross h_cross h_r20 h_ofi;
  have := multiple_rsquared_ge_partial ρ_ofi ρ_r20 ρ_cross ( by linarith ) ( by linarith ) ( by linarith ) ; ( rw [ max_le_iff ] ; constructor <;> ring_nf at * <;> nlinarith; )