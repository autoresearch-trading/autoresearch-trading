/-
# Claim 3: Optimal Lookback

For β > 0 (momentum), there exists a finite optimal lookback k* that maximizes
the predictive R² from using r_t^(k) to predict r_{t+1}.

For β < 0 (mean reversion), k* = 1 is optimal.
-/
import Mathlib

open Real

/-
PROBLEM
For 0 < β < 1, the function k ↦ β * (1 - β^k) / (1 - β) is bounded above
    by β / (1 - β). This means the covariance numerator saturates.

PROVIDED SOLUTION
Since 0 < β < 1, we have 0 ≤ β^k, so 1 - β^k ≤ 1, and since β > 0 and 1 - β > 0, β(1-β^k)/(1-β) ≤ β/(1-β). Use div_le_div_of_nonneg_right (or div_le_div_right) with mul_le_mul_of_nonneg_left.
-/
theorem cov_numerator_bounded (β : ℝ) (hβ_pos : 0 < β) (hβ_lt : β < 1) (k : ℕ) :
    β * (1 - β ^ k) / (1 - β) ≤ β / (1 - β) := by
  gcongr ; nlinarith [ pow_nonneg hβ_pos.le k ];
  nlinarith [ pow_nonneg hβ_pos.le k ]

/-
PROBLEM
The squared covariance for k=1 when β ≠ 1: Cov² = β² * σ⁴.

PROVIDED SOLUTION
Simplify: β^1 = β, so (σ2 * β * (1 - β) / (1 - β))^2 = (σ2 * β)^2 = β^2 * σ2^2. Cancel (1-β) in num/denom using hβ (β ≠ 1 means 1-β ≠ 0). Use field_simp and ring.
-/
theorem cov_sq_k1 (β σ2 : ℝ) (hβ : β ≠ 1) :
    (σ2 * β * (1 - β ^ 1) / (1 - β)) ^ 2 = β ^ 2 * σ2 ^ 2 := by
  grind

/-
PROBLEM
For β > 0, R²(k) → 0 as k → ∞ because Var(r_t^(k)) grows
    linearly while Cov² is bounded.

PROVIDED SOLUTION
The numerator (β * (1 - β^k) / (1 - β))^2 is bounded above by (β/(1-β))^2 (by cov_numerator_bounded). So the expression is ≤ (β/(1-β))^2 / k. For any ε > 0, choose K = ⌈(β/(1-β))^2 / ε⌉ + 1. Then for k ≥ K, (β/(1-β))^2 / k ≤ (β/(1-β))^2 / K < ε. Use Archimedean property.
-/
theorem rsquared_eventually_small (β : ℝ) (hβ_pos : 0 < β) (hβ_lt : β < 1) :
    ∀ ε > 0, ∃ K : ℕ, ∀ k : ℕ, K ≤ k →
      (β * (1 - β ^ k) / (1 - β)) ^ 2 / (↑k : ℝ) < ε := by
  -- The numerator is bounded above by (β/(1-β))^2 (by cov_numerator_bounded).
  have h_bound : ∀ k : ℕ, (β * (1 - β ^ k) / (1 - β)) ^ 2 ≤ (β / (1 - β)) ^ 2 := by
    exact fun k => pow_le_pow_left₀ ( div_nonneg ( mul_nonneg hβ_pos.le ( sub_nonneg.2 ( pow_le_one₀ hβ_pos.le hβ_lt.le ) ) ) ( sub_nonneg.2 hβ_lt.le ) ) ( div_le_div_of_nonneg_right ( mul_le_of_le_one_right hβ_pos.le ( sub_le_self _ ( pow_nonneg hβ_pos.le _ ) ) ) ( sub_nonneg.2 hβ_lt.le ) ) _;
  -- We want to find K such that for all k ≥ K, (β/(1-β))^2 / k < ε.
  intros ε hε_pos
  obtain ⟨K, hK⟩ : ∃ K : ℕ, ∀ k : ℕ, k ≥ K → (β / (1 - β)) ^ 2 / (k : ℝ) < ε := by
    exact ⟨ ⌊ ( β / ( 1 - β ) ) ^ 2 / ε⌋₊ + 1, fun k hk => by rw [ div_lt_iff₀ ] <;> nlinarith [ Nat.lt_of_floor_lt hk, mul_div_cancel₀ ( ( β / ( 1 - β ) ) ^ 2 ) hε_pos.ne' ] ⟩;
  exact ⟨ K, fun k hk => lt_of_le_of_lt ( div_le_div_of_nonneg_right ( h_bound k ) ( Nat.cast_nonneg _ ) ) ( hK k hk ) ⟩

/-
PROBLEM
For 0 < β < 1, the maximum of R²(k) over k ≥ 1 is achieved
    at some finite k* ≥ 1.
    We model R²(k) ∝ (β * (1 - β^k) / (1 - β))² / k.

PROVIDED SOLUTION
Use rsquared_eventually_small with ε = R²(1) = β² > 0. Get K such that for k ≥ K, R²(k) < β². The function k ↦ R²(k) on {1, ..., max(K, 1)} is a finite set of reals, so it has a maximum. This maximum is at least R²(1) = β² > R²(k) for all k > K, so it's the global max over k ≥ 1.

More precisely: let f(k) = (β * (1 - β^k)/(1-β))^2 / k. We have f(1) = β^2 (by cov_sq_k1 type reasoning). By rsquared_eventually_small, ∃ K, ∀ k ≥ K, f(k) < β^2/2. The max of f over {1,...,K} exists (finite nonempty set). Any k > K has f(k) < f(1) ≤ max, so this max works as the global max.

Actually, more carefully: consider the finite set {1, 2, ..., max(K, 1)}. The function f achieves a maximum kstar on this set. For k > K, f(k) < β^2 ≤ f(1) ≤ f(kstar). So kstar works globally.
-/
theorem exists_optimal_lookback_momentum (β : ℝ) (hβ_pos : 0 < β) (hβ_lt : β < 1) :
    ∃ kstar : ℕ, kstar ≥ 1 ∧
      ∀ k : ℕ, k ≥ 1 →
        (β * (1 - β ^ k) / (1 - β)) ^ 2 / (↑k : ℝ) ≤
        (β * (1 - β ^ kstar) / (1 - β)) ^ 2 / (↑kstar : ℝ) := by
  by_contra h_contra;
  obtain ⟨K, hK⟩ : ∃ K : ℕ, ∀ k : ℕ, K ≤ k → (β * (1 - β ^ k) / (1 - β)) ^ 2 / (k : ℝ) < (β * (1 - β ^ 1) / (1 - β)) ^ 2 / 1 := by
    have := rsquared_eventually_small β hβ_pos hβ_lt ( ( β * ( 1 - β ^ 1 ) / ( 1 - β ) ) ^ 2 / 1 ) ( div_pos ( sq_pos_of_pos <| div_pos ( mul_pos hβ_pos <| sub_pos.mpr <| pow_lt_one₀ hβ_pos.le hβ_lt <| by norm_num ) <| sub_pos.mpr hβ_lt ) zero_lt_one ) ; aesop;
  -- Consider the finite set {1, 2, ..., max(K, 1)}. The function f achieves a maximum kstar on this set.
  obtain ⟨kstar, hkstar⟩ : ∃ kstar ∈ Finset.Icc 1 (Nat.max K 1), ∀ k ∈ Finset.Icc 1 (Nat.max K 1), (β * (1 - β ^ k) / (1 - β)) ^ 2 / (k : ℝ) ≤ (β * (1 - β ^ kstar) / (1 - β)) ^ 2 / (kstar : ℝ) := by
    exact Finset.exists_max_image _ _ ⟨ 1, Finset.mem_Icc.mpr ⟨ by norm_num, Nat.one_le_iff_ne_zero.mpr <| by positivity ⟩ ⟩;
  refine' h_contra ⟨ kstar, Finset.mem_Icc.mp hkstar.1 |>.1, fun k hk => _ ⟩ ; by_cases hk' : k ≤ K <;> simp_all +decide [ div_eq_mul_inv ] ;
  grind +splitImp

/-
PROBLEM
For -1 < β < 0, k = 1 is optimal: k=1 dominates k=2.

PROVIDED SOLUTION
For k=1: (β*(1-β)/(1-β))^2 / 1 = β^2. For k=2: (β*(1-β^2)/(1-β))^2 / 2 = (β*(1+β))^2 / 2 = β^2*(1+β)^2/2. We need β^2 ≥ β^2*(1+β)^2/2, i.e., 2 ≥ (1+β)^2. Since -1 < β < 0, we have 0 < 1+β < 1, so (1+β)^2 < 1 < 2. Use field_simp [sub_ne_zero.mpr (ne_of_lt (by linarith : β < 1)).symm] and nlinarith.
-/
theorem mean_reversion_k1_beats_k2 (β : ℝ) (hβ_neg : β < 0) (hβ_gt : -1 < β) :
    (β * (1 - β ^ 1) / (1 - β)) ^ 2 / (1 : ℝ) ≥
    (β * (1 - β ^ 2) / (1 - β)) ^ 2 / (2 : ℝ) := by
  field_simp;
  rw [ div_le_div_iff₀ ] <;> try nlinarith;
  nlinarith [ mul_le_mul_of_nonneg_left hβ_gt.le ( sq_nonneg β ), mul_le_mul_of_nonneg_left hβ_neg.le ( sq_nonneg β ), mul_le_mul_of_nonneg_left hβ_gt.le ( sq_nonneg ( β^2 ) ), mul_le_mul_of_nonneg_left hβ_neg.le ( sq_nonneg ( β^2 ) ) ]