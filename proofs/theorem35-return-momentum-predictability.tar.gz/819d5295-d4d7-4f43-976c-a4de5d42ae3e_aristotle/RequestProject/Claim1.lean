/-
# Claim 1: AR(1) Autocorrelation and R²

For a stationary AR(1) process r_t = α + β * r_{t-1} + ε_t where ε_t is
uncorrelated with r_{t-1}, the R² of the regression equals β².

We formalize this algebraically: given the variance decomposition and
covariance structure implied by the model, we derive R² = β².
-/
import Mathlib

open Real

/-! ## Definitions -/

/-- R² of a simple linear regression, defined as the squared correlation. -/
noncomputable def R_squared (cov varX varY : ℝ) : ℝ :=
  cov ^ 2 / (varX * varY)

/-! ## Claim 1: R² = β² for stationary AR(1) -/

/-
PROBLEM
For AR(1): r_t = α + β * r_{t-1} + ε_t with ε uncorrelated with r_{t-1},
    Cov(r_t, r_{t-1}) = β * Var(r_{t-1}) and Var(r_t) = β² * Var(r_{t-1}) + Var(ε).
    The R² of regressing r_t on r_{t-1} equals β² * Var(r_{t-1}) / Var(r_t).

PROVIDED SOLUTION
Unfold R_squared. The goal becomes (β * σ2)^2 / (σ2 * (β^2 * σ2 + σε2)) = β^2 * σ2 / (β^2 * σ2 + σε2). Simplify: (β * σ2)^2 = β^2 * σ2^2, so LHS = β^2 * σ2^2 / (σ2 * (β^2 * σ2 + σε2)) = β^2 * σ2 / (β^2 * σ2 + σε2). Use field_simp and ring.
-/
theorem ar1_rsquared_general (β σ2 σε2 : ℝ) (hσ2_pos : 0 < σ2) (hσε2_nn : 0 ≤ σε2)
    (hVarY : β ^ 2 * σ2 + σε2 > 0) :
    R_squared (β * σ2) σ2 (β ^ 2 * σ2 + σε2) = β ^ 2 * σ2 / (β ^ 2 * σ2 + σε2) := by
  unfold R_squared; rw [ div_eq_div_iff ] <;> nlinarith;

/-
PROBLEM
For a **stationary** AR(1), Var(r_t) = Var(r_{t-1}) = σ², so R² = β².
    Stationarity means σ² = β² * σ² + σε², i.e., σε² = (1 - β²) * σ².

PROVIDED SOLUTION
Unfold R_squared. Goal: (β * σ2)^2 / (σ2 * σ2) = β^2. Simplify: β^2 * σ2^2 / σ2^2 = β^2. Use field_simp and ring, with hσ2_pos to show σ2 ≠ 0.
-/
theorem ar1_rsquared_stationary (β σ2 : ℝ) (hσ2_pos : 0 < σ2) (hβ_lt : β ^ 2 < 1) :
    R_squared (β * σ2) σ2 σ2 = β ^ 2 := by
  unfold R_squared; ring_nf; norm_num [ hσ2_pos.ne' ] ;

/-
PROBLEM
Interpretation: β > 0 means momentum (positive autocorrelation).

PROVIDED SOLUTION
Since σ2 > 0, β * σ2 > 0 iff β > 0. Use mul_pos_iff or constructor with intro + positivity/division.
-/
theorem momentum_iff_positive_beta (β σ2 : ℝ) (hσ2_pos : 0 < σ2) :
    β * σ2 > 0 ↔ β > 0 := by
  constructor <;> intro h <;> nlinarith

/-
PROBLEM
Interpretation: β < 0 means mean reversion (negative autocorrelation).

PROVIDED SOLUTION
Since σ2 > 0, β * σ2 < 0 iff β < 0. Use mul_neg_iff or constructor.
-/
theorem mean_reversion_iff_negative_beta (β σ2 : ℝ) (hσ2_pos : 0 < σ2) :
    β * σ2 < 0 ↔ β < 0 := by
  constructor <;> intro <;> nlinarith

/-
PROBLEM
β = 0 means returns are unpredictable from their own history.

PROVIDED SOLUTION
R_squared (β * σ2) σ2 σ2 = β^2 by ar1_rsquared_stationary. So R² = 0 iff β^2 = 0 iff β = 0. Use ar1_rsquared_stationary, then sq_eq_zero_iff.
-/
theorem unpredictable_iff_zero_beta (β σ2 : ℝ) (hσ2_pos : 0 < σ2) (hβ_lt : β ^ 2 < 1) :
    R_squared (β * σ2) σ2 σ2 = 0 ↔ β = 0 := by
  -- By definition of R_squared, we have R_squared (β * σ2) σ2 σ2 = (β * σ2)^2 / (σ2 * σ2).
  rw [R_squared];
  aesop