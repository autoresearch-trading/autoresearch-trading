/-
# Claim 5: Numerical Verification

With β = 0.02:
- R²(k=1) = β² = 0.0004
- R²(k=20) ≈ β² * 20 = 0.008
- The improvement factor from k=1 to k=20 is approximately 20
-/
import Mathlib

open Real

/-! ## Exact computations with rationals -/

/-
PROBLEM
β = 0.02 = 1/50. R²(k=1) = β² = 1/2500 = 0.0004.

PROVIDED SOLUTION
norm_num
-/
theorem rsquared_k1 : (1 / 50 : ℚ) ^ 2 = 1 / 2500 := by
  native_decide +revert

/-
PROBLEM
The approximate R²(k=20) = β² * k = (1/50)² * 20 = 20/2500 = 1/125 = 0.008.

PROVIDED SOLUTION
norm_num
-/
theorem rsquared_k20_approx : (1 / 50 : ℚ) ^ 2 * 20 = 1 / 125 := by
  grind

/-
PROBLEM
1/125 = 0.008

PROVIDED SOLUTION
norm_num
-/
theorem rsquared_k20_decimal : (1 : ℚ) / 125 = 8 / 1000 := by
  norm_num [ div_eq_mul_inv ] at *

/-
PROBLEM
1/2500 = 0.0004

PROVIDED SOLUTION
norm_num
-/
theorem rsquared_k1_decimal : (1 : ℚ) / 2500 = 4 / 10000 := by
  decide +kernel

/-
PROBLEM
The improvement factor: R²(k=20) / R²(k=1) = 20.
    (1/125) / (1/2500) = 2500/125 = 20.

PROVIDED SOLUTION
norm_num
-/
theorem improvement_factor : (1 / 125 : ℚ) / (1 / 2500) = 20 := by
  norm_num +zetaDelta at *

/-
PROBLEM
The improvement from k=1 to k=20 is approximately k = 20.
    More precisely, in the small-β regime, R²(k) ≈ β²·k,
    so R²(k)/R²(1) ≈ k.

PROVIDED SOLUTION
β^2 * k / β^2 = k. Since β ≠ 0, β^2 ≠ 0. Use field_simp and ring, or mul_div_cancel_left.
-/
theorem improvement_is_k (β : ℚ) (hβ : β ≠ 0) (k : ℕ) (hk : k ≥ 1) :
    (β ^ 2 * ↑k) / (β ^ 2) = ↑k := by
  rw [ mul_div_cancel_left₀ _ ( pow_ne_zero 2 hβ ) ]