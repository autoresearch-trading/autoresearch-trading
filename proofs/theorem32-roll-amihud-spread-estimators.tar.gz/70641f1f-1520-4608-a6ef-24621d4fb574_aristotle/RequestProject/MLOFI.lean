/-
# Multi-Level Order Flow Imbalance (MLOFI)
Based on Cont, Kukanov & Stoikov (2014) and Xu, Howison & Gould (2019).
-/
import Mathlib

open Finset BigOperators Real Submodule

noncomputable section

/-! ## Claim 1: R² Monotonicity (Adding regressors cannot decrease R²)

We formalize this as a property of orthogonal projections in inner product spaces:
if V ≤ W are (complete) subspaces, then projecting onto W captures at least as much
of any vector as projecting onto V.

R² = ‖proj x‖² / ‖x‖², so larger projection norm means larger R².
-/

/-
PROBLEM
If V ≤ W are subspaces with orthogonal projections, then ‖proj_W x‖ ≥ ‖proj_V x‖.
This is the abstract version of "adding regressors cannot decrease R²".

PROVIDED SOLUTION
The projection of x onto V is also in W (since V ≤ W). So the projection onto V is a member of W. The projection onto W minimizes distance from x over W, so ‖x - proj_W x‖ ≤ ‖x - proj_V x‖. By Pythagorean theorem: ‖x‖² = ‖proj x‖² + ‖x - proj x‖². Since ‖x - proj_W x‖ ≤ ‖x - proj_V x‖, we get ‖proj_W x‖ ≥ ‖proj_V x‖. Key lemmas: norm_sq_eq_add_norm_sq_projection, orthogonalProjection as best approximation, Subtype.coe_le.
-/
theorem projection_norm_mono {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (V W : Submodule ℝ E) [V.HasOrthogonalProjection] [W.HasOrthogonalProjection]
    (hVW : V ≤ W) (x : E) :
    ‖(orthogonalProjection V x : E)‖ ≤ ‖(orthogonalProjection W x : E)‖ := by
  -- By the properties of orthogonal projections, we know that ‖x - proj_W x‖ ≤ ‖x - proj_V x‖.
  have h_dist : ‖x - W.orthogonalProjection x‖ ≤ ‖x - V.orthogonalProjection x‖ := by
    -- By the properties of orthogonal projections, we know that for any vector $x$, the distance from $x$ to its projection onto $W$ is less than or equal to the distance from $x$ to its projection onto $V$.
    have h_dist : ∀ y ∈ W, ‖x - y‖ ≥ ‖x - W.orthogonalProjection x‖ := by
      intro y hy
      have h_dist : ‖x - y‖^2 = ‖x - W.orthogonalProjection x‖^2 + ‖W.orthogonalProjection x - y‖^2 := by
        rw [ show x - y = ( x - W.orthogonalProjection x ) + ( W.orthogonalProjection x - y ) by abel1, norm_add_sq_real ];
        simp +zetaDelta at *;
        exact Submodule.starProjection_inner_eq_zero _ _ ( by aesop );
      exact le_of_pow_le_pow_left₀ ( by norm_num ) ( norm_nonneg _ ) ( h_dist ▸ le_add_of_nonneg_right ( sq_nonneg _ ) );
    exact h_dist _ ( hVW <| Submodule.coe_mem _ );
  -- By the properties of orthogonal projections, we know that ‖x‖² = ‖proj_V x‖² + ‖x - proj_V x‖² and ‖x‖² = ‖proj_W x‖² + ‖x - proj_W x‖².
  have h_norm_sq : ‖x‖^2 = ‖V.orthogonalProjection x‖^2 + ‖x - V.orthogonalProjection x‖^2 ∧ ‖x‖^2 = ‖W.orthogonalProjection x‖^2 + ‖x - W.orthogonalProjection x‖^2 := by
    constructor <;> rw [ @norm_sub_sq ℝ ] <;> simp +decide [ inner_sub_left, inner_sub_right ];
    · rw [ ← real_inner_self_eq_norm_sq, ← real_inner_self_eq_norm_sq ] ; ring!;
      grind +suggestions;
    · rw [ show inner ℝ x ( W.starProjection x ) = ‖W.starProjection x‖ ^ 2 by
            rw [ ← sub_add_cancel x ( W.starProjection x ), inner_add_left ] ; aesop; ] ; ring!;
  simp +zetaDelta at *;
  nlinarith [ norm_nonneg ( V.starProjection x ), norm_nonneg ( W.starProjection x ), norm_nonneg ( x - V.starProjection x ), norm_nonneg ( x - W.starProjection x ) ]

/-
PROBLEM
R² monotonicity: R²(multi) ≥ R²(single).
If V ≤ W are subspaces and x ≠ 0, then the fraction of ‖x‖² explained by W
is at least the fraction explained by V.

PROVIDED SOLUTION
Follows directly from projection_norm_mono: since ‖proj_V x‖ ≤ ‖proj_W x‖, we have ‖proj_V x‖² ≤ ‖proj_W x‖², and dividing by ‖x‖² > 0 (since x ≠ 0) preserves the inequality. Use div_le_div_of_nonneg_right or similar.
-/
theorem r_squared_mono {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (V W : Submodule ℝ E) [V.HasOrthogonalProjection] [W.HasOrthogonalProjection]
    (hVW : V ≤ W) (x : E) (hx : x ≠ 0) :
    ‖(orthogonalProjection V x : E)‖ ^ 2 / ‖x‖ ^ 2 ≤
    ‖(orthogonalProjection W x : E)‖ ^ 2 / ‖x‖ ^ 2 := by
  gcongr
  exact projection_norm_mono V W hVW x

/-! ## Claim 2: PCA Dominance

The first principal component captures at least λ₁/trace(Σ) of total variance.
We formalize this as: for a symmetric PSD matrix, the ratio of the largest eigenvalue
to the trace is a lower bound on the variance explained by the first PC.
-/

/-
PROBLEM
For non-negative reals summing to a positive total, the maximum divided by the sum
is at most 1. This captures: if eigenvalues are λ₁ ≥ ... ≥ λ_L ≥ 0,
then λ₁/trace ≤ 1 and λ₁/trace is the fraction of variance captured by PC1.

PROVIDED SOLUTION
eig ⟨0, hL⟩ is one of the summands, so it's ≤ the sum (since all are nonneg). Then divide both sides by the positive sum.
-/
theorem pca_variance_fraction (L : ℕ) (hL : 0 < L) (eig : Fin L → ℝ)
    (heig_nonneg : ∀ i, 0 ≤ eig i)
    (heig_sorted : ∀ i j, i ≤ j → eig j ≤ eig i)
    (hsum_pos : 0 < ∑ i, eig i) :
    eig ⟨0, hL⟩ / ∑ i, eig i ≤ 1 := by
  exact div_le_one_of_le₀ ( Finset.single_le_sum ( fun i _ => heig_nonneg i ) ( Finset.mem_univ _ ) ) hsum_pos.le

/-
PROBLEM
If λ₁/trace(Σ) ≥ threshold, then PC1 captures at least threshold fraction of variance.

PROVIDED SOLUTION
From hthresh: threshold ≤ eig 0 / ∑ eig. Multiply both sides by ∑ eig (which is positive). Use div_le_iff.
-/
theorem pca_dominance_threshold (L : ℕ) (hL : 0 < L) (eig : Fin L → ℝ)
    (heig_nonneg : ∀ i, 0 ≤ eig i)
    (hsum_pos : 0 < ∑ i, eig i)
    (threshold : ℝ) (hthresh : threshold ≤ eig ⟨0, hL⟩ / ∑ i, eig i) :
    threshold * ∑ i, eig i ≤ eig ⟨0, hL⟩ := by
  rwa [ le_div_iff₀ hsum_pos ] at hthresh

/-! ## Claim 3: Exponential Decay of Level Importance

If β_l = β₁ * exp(-α*(l-1)), the tail sum beyond L_cutoff is bounded.
-/

/-
PROBLEM
The tail sum of β_l² for l > L_cutoff equals β₁² * exp(-2α*L_cutoff) / (1 - exp(-2α)).
Here we index starting from 0, so β_l = β₁ * exp(-α*l) and the tail starts at l = L_cutoff.

PROVIDED SOLUTION
Factor out b1^2 * exp(-2*al*L_cutoff). Then ∑' l, exp(-2*al*l) = 1/(1 - exp(-2*al)) by tsum_geometric_of_lt_one (since 0 ≤ exp(-2*al) < 1 when al > 0). The key manipulation is: exp(-2*al*(l+L_cutoff)) = exp(-2*al*L_cutoff) * exp(-2*al*l). Use tsum_mul_left and the geometric series formula. Write exp(-2*al*l) = (exp(-2*al))^l using Real.exp_nat_mul.
-/
theorem exponential_decay_tail_bound (b1 al : ℝ) (hal : 0 < al) (L_cutoff : ℕ) :
    ∑' (l : ℕ), b1 ^ 2 * Real.exp (-2 * al * (↑(l + L_cutoff) : ℝ)) =
    b1 ^ 2 * Real.exp (-2 * al * ↑L_cutoff) / (1 - Real.exp (-2 * al)) := by
  rw [ div_eq_mul_inv, ← tsum_geometric_of_lt_one ( by positivity ) ( by norm_num; positivity ) ];
  rw [ ← tsum_mul_left ] ; congr ; ext n ; rw [ ← Real.exp_nat_mul ] ; ring;
  simpa only [ mul_assoc, ← Real.exp_add ] using by push_cast; ring;

/-
PROBLEM
The tail sum as a fraction of the total sum equals exp(-2α*L_cutoff).

PROVIDED SOLUTION
Use exponential_decay_tail_bound for numerator. For denominator, use the same formula with L_cutoff = 0: ∑' l, b1^2 * exp(-2*al*l) = b1^2 / (1 - exp(-2*al)). Then the ratio is (b1^2 * exp(-2*al*L_cutoff) / (1 - exp(-2*al))) / (b1^2 / (1 - exp(-2*al))) = exp(-2*al*L_cutoff). Need b1 ≠ 0 so that denominators are nonzero.
-/
theorem exponential_decay_fraction (b1 al : ℝ) (hal : 0 < al) (hb1 : b1 ≠ 0) (L_cutoff : ℕ) :
    (∑' (l : ℕ), b1 ^ 2 * Real.exp (-2 * al * (↑(l + L_cutoff) : ℝ))) /
    (∑' (l : ℕ), b1 ^ 2 * Real.exp (-2 * al * (↑l : ℝ))) =
    Real.exp (-2 * al * ↑L_cutoff) := by
  rw [ div_eq_iff ];
  · rw [ ← tsum_mul_left ] ; congr ; ext l ; push_cast ; rw [ mul_left_comm ] ; rw [ ← Real.exp_add ] ; ring;
  · norm_num [ tsum_mul_left, Real.exp_ne_zero ];
    refine' ⟨ hb1, ne_of_gt _ ⟩;
    refine' Summable.tsum_pos ..;
    exacts [ by simpa [ ← Real.exp_nat_mul, mul_comm ] using summable_geometric_of_lt_one ( by positivity ) ( show Real.exp ( - ( 2 * al ) ) < 1 by rw [ Real.exp_lt_one_iff ] ; norm_num ; positivity ), fun _ => by positivity, 0, by positivity ]

/-
PROBLEM
With α = 0.5, the fraction is exp(-L_cutoff). For L_cutoff = 5, exp(-5) < 0.0067.
This means truncation error is less than 0.67% of total.

PROVIDED SOLUTION
exp(-5) ≤ 7/1000. Note -2*(1/2)*5 = -5. Write exp(-5) = exp(-1)^5 using exp_add repeatedly. Use Real.exp_neg_one_lt_d9 which gives exp(-1) < some bound. Then bound exp(-1) < 0.3679 and compute 0.3679^5 < 0.007.
-/
theorem exponential_decay_numerical_5 :
    Real.exp (-2 * (1/2 : ℝ) * 5) ≤ 7 / 1000 := by
  norm_num [ Real.exp_neg ];
  rw [ inv_eq_one_div, div_le_iff₀ ] <;> have := Real.exp_one_gt_d9.le <;> norm_num at * <;> rw [ show Real.exp 5 = ( Real.exp 1 ) ^ 5 by rw [ ← Real.exp_nat_mul ] ; norm_num ] <;> nlinarith [ pow_le_pow_left₀ ( by positivity ) this 5 ]

/-
PROBLEM
With α = 0.5 and L_cutoff = 3, exp(-3) < 0.0498.
This means truncation error is less than 4.98% of total.

PROVIDED SOLUTION
exp(-3) < 0.0498. The key is -2*(1/2)*3 = -3. exp(-3) ≈ 0.04979. We need exp(-3) ≤ 498/10000 = 0.0498.
-/
theorem exponential_decay_numerical_3 :
    Real.exp (-2 * (1/2 : ℝ) * 3) ≤ 498 / 10000 := by
  have := Real.exp_neg_one_lt_d9 ; norm_num at * ; rw [ show ( -3 : ℝ ) = -1 + ( -1 ) + ( -1 ) by norm_num, Real.exp_add, Real.exp_add ] ; nlinarith [ Real.exp_pos ( -1 ) ]

/-! ## Claim 4: R² Loss from Equal Weights vs Optimal

The R² loss from using equal weights w_l = 1/L instead of optimal β_l is bounded.
We formalize this algebraically.
-/

/-
PROBLEM
The original user claim used the bound
  R²(opt) - R²(equal) ≤ (L-1) * max_l |β_l - mean(β)| * Var(OFI_l) / Var(ΔP)
but this is false as stated (counterexample: L=3, β=[0,1,10], σ²=[1,1,1]).

The correct bound is: the sum of weighted squared deviations is at most
the maximum deviation times the total weighted absolute deviation:
  ∑ᵢ (βᵢ - β̄)² * σᵢ² ≤ max_i|βᵢ - β̄| * ∑ᵢ |βᵢ - β̄| * σᵢ²
This gives a meaningful bound on R² loss from using equal weights.

PROVIDED SOLUTION
It suffices to show ∑ᵢ (βᵢ - β̄)² * σᵢ² ≤ (max_i |βᵢ - β̄|) * ∑ᵢ |βᵢ - β̄| * σᵢ², then divide by varP > 0.

For each i: (βᵢ - β̄)² * σᵢ² = |βᵢ - β̄| * |βᵢ - β̄| * σᵢ² = |βᵢ - β̄| * (|βᵢ - β̄| * σᵢ²).

Since |βᵢ - β̄| ≤ max_j |βⱼ - β̄| = M (the sup'), we have:
(βᵢ - β̄)² * σᵢ² ≤ M * (|βᵢ - β̄| * σᵢ²).

Summing over i: ∑ᵢ (βᵢ - β̄)² * σᵢ² ≤ M * ∑ᵢ |βᵢ - β̄| * σᵢ².

Use div_le_div_of_nonneg_right or just gcongr.

Key steps: rewrite (x)^2 as |x| * |x| using sq_abs, then use Finset.sum_le_sum with pointwise bounds, factor out the sup using Finset.mul_sum.
-/
theorem equal_weight_loss_bound (L : ℕ) (hL : 0 < L)
    (beta : Fin L → ℝ) (sigmasq : Fin L → ℝ) (hsig : ∀ i, 0 ≤ sigmasq i)
    (varP : ℝ) (hvarP : 0 < varP) :
    let beta_mean := (∑ i, beta i) / ↑L
    (∑ i, (beta i - beta_mean) ^ 2 * sigmasq i) / varP ≤
    (Finset.univ.sup' ⟨⟨0, hL⟩, Finset.mem_univ _⟩
      (fun i => |beta i - beta_mean|)) *
    (∑ i, |beta i - beta_mean| * sigmasq i) / varP := by
  field_simp;
  rw [ Finset.mul_sum _ _ _ ];
  refine Finset.sum_le_sum fun i _ => ?_;
  rw [ ← mul_assoc, mul_comm ];
  rw [ div_le_iff₀ ( by positivity ) ];
  refine' le_trans _ ( mul_le_mul_of_nonneg_right ( mul_le_mul_of_nonneg_right ( mul_le_mul_of_nonneg_right ( Finset.le_sup' _ ( Finset.mem_univ i ) ) ( abs_nonneg _ ) ) ( hsig i ) ) ( sq_nonneg _ ) );
  norm_num [ ← sq, mul_div_cancel₀, hL.ne' ];
  field_simp;
  norm_cast

-- The user's original (incorrect) claim is commented out below:
-- theorem equal_weight_loss_bound_ORIGINAL (L : ℕ) (hL : 0 < L)
--     (beta : Fin L → ℝ) (sigmasq : Fin L → ℝ) (hsig : ∀ i, 0 ≤ sigmasq i)
--     (varP : ℝ) (hvarP : 0 < varP) :
--     let beta_mean := (∑ i, beta i) / ↑L
--     (∑ i, (beta i - beta_mean) ^ 2 * sigmasq i) / varP ≤
--     (↑L - 1) * (Finset.univ.sup' ⟨⟨0, hL⟩, Finset.mem_univ _⟩
--       (fun i => |beta i - beta_mean| * sigmasq i)) / varP
-- DISPROVED: counterexample L=3, β=[0,1,10], σ²=[1,1,1] gives
-- LHS ≈ 60.67 > RHS ≈ 12.67

end