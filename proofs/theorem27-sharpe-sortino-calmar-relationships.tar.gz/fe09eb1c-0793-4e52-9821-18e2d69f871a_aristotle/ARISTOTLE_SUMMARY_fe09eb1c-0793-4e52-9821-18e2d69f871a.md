# Summary of changes
All 13 theorems have been formalized and machine-verified in `RequestProject/SortinoRatio.lean`. The file builds cleanly with no `sorry`, no warnings, and only standard axioms (`propext`, `Classical.choice`, `Quot.sound`).

## What was proved

**Claims 1–2 (Algebraic relationship):**
- `tdd_buggy_eq`: The buggy TDD equals the correct TDD divided by √p, i.e. √(S/N_neg) = √(S/N) / √(N_neg/N), where S is the sum of squared negative returns.
- `sortino_buggy_eq`: The buggy Sortino ratio equals the correct Sortino ratio times √p, i.e. μ/TDD_buggy·√m = (μ/TDD_correct·√m)·√p.

**Claim 3 (Understatement):**
- `sortino_buggy_lt`: When 0 < p < 1 and S_correct > 0, the buggy Sortino is strictly less than the correct one (S_buggy < S_correct).

**Claim 5 (Numerical bounds on √0.45):**
- `sqrt_045_lower` / `sqrt_045_upper`: 0.6708 < √0.45 < 0.6709
- `inv_sqrt_045_lower` / `inv_sqrt_045_upper`: 1.490 < 1/√0.45 < 1.491

**Claim 6 (Corrected Sortino values):**
- `corrected_sortino_1_lower/upper`: 0.239 < 0.161/√0.45 < 0.241 (≈ 0.240)
- `corrected_sortino_2_lower/upper`: 0.263 < 0.177/√0.45 < 0.265 (≈ 0.264)
- `corrected_sortino_3_lower/upper`: 0.342 < 0.230/√0.45 < 0.344 (≈ 0.343)

All bounds confirm that the buggy implementation (averaging only over negative returns instead of all N observations) understates the Sortino ratio by a factor of √p ≈ 0.6708 when p = 0.45, and the true Sortino values are approximately 1.49× the reported values.