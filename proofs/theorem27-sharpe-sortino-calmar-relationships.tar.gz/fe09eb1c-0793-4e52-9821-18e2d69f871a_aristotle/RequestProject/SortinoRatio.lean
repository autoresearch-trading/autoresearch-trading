import Mathlib

/-!
# Sortino Ratio: Correct Formula and Bug Characterization

We formalize the relationship between the correct and buggy implementations of the
Sortino ratio's Target Downside Deviation (TDD), and prove numerical bounds.

## Main results

- `tdd_buggy_eq` : TDD_buggy = TDD_correct / √p
- `sortino_buggy_eq` : S_buggy = S_correct * √p
- `sortino_buggy_lt` : S_buggy < S_correct when μ > 0 and 0 < p < 1
- Numerical verification of √0.45 bounds and corrected Sortino values
-/

noncomputable section

open Real

/-! ## Part 1-2: Algebraic relationship between TDD and Sortino -/

/-- The buggy TDD equals the correct TDD divided by √p.

Given:
- `sum_neg_sq` = Σ min(Rᵢ, 0)²  (the sum of squared negative returns)
- `N` = total number of observations
- `N_neg` = number of negative returns
- `p = N_neg / N` (fraction of negative returns)
- `TDD_correct = √(sum_neg_sq / N)`
- `TDD_buggy = √(sum_neg_sq / N_neg)`

Then `TDD_buggy = TDD_correct / √p`. -/
theorem tdd_buggy_eq (N N_neg sum_neg_sq : ℝ) (hN : 0 < N) (_hNneg : 0 < N_neg)
    (_hle : N_neg ≤ N) (hsum : 0 ≤ sum_neg_sq) :
    Real.sqrt (sum_neg_sq / N_neg) = Real.sqrt (sum_neg_sq / N) / Real.sqrt (N_neg / N) := by
  rw [← Real.sqrt_div (by positivity), div_div_div_cancel_right₀ (by positivity)]

/-- The buggy Sortino ratio equals the correct Sortino ratio times √p.

S = μ / TDD * √m, so S_buggy/S_correct = TDD_correct/TDD_buggy = √p. -/
theorem sortino_buggy_eq (mu m TDD_correct TDD_buggy p : ℝ)
    (hTDD_pos : 0 < TDD_correct) (hTDD_buggy_pos : 0 < TDD_buggy)
    (hp_pos : 0 < p) (_hm_pos : 0 < m)
    (hrel : TDD_buggy = TDD_correct / Real.sqrt p) :
    (mu / TDD_buggy * Real.sqrt m) = (mu / TDD_correct * Real.sqrt m) * Real.sqrt p := by
  grind

/-! ## Part 3: The buggy implementation understates the Sortino ratio -/

/-- When 0 < p < 1 and S_correct > 0, the buggy Sortino is strictly less than the correct one. -/
theorem sortino_buggy_lt (S_correct S_buggy p : ℝ)
    (hS_pos : 0 < S_correct) (hp_pos : 0 < p) (hp_lt : p < 1)
    (hrel : S_buggy = S_correct * Real.sqrt p) :
    S_buggy < S_correct := by
  exact hrel.symm ▸ mul_lt_of_lt_one_right hS_pos (by rw [Real.sqrt_lt] <;> linarith)

/-! ## Part 5: Numerical bounds on √0.45 -/

theorem sqrt_045_lower : Real.sqrt 0.45 > 0.6708 := by
  exact Real.lt_sqrt_of_sq_lt <| by norm_num

theorem sqrt_045_upper : Real.sqrt 0.45 < 0.6709 := by
  rw [Real.sqrt_lt] <;> norm_num

/-- 1/√0.45 > 1.490 -/
theorem inv_sqrt_045_lower : 1 / Real.sqrt 0.45 > 1.490 := by
  norm_num [div_eq_mul_inv] at *
  nlinarith [Real.sqrt_nonneg 20, Real.sq_sqrt (show 0 ≤ 20 by norm_num)]

/-- 1/√0.45 < 1.491 -/
theorem inv_sqrt_045_upper : 1 / Real.sqrt 0.45 < 1.491 := by
  rw [div_lt_iff₀] <;> norm_num [Real.sqrt_lt']
  rw [div_mul_div_comm, lt_div_iff₀] <;>
    nlinarith [Real.sqrt_nonneg 20, Real.sq_sqrt (show 0 ≤ 20 by norm_num)]

/-! ## Part 6: Corrected Sortino values -/

/-- 0.161 / √0.45 > 0.239 -/
theorem corrected_sortino_1_lower : 0.161 / Real.sqrt 0.45 > 0.239 := by
  rw [gt_iff_lt, lt_div_iff₀] <;> norm_num [Real.lt_sqrt]
  nlinarith [Real.sqrt_nonneg 20, Real.sq_sqrt <| show 0 ≤ 20 by norm_num,
    mul_div_cancel₀ 3 <| ne_of_gt <| Real.sqrt_pos.2 <| show 0 < 20 by norm_num]

/-- 0.161 / √0.45 < 0.241 -/
theorem corrected_sortino_1_upper : 0.161 / Real.sqrt 0.45 < 0.241 := by
  rw [div_lt_iff₀] <;>
    nlinarith [Real.sqrt_nonneg 0.45, Real.sq_sqrt (show 0.45 ≥ 0 by norm_num)]

/-- 0.177 / √0.45 > 0.263 -/
theorem corrected_sortino_2_lower : 0.177 / Real.sqrt 0.45 > 0.263 := by
  rw [gt_iff_lt, lt_div_iff₀] <;> norm_num [Real.lt_sqrt]
  rw [mul_div, div_lt_iff₀] <;>
    nlinarith [Real.sqrt_nonneg 20, Real.sq_sqrt (show 0 ≤ 20 by norm_num)]

/-- 0.177 / √0.45 < 0.265 -/
theorem corrected_sortino_2_upper : 0.177 / Real.sqrt 0.45 < 0.265 := by
  rw [div_lt_iff₀] <;>
    nlinarith [Real.sqrt_nonneg 0.45, Real.sq_sqrt (show 0 ≤ 0.45 by norm_num)]

/-- 0.230 / √0.45 > 0.342 -/
theorem corrected_sortino_3_lower : 0.230 / Real.sqrt 0.45 > 0.342 := by
  exact lt_div_iff₀ (Real.sqrt_pos.mpr (by norm_num)) |>.2
    (by nlinarith [Real.sqrt_nonneg 0.45, Real.sq_sqrt (show 0 ≤ 0.45 by norm_num)])

/-- 0.230 / √0.45 < 0.344 -/
theorem corrected_sortino_3_upper : 0.230 / Real.sqrt 0.45 < 0.344 := by
  rw [div_lt_iff₀] <;> norm_num [Real.lt_sqrt]
  nlinarith [Real.sqrt_nonneg 20, Real.sq_sqrt (show 0 ≤ 20 by norm_num),
    mul_div_cancel₀ 3 (ne_of_gt (Real.sqrt_pos.mpr (show 0 < 20 by norm_num)))]

end
