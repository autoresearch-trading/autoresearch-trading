import Mathlib
import RequestProject.Definitions

/-!
# Part A: Z-Score Properties

Properties 1-3: Centering, Unit Variance, Order Preservation.
-/

noncomputable section

open Finset BigOperators Real

/-! ## Property 1: Centering

The rolling mean of z-scores over the window is exactly 0,
provided σ > 0.
-/

/-
PROBLEM
Helper: sum of deviations from mean is zero.

PROVIDED SOLUTION
Expand rollingMean. sum (x_i - (1/W) * sum x_j) = sum x_i - W * (1/W) * sum x_j = sum x_i - sum x_j = 0. Use Finset.sum_sub_distrib and the fact that summing a constant W times gives W * const, and W * (1/W) = 1 when W > 0.
-/
lemma sum_deviation_zero (W : ℕ) (hW : 0 < W) (x : Fin W → ℝ) :
    ∑ i, (x i - rollingMean W hW x) = 0 := by
      simp +decide [ rollingMean, hW.ne' ]

/-
PROBLEM
The rolling mean of z-scores is zero when σ > 0.

PROVIDED SOLUTION
Unfold rollingMean and zScore. The mean of z_i = (x_i - μ)/σ is (1/W) * sum_i (x_i - μ)/σ = (1/(W*σ)) * sum_i (x_i - μ). By sum_deviation_zero, sum_i (x_i - μ) = 0. So the mean is 0. Use sum_deviation_zero and the fact that σ > 0.
-/
theorem zscore_centering (W : ℕ) (hW : 0 < W) (x : Fin W → ℝ)
    (hσ : rollingStd W hW x > 0) :
    rollingMean W hW (zScore W hW x) = 0 := by
      unfold rollingMean zScore;
      rw [ ← Finset.sum_div _ _ _, sum_deviation_zero ] ; ring

/-! ## Property 2: Unit Variance

The rolling variance of z-scores over the window is exactly 1,
provided σ > 0.
-/

/-
PROBLEM
The rolling variance of z-scores is 1 when σ > 0.

PROVIDED SOLUTION
Unfold rollingVar for zScore. We need (1/W) * sum_i (z_i - mean(z))^2 = 1. By zscore_centering, mean(z) = 0. So this becomes (1/W) * sum_i z_i^2 = (1/W) * sum_i ((x_i - μ)/σ)^2 = (1/W) * (1/σ^2) * sum_i (x_i - μ)^2 = (1/σ^2) * rollingVar = (1/σ^2) * σ^2 = 1. The key steps: use zscore_centering to simplify the mean to 0, expand zScore, pull 1/σ out of the sum as 1/σ^2, and recognize the remaining sum as W * rollingVar = W * σ^2 (since rollingVar = σ^2 because rollingStd = sqrt(rollingVar) and rollingStd > 0 implies rollingVar = rollingStd^2).
-/
theorem zscore_unit_variance (W : ℕ) (hW : 0 < W) (x : Fin W → ℝ)
    (hσ : rollingStd W hW x > 0) :
    rollingVar W hW (zScore W hW x) = 1 := by
      -- By definition of rolling variance, we have:
      have h_rolling_var : rollingVar W hW (zScore W hW x) = (1 / W) * (∑ i, ((x i - rollingMean W hW x) / rollingStd W hW x) ^ 2) := by
        unfold rollingVar zScore;
        rw [ show rollingMean W hW ( fun i => ( x i - rollingMean W hW x ) / rollingStd W hW x ) = 0 by simpa [ div_eq_inv_mul, mul_assoc, mul_comm, mul_left_comm ] using zscore_centering W hW x hσ ] ; norm_num;
      -- By definition of rolling variance, we have that the sum of the squared deviations from the mean is equal to W times the rolling variance.
      have h_sum_sq_deviations : ∑ i, (x i - rollingMean W hW x) ^ 2 = W * rollingVar W hW x := by
        unfold rollingVar; simp +decide [ hW.ne', mul_div_cancel₀ ] ;
      simp_all +decide [ div_pow, ← Finset.sum_div _ _ _ ];
      field_simp;
      exact Eq.symm ( Real.sq_sqrt <| by exact mul_nonneg ( by positivity ) <| Finset.sum_nonneg fun _ _ => sq_nonneg _ )

/-! ## Property 3: Order Preservation

Z-score normalization preserves ordering within a window.
-/

/-
PROBLEM
Z-score preserves strict ordering within the same window
(since division by the same positive σ is strictly monotone).

PROVIDED SOLUTION
zScore W hW x a = (x a - μ) / σ and zScore W hW x b = (x b - μ) / σ where μ = rollingMean and σ = rollingStd. Since σ > 0, dividing by σ is strictly monotone. So (x a - μ)/σ > (x b - μ)/σ iff x a - μ > x b - μ iff x a > x b. Use div_lt_div_right hσ or sub_lt_sub_iff_right.
-/
theorem zscore_order_preserving (W : ℕ) (hW : 0 < W) (x : Fin W → ℝ)
    (hσ : rollingStd W hW x > 0) (a b : Fin W) :
    x a > x b ↔ zScore W hW x a > zScore W hW x b := by
      field_simp [hσ];
      exact ⟨ fun h => by rw [ zScore, zScore ] ; exact div_lt_div_iff_of_pos_right hσ |>.2 <| by linarith, fun h => by rw [ zScore, zScore ] at h; exact by rw [ div_lt_div_iff_of_pos_right hσ ] at h; linarith ⟩

end