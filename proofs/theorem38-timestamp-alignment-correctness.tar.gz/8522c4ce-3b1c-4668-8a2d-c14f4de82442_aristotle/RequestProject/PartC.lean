import Mathlib
import RequestProject.Definitions

/-!
# Part C: Clipping Properties

Property 7: Clipping bounds and idempotence
Property 8: Clipping preserves ordering within bounds
-/

noncomputable section

open Finset BigOperators

/-! ## Property 7: Clipping Bounds and Idempotence -/

/-
PROBLEM
After clipping to [-C, C], the result satisfies |z| ≤ C.

PROVIDED SOLUTION
Unfold clip. clip C z = max (-C) (min C z). We need |max (-C) (min C z)| ≤ C. Since max (-C) (min C z) ≥ -C and max (-C) (min C z) ≤ min C z ≤ C (by cases), we get -C ≤ result ≤ C, hence |result| ≤ C. Use abs_le.
-/
theorem clip_bounds (C : ℝ) (hC : 0 ≤ C) (z : ℝ) :
    |clip C z| ≤ C := by
      unfold clip; exact abs_le.mpr ⟨ by cases max_cases ( -C ) ( min C z ) <;> cases min_cases C z <;> linarith, by cases max_cases ( -C ) ( min C z ) <;> cases min_cases C z <;> linarith ⟩ ;

/-
PROBLEM
Clipping is idempotent: clip(clip(z, C), C) = clip(z, C).

PROVIDED SOLUTION
Unfold clip. clip C z = max (-C) (min C z). Apply clip again: max (-C) (min C (max (-C) (min C z))). Since max (-C) (min C z) is already in [-C, C], min C of it equals itself, and max (-C) of it equals itself. Use linear_order properties or just split into cases on whether z ≤ -C, -C < z < C, or z ≥ C.
-/
theorem clip_idempotent (C : ℝ) (z : ℝ) :
    clip C (clip C z) = clip C z := by
      unfold clip;
      grind

/-! ## Property 8: Clipping Preserves Ordering Within Bounds -/

/-
PROBLEM
For values strictly within (-C, C), clipping preserves strict ordering.

PROVIDED SOLUTION
Unfold clip. For za in (-C, C): min C za = za (since za < C), max (-C) za = za (since za > -C). So clip C za = za. Similarly clip C zb = zb. Hence clip C za > clip C zb ↔ za > zb.
-/
theorem clip_preserves_order_within_bounds (C : ℝ) (za zb : ℝ)
    (ha_lo : -C < za) (ha_hi : za < C) (hb_lo : -C < zb) (hb_hi : zb < C) :
    clip C za > clip C zb ↔ za > zb := by
      unfold clip;
      grind

/-
PROBLEM
For values both above C, clipping maps them to the same value (information loss).

PROVIDED SOLUTION
Unfold clip. For za ≥ C: min C za = C (since za ≥ C), so clip C za = max (-C) C = C. Similarly for zb. Hence both equal C.
-/
theorem clip_information_loss_above (C : ℝ) (za zb : ℝ)
    (ha : za ≥ C) (hb : zb ≥ C) :
    clip C za = clip C zb := by
      unfold clip; aesop;

/-
PROBLEM
For values both below -C, clipping maps them to the same value.

PROVIDED SOLUTION
Unfold clip. For za ≤ -C: min C za ≤ min C (-C) = -C (since za ≤ -C ≤ C), actually min C za = za since za ≤ -C ≤ C. Then max (-C) za = -C since za ≤ -C. Similarly for zb. Both equal -C.
-/
theorem clip_information_loss_below (C : ℝ) (za zb : ℝ)
    (ha : za ≤ -C) (hb : zb ≤ -C) :
    clip C za = clip C zb := by
      unfold clip; aesop;

/-
PROBLEM
Clipping is monotone (non-decreasing).

PROVIDED SOLUTION
clip C = max (-C) ∘ min C. Both min C and max (-C) are monotone, and composition of monotone functions is monotone.
-/
theorem clip_monotone (C : ℝ) : Monotone (clip C) := by
  intro x y hxy;
  refine' max_le_max ( _ ) ( _ );
  · norm_num;
  · exact min_le_min_left _ hxy

end