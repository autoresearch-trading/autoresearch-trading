import Mathlib
import RequestProject.Definitions

/-!
# Part A, Property 4: Stationarity

If x_t is a stationary process with constant mean μ and std σ,
then the rolling z-score converges to (x_t - μ)/σ as W → ∞.

We formalize this as: if the rolling mean converges to μ and the rolling std
converges to σ > 0, then the z-score converges to (x_t - μ)/σ.
This is the deterministic core of the LLN argument.
-/

noncomputable section

open Filter Topology

/-
PROBLEM
If the rolling mean of the window ending at t converges to μ and the
rolling std converges to σ > 0, then z_t converges to (x_t - μ)/σ.

We formalize this abstractly: given sequences μ_W → μ and σ_W → σ > 0,
and a fixed value x, then (x - μ_W) / σ_W → (x - μ) / σ.

PROVIDED SOLUTION
This is a limit of (x - μ_W) / σ_W as W → ∞. Since μ_W → μ and σ_W → σ with σ > 0, by continuity of subtraction and division (with nonzero denominator), the result tends to (x - μ)/σ. Use Filter.Tendsto.div and Filter.Tendsto.sub (or Tendsto.const_sub). The key is that σ_W → σ ≠ 0 so division is continuous.
-/
theorem zscore_stationarity_limit
    (x μ σ : ℝ) (hσ : σ > 0)
    (μ_seq σ_seq : ℕ → ℝ)
    (hμ : Filter.Tendsto μ_seq Filter.atTop (nhds μ))
    (hσ_seq : Filter.Tendsto σ_seq Filter.atTop (nhds σ)) :
    Filter.Tendsto (fun W => (x - μ_seq W) / σ_seq W) Filter.atTop
      (nhds ((x - μ) / σ)) := by
        exact Filter.Tendsto.div ( tendsto_const_nhds.sub hμ ) hσ_seq hσ.ne'

end