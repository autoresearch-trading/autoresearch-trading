import Mathlib
import RequestProject.Definitions

/-!
# Part B: Robust Normalization Properties

Property 5: Breakdown point of median
Property 6: IQR = 0 edge case
-/

noncomputable section

open Finset BigOperators

/-! ## Property 5: Median Breakdown Point

The breakdown point of the median is 50%: changing fewer than ⌊n/2⌋ + 1
values in a sample cannot change the median arbitrarily.
-/

/-
PROBLEM
Breakdown point: if the number of corrupted positions is at most n
(out of 2n+1 total), then at least n+1 values agree between the original
and corrupted samples. This means the median position must contain an
unchanged value.

PROVIDED SOLUTION
The total number of indices is 2*n+1. The filter for x i ≠ y i has card ≤ n. The filter for x i = y i is the complement, so its card = (2*n+1) - card(≠ filter) ≥ (2*n+1) - n = n+1. Use Finset.filter_card_add_filter_neg_card_eq_card (or the complement counting argument).
-/
theorem median_50pct_breakdown
    (n : ℕ) (x : Fin (2 * n + 1) → ℝ) (y : Fin (2 * n + 1) → ℝ)
    (h_corrupt : Finset.card (Finset.filter (fun i => x i ≠ y i) Finset.univ) ≤ n) :
    n + 1 ≤ Finset.card (Finset.filter (fun i => x i = y i) Finset.univ) := by
      simp_all +decide [ Finset.filter_not, Finset.card_sdiff ];
      linarith

/-
PROBLEM
Mean has 0% breakdown point: a single outlier can shift the mean
by an arbitrary amount.

PROVIDED SOLUTION
Choose x where x 0 = M * n + 1 and x i = 0 for i ≠ 0 (using Fin.cases or by defining x i = if i = 0 then M*n+1 else 0). Then (1/n) * sum x_i = (1/n) * (M*n+1) = M + 1/n > M. Need to be careful with Fin indexing: use ⟨0, hn⟩ for Fin n.
-/
theorem mean_zero_breakdown (n : ℕ) (hn : 0 < n) (M : ℝ) (hM : 0 < M) :
    ∃ (x : Fin n → ℝ),
      (∀ i : Fin n, (i : ℕ) ≠ 0 → x i = 0) ∧
      |((1 : ℝ) / n) * ∑ i, x i| > M := by
        use fun i => if i = ⟨ 0, by linarith ⟩ then M * n + 1 else 0;
        simp +zetaDelta at *;
        exact ⟨ by aesop, by rw [ inv_mul_eq_div, lt_div_iff₀ ] <;> cases abs_cases ( M * n + 1 ) <;> nlinarith [ show ( n : ℝ ) ≥ 1 by norm_cast ] ⟩

/-! ## Property 6: IQR = 0 Edge Case -/

/-
PROBLEM
When IQR = 0, robust z-score reduces to centering only.

PROVIDED SOLUTION
Unfold robustZScore. The if-then-else checks iqr = 0; since iqr = 0, it returns x - median.
-/
theorem robust_zscore_iqr_zero (median x : ℝ) :
    robustZScore median 0 x = x - median := by
      unfold robustZScore; aesop;

/-
PROBLEM
When IQR = 0, the robust normalization (centering) is injective.

PROVIDED SOLUTION
Unfold robustZScore and Function.Injective. Since iqr = 0, robustZScore median 0 x = x - median. If x - median = y - median then x = y. Use sub_left_cancel or similar.
-/
theorem robust_zscore_iqr_zero_is_translation (median : ℝ) :
    Function.Injective (robustZScore median 0) := by
      unfold robustZScore; aesop_cat;

end