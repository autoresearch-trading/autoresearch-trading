import Mathlib

/-!
# Rolling Z-Score Normalization: Definitions

Core definitions for rolling z-score normalization properties.
-/

noncomputable section

open Finset BigOperators Real

/-- Rolling mean of a function over `Fin W`. -/
def rollingMean (W : ℕ) (hW : 0 < W) (x : Fin W → ℝ) : ℝ :=
  (1 / W) * ∑ i, x i

/-- Rolling variance of a function over `Fin W`. -/
def rollingVar (W : ℕ) (hW : 0 < W) (x : Fin W → ℝ) : ℝ :=
  (1 / W) * ∑ i, (x i - rollingMean W hW x) ^ 2

/-- Rolling standard deviation. -/
def rollingStd (W : ℕ) (hW : 0 < W) (x : Fin W → ℝ) : ℝ :=
  Real.sqrt (rollingVar W hW x)

/-- Z-score normalization: z_i = (x_i - μ) / σ -/
def zScore (W : ℕ) (hW : 0 < W) (x : Fin W → ℝ) (i : Fin W) : ℝ :=
  (x i - rollingMean W hW x) / rollingStd W hW x

/-- Clipping function: clip z to [-C, C]. -/
def clip (C : ℝ) (z : ℝ) : ℝ :=
  max (-C) (min C z)

/-- Robust z-score normalization using median and IQR.
    When IQR = 0, we replace it with 1 (centering only). -/
def robustZScore (median : ℝ) (iqr : ℝ) (x : ℝ) : ℝ :=
  if iqr = 0 then x - median else (x - median) / iqr

end
