import Mathlib
import RequestProject.Definitions

/-!
# Part D: Sufficiency Preservation

Property 9: Z-score preserves sufficient statistics (bijection argument)
Property 10: Clipping can destroy sufficiency (non-injectivity)
-/

noncomputable section

/-! ## Property 9: Bijective Transformations Preserve Sufficient Statistics

The key insight is that z-score with fixed μ, σ (σ > 0) is a bijection,
and bijections preserve sufficient statistics via the Fisher-Neyman
factorization theorem. -/

/-
PROBLEM
The z-score transformation (x ↦ (x - μ)/σ) with σ > 0 is a bijection.

PROVIDED SOLUTION
The function f(x) = (x - μ)/σ with σ > 0 is bijective because it has inverse g(y) = σ*y + μ. Injective: if (x₁-μ)/σ = (x₂-μ)/σ then x₁-μ = x₂-μ so x₁=x₂. Surjective: for any y, take x = σ*y + μ, then (x-μ)/σ = (σ*y)/σ = y.
-/
theorem zscore_bijective (μ σ : ℝ) (hσ : σ > 0) :
    Function.Bijective (fun x : ℝ => (x - μ) / σ) := by
      exact ⟨ fun x y h => by simpa [ div_eq_iff, hσ.ne' ] using h, fun x => ⟨ x * σ + μ, by simp [ div_eq_iff, hσ.ne' ] ⟩ ⟩

/-
PROBLEM
The z-score transformation has an inverse: x ↦ σ * x + μ.

PROVIDED SOLUTION
σ * ((x - μ) / σ) + μ = (x - μ) + μ = x. The first step uses mul_div_cancel with σ ≠ 0 (from hσ).
-/
theorem zscore_inverse (μ σ : ℝ) (hσ : σ > 0) (x : ℝ) :
    σ * ((x - μ) / σ) + μ = x := by
      rw [ mul_div_cancel₀ _ hσ.ne', sub_add_cancel ]

/-
PROBLEM
Bijective transformations preserve factorization structure.
If g : α → β is bijective and k : α → ℝ, then there exists k' : β → ℝ
such that k = k' ∘ g. This is the core of why bijections preserve
sufficient statistics via Fisher-Neyman.

PROVIDED SOLUTION
Since g is bijective, it has an inverse g⁻¹. Let k' = k ∘ g⁻¹. Then k'(g(a)) = k(g⁻¹(g(a))) = k(a). Use Function.Bijective to get the inverse via Function.invFun or surjInv, then define k' := k ∘ (Function.invFun g).
-/
theorem bijection_preserves_factorization
    {α β : Type*} (g : α → β) (hg : Function.Bijective g)
    (k : α → ℝ) :
    ∃ k' : β → ℝ, ∀ a : α, k a = k' (g a) := by
      exact ⟨ fun b => k ( Classical.choose ( hg.2 b ) ), fun a => by have := Classical.choose_spec ( hg.2 ( g a ) ) ; have := hg.1 this; aesop ⟩

/-
PROBLEM
Z-score preserves sufficient statistics: if the density factors as
    f(x; θ) = h(x) · k(T(x); θ), then since the z-score g is bijective,
    g(T(x)) also admits a factorization f(x; θ) = h(x) · k'(g(T(x)); θ).

PROVIDED SOLUTION
Use bijection_preserves_factorization with g = fun t => (t - μ)/σ and zscore_bijective to get k' such that k(a) = k'(g(a)) for all a. Then for any x, h(x) * k(T(x)) = h(x) * k'((T(x) - μ)/σ).
-/
theorem zscore_preserves_sufficiency
    {Ω : Type*} (T : Ω → ℝ) (μ σ : ℝ) (hσ : σ > 0)
    (h : Ω → ℝ) (k : ℝ → ℝ) :
    ∃ k' : ℝ → ℝ, ∀ x : Ω,
      h x * k (T x) = h x * k' ((T x - μ) / σ) := by
        use fun t => k ( σ * t + μ );
        exact fun x => by simp +decide [ mul_div_cancel₀ _ hσ.ne' ] ;

/-! ## Property 10: Clipping Can Destroy Sufficiency

Clipping is not injective on all of ℝ, so it cannot preserve the
factorization structure in general. -/

/-
PROBLEM
Clipping is not injective (when C is positive).

PROVIDED SOLUTION
Take x = C + 1 and y = C + 2. Then x ≠ y but clip C x = clip C y = C (since both ≥ C). This contradicts injectivity. Use clip_information_loss_above or unfold clip directly.
-/
theorem clip_not_injective (C : ℝ) (hC : 0 < C) :
    ¬ Function.Injective (clip C) := by
      norm_num [ Function.Injective, clip ];
      exact ⟨ C + 1, C + 2, by norm_num [ hC.le ], by norm_num ⟩

/-
PROBLEM
Concrete counterexample: two different values map to the same clipped value.

PROVIDED SOLUTION
Take x = C + 1 and y = C + 2. Then x ≠ y and clip C x = clip C y = C.
-/
theorem clip_destroys_info (C : ℝ) (hC : 0 < C) :
    ∃ x y : ℝ, x ≠ y ∧ clip C x = clip C y := by
      exact ⟨ C + 1, C + 2, by linarith, by unfold clip; norm_num [ hC.le ] ⟩

/-
PROBLEM
If a transformation is not injective, it can destroy factorization structure:
    there exist functions k such that no k' satisfies k = k' ∘ clip
    (because clip identifies distinct inputs where k differs).

PROVIDED SOLUTION
Take k = id (the identity function). Take x = C + 1 and y = C + 2. Then k x = C + 1 ≠ C + 2 = k y, but clip C x = clip C y = C (since both ≥ C).
-/
theorem non_injective_destroys_sufficiency (C : ℝ) (hC : 0 < C) :
    ∃ (k : ℝ → ℝ), ∃ x y : ℝ, k x ≠ k y ∧ clip C x = clip C y := by
      use fun x => x, C + 1, C + 2;
      unfold clip; norm_num [ hC ] ;

end