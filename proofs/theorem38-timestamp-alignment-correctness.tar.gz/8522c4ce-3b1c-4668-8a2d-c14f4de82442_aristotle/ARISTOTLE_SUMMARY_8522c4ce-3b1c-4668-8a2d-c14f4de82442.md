# Summary of changes

# Rolling Z-Score Normalization Properties — Fully Formalized and Proved

All 10 claims from the theorem statement have been formalized and machine-verified in Lean 4 with Mathlib, with zero `sorry` statements remaining. The project is organized as follows:

## File Structure

- **`RequestProject/Definitions.lean`** — Core definitions: `rollingMean`, `rollingVar`, `rollingStd`, `zScore`, `clip`, and `robustZScore`.

- **`RequestProject/PartA.lean`** — Properties 1–3:
  1. **`zscore_centering`**: The rolling mean of z-scores is exactly 0 (when σ > 0).
  2. **`zscore_unit_variance`**: The rolling variance of z-scores is exactly 1 (when σ > 0).
  3. **`zscore_order_preserving`**: Z-score preserves strict ordering within a window (x_a > x_b ↔ z_a > z_b).

- **`RequestProject/PartA4.lean`** — Property 4:
  4. **`zscore_stationarity_limit`**: If rolling mean → μ and rolling std → σ > 0, then z_t → (x_t − μ)/σ. Proved via continuity of subtraction and division with nonzero limit.

- **`RequestProject/PartB.lean`** — Properties 5–6:
  5. **`median_50pct_breakdown`**: If ≤ n out of 2n+1 values are corrupted, at least n+1 agree (50% breakdown point). Also **`mean_zero_breakdown`**: a single outlier can make the mean arbitrarily large (0% breakdown point).
  6. **`robust_zscore_iqr_zero`**: When IQR = 0, robust z-score reduces to centering (x − median). **`robust_zscore_iqr_zero_is_translation`**: This centering is injective.

- **`RequestProject/PartC.lean`** — Properties 7–8:
  7. **`clip_bounds`**: |clip(z)| ≤ C. **`clip_idempotent`**: clip(clip(z)) = clip(z).
  8. **`clip_preserves_order_within_bounds`**: For z_a, z_b ∈ (−C, C), ordering is preserved. **`clip_information_loss_above`** / **`clip_information_loss_below`**: Values beyond ±C collapse to ±C. Also **`clip_monotone`**.

- **`RequestProject/PartD.lean`** — Properties 9–10:
  9. **`zscore_bijective`**: The z-score map x ↦ (x−μ)/σ is bijective. **`bijection_preserves_factorization`**: Bijections preserve Fisher-Neyman factorization. **`zscore_preserves_sufficiency`**: Z-score preserves sufficient statistics.
  10. **`clip_not_injective`**: Clipping is not injective. **`clip_destroys_info`**: Concrete counterexample. **`non_injective_destroys_sufficiency`**: Non-injectivity destroys factorization structure (sufficiency).

All proofs compile cleanly and use only standard axioms (propext, Classical.choice, Quot.sound).
