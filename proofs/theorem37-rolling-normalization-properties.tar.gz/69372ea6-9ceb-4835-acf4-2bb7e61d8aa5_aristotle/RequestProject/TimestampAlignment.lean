import Mathlib

open Finset

namespace TimestampAlignment

/-!
# Theorem 38: Timestamp Alignment via Nearest-Before Matching

We formalize the nearest-before alignment of trade batch timestamps to orderbook
snapshot timestamps, and prove correctness, equivalence of implementations, and
edge-case properties.
-/

variable {M N : ℕ}

/-- The set of snapshot indices whose timestamps are at or before time `t`. -/
def candidates (S : Fin M → ℤ) (t : ℤ) : Finset (Fin M) :=
  Finset.univ.filter (fun j => S j ≤ t)

/-- Nearest-before alignment: returns the largest index `j` such that `S j ≤ t`,
    or `none` if no snapshot is at or before `t`. -/
noncomputable def alignIndex (S : Fin M → ℤ) (t : ℤ) : Option (Fin M) :=
  if h : (candidates S t).Nonempty then some ((candidates S t).max' h) else none

/-! ## Part A: Correctness of Nearest-Before -/

/-
PROBLEM
**Claim 1: Unique alignment.**
For each `t` with at least one `s_j ≤ t`, the aligned index is unique.
Since S is strictly increasing, there is exactly one maximum index.

PROVIDED SOLUTION
From hmax₁ applied to j₂ (using hj₂) we get j₂ ≤ j₁. From hmax₂ applied to j₁ (using hj₁) we get j₁ ≤ j₂. By antisymmetry, j₁ = j₂.
-/
theorem align_unique (S : Fin M → ℤ) (hS : StrictMono S) (t : ℤ)
    (j₁ j₂ : Fin M) (hj₁ : S j₁ ≤ t) (hj₂ : S j₂ ≤ t)
    (hmax₁ : ∀ k, S k ≤ t → k ≤ j₁) (hmax₂ : ∀ k, S k ≤ t → k ≤ j₂) :
    j₁ = j₂ := by
      grind

/-
PROBLEM
**Claim 2: No future leakage.**
The aligned snapshot timestamp is always ≤ the trade timestamp.

PROVIDED SOLUTION
Unfold alignIndex. The dif_pos branch gives j = max' of candidates. By definition of candidates (filter on S j ≤ t), max' is a member of candidates, so S j ≤ t. Use Finset.max'_mem and Finset.mem_filter.
-/
theorem align_no_leakage (S : Fin M → ℤ) (t : ℤ) (j : Fin M)
    (h : alignIndex S t = some j) : S j ≤ t := by
      unfold alignIndex at h;
      split_ifs at h ; simp_all +decide [ candidates ];
      exact h ▸ Finset.mem_filter.mp ( Finset.max'_mem _ _ ) |>.2

/-
PROBLEM
**Claim 3: Freshest available.**
The aligned index is the maximum among all valid indices.

PROVIDED SOLUTION
Unfold alignIndex. The dif_pos branch gives j = max' of candidates. For any k with S k ≤ t, k is in candidates (by mem_filter and mem_univ), so k ≤ max' = j by Finset.le_max'.
-/
theorem align_freshest (S : Fin M → ℤ) (t : ℤ) (j : Fin M)
    (h : alignIndex S t = some j) : ∀ k : Fin M, S k ≤ t → k ≤ j := by
      unfold alignIndex at h;
      norm_num +zetaDelta at *;
      obtain ⟨ h₁, rfl ⟩ := h; exact fun k hk => Finset.le_max' _ _ <| by unfold candidates; aesop;

/-
PROBLEM
**Claim 4: Staleness bound.**
If consecutive snapshot intervals are bounded by `Delta`, and the aligned index
is not the last snapshot, then the staleness `t - S j ≤ Delta`.

PROVIDED SOLUTION
Since alignIndex S t = some j, by align_freshest we know j is the max index with S j ≤ t. Let j' = ⟨j+1, hnotlast⟩. Since j is the maximum with S j ≤ t, we must have ¬(S j' ≤ t), i.e., t < S j'. So t < S ⟨j+1, hnotlast⟩. Also S j ≤ t by align_no_leakage. Therefore t - S j < S ⟨j+1, hnotlast⟩ - S j ≤ Delta by hDelta. So t - S j ≤ Delta (since t - S j < S(j+1) - S j ≤ Delta, and everything is integers so strict < gives ≤ after subtracting 1, but actually t - S j < S(j+1) - S j and S(j+1) - S j ≤ Delta gives t - S j < Delta + 1, hmm). Actually more directly: t ≤ S(j+1) - 1 (since t < S(j+1) and these are integers), so t - S j ≤ S(j+1) - 1 - S j ≤ Delta - 1 ≤ Delta. Or even simpler: t - S j < S(j+1) - S j ≤ Delta, so t - S j < Delta, but we need ≤. Actually t - S j ≤ t - S j and t < S(j+1), so t - S j < S(j+1) - S j ≤ Delta. Since these are integers, t - S j < Delta doesn't directly give ≤, but < on integers does give ≤ (t - S j ≤ Delta - 1 ≤ Delta). Wait no: a < b for integers means a ≤ b - 1, so a ≤ b. Hmm that's wrong. a < b means a + 1 ≤ b, which means a ≤ b - 1 < b, so a < b → a ≤ b. Obviously. So t - S j < S(j+1) - S j ≤ Delta gives t - S j < Delta, which gives t - S j ≤ Delta since ≤ is weaker.
-/
theorem staleness_bound (S : Fin M → ℤ) (hS : StrictMono S) (t : ℤ) (j : Fin M)
    (hj : alignIndex S t = some j) (Delta : ℤ)
    (hDelta : ∀ (i : Fin M) (hi : (i : ℕ) + 1 < M),
      S ⟨(i : ℕ) + 1, hi⟩ - S i ≤ Delta)
    (hnotlast : (j : ℕ) + 1 < M) :
    t - S j ≤ Delta := by
      contrapose! hj;
      unfold alignIndex;
      split_ifs <;> simp_all +decide [ Finset.max' ];
      refine' ne_of_gt ( lt_of_lt_of_le _ ( Finset.le_sup' _ <| Finset.mem_filter.mpr ⟨ Finset.mem_univ ⟨ j + 1, hnotlast ⟩, _ ⟩ ) );
      · exact Nat.lt_succ_self _;
      · linarith [ hDelta j hnotlast ]

/-! ## Part B: Equivalence of Implementations -/

/-- `searchsortedRight S t` counts the number of elements in `S` that are `≤ t`.
This corresponds to `np.searchsorted(S, t, side="right")` for a sorted array. -/
noncomputable def searchsortedRight (S : Fin M → ℤ) (t : ℤ) : ℕ :=
  (Finset.univ.filter (fun j : Fin M => S j ≤ t)).card

/-
PROBLEM
**Claim 5a: searchsorted equivalence (some case).**
When `searchsortedRight` returns a positive value, the alignment index equals
`searchsortedRight - 1`.

PROVIDED SOLUTION
searchsortedRight S t = card of candidates S t. Since hpos says this card > 0, candidates is nonempty. So alignIndex returns some (max' candidates). We need max' candidates = ⟨card - 1, ...⟩. Since S is StrictMono, the candidates form an initial segment of Fin M: if j is in candidates and i < j, then S i < S j ≤ t so i is in candidates too. For a set of Fin M values forming an initial segment {0, 1, ..., card-1}, the max is card - 1. Use that StrictMono S implies the filter is an initial segment, and the max of {0,...,k-1} in Fin M is k-1.
-/
theorem searchsorted_eq_align_some (S : Fin M → ℤ) (hS : StrictMono S) (t : ℤ)
    (hpos : 0 < searchsortedRight S t)
    (hcard : searchsortedRight S t ≤ M) :
    alignIndex S t = some ⟨searchsortedRight S t - 1, by omega⟩ := by
      unfold searchsortedRight alignIndex;
      split_ifs <;> simp_all +decide [ candidates ];
      · refine' le_antisymm _ _ <;> norm_num [ Finset.max' ];
        · intro b hb; exact (by
          refine' Nat.le_sub_one_of_lt _;
          refine' lt_of_lt_of_le _ ( Finset.card_mono <| show Finset.Iic b ⊆ Finset.filter ( fun j => S j ≤ t ) Finset.univ from fun x hx => Finset.mem_filter.mpr ⟨ Finset.mem_univ _, le_trans ( hS.monotone <| Finset.mem_Iic.mp hx ) hb ⟩ ) ; simp +decide [ Finset.card_map, Finset.card_range ]);
        · -- Since S is strictly monotonic, the set {j | S j ≤ t} is an initial segment of Fin M.
          have h_initial_segment : Finset.filter (fun j => S j ≤ t) Finset.univ = Finset.Iic (Finset.max' (Finset.filter (fun j => S j ≤ t) Finset.univ) ‹_›) := by
            ext j; simp [Finset.mem_Iic];
            exact ⟨ fun hj => Finset.le_max' _ _ <| by aesop, fun hj => by exact le_trans ( hS.monotone hj ) <| Finset.mem_filter.mp ( Finset.max'_mem _ ‹_› ) |>.2 ⟩;
          refine' ⟨ _, _, _ ⟩;
          exact Finset.max' ( Finset.filter ( fun j => S j ≤ t ) Finset.univ ) ‹_›;
          · exact Finset.mem_filter.mp ( Finset.max'_mem _ ‹_› ) |>.2;
          · replace h_initial_segment := congr_arg Finset.card h_initial_segment ; simp_all +decide [ Finset.card_univ ];
      · contrapose! hpos; unfold searchsortedRight at *; aesop;

/-
PROBLEM
**Claim 5b: searchsorted equivalence (none case).**
When `searchsortedRight` returns 0, there is no valid alignment.

PROVIDED SOLUTION
searchsortedRight S t = 0 means the filter (candidates) has empty card, i.e., candidates is empty, so ¬Nonempty. Then alignIndex takes the dif_neg branch and returns none.
-/
theorem searchsorted_eq_align_none (S : Fin M → ℤ) (hS : StrictMono S) (t : ℤ)
    (hzero : searchsortedRight S t = 0) :
    alignIndex S t = none := by
      grind +locals

/-
PROBLEM
**Claim 5c: searchsortedRight is bounded by M.

PROVIDED SOLUTION
searchsortedRight is the card of a filter of Finset.univ (Fin M), which has card M. Card of filter ≤ card of original. Use Finset.card_filter_le_card or card_le_card (filter_subset).
-/
theorem searchsortedRight_le (S : Fin M → ℤ) (t : ℤ) :
    searchsortedRight S t ≤ M := by
      exact le_trans ( Finset.card_filter_le _ _ ) ( by simpa )

/-
PROBLEM
**Claim 6: Linear scan pointer monotonicity.**
The key property of the linear scan is that the `ob_idx` pointer only moves forward.
Since `ob_idx` starts at 0, is bounded by M, and only increases, the total pointer
movement across N trades is at most M. Combined with N loop iterations, total work
is O(N + M).

PROVIDED SOLUTION
Directly from h_bound applied to ⟨N, lt_add_one N⟩.
-/
theorem total_pointer_bounded
    (ob_indices : Fin (N + 1) → ℕ)
    (h_init : ob_indices ⟨0, Nat.zero_lt_succ N⟩ = 0)
    (h_mono : ∀ i : Fin N, ob_indices i.castSucc ≤ ob_indices i.succ)
    (h_bound : ∀ i : Fin (N + 1), ob_indices i ≤ M) :
    ob_indices ⟨N, lt_add_one N⟩ ≤ M := by
      exact h_bound _

/-! ## Part C: Edge Cases -/

/-
PROBLEM
**Claim 7: No snapshot before first batch.**
If the first snapshot is after the trade time, alignment returns `none`.

PROVIDED SOLUTION
We need to show candidates S t is empty (not Nonempty). For any j : Fin M, since S is StrictMono and 0 ≤ j, we have S ⟨0, hM⟩ ≤ S j. Combined with t < S ⟨0, hM⟩, we get t < S j, so ¬(S j ≤ t). Thus the filter is empty and alignIndex returns none.
-/
theorem no_snapshot_before (S : Fin M → ℤ) (hS : StrictMono S)
    (t : ℤ) (hM : 0 < M)
    (hfirst : t < S ⟨0, hM⟩) :
    alignIndex S t = none := by
      -- By definition of `candidates`, we need to show that `t < S ⟨0, hM⟩` implies `candidates S t` is empty.
      have h_empty : ∀ j : Fin M, S j > t := by
        exact fun j => lt_of_lt_of_le hfirst <| hS.monotone <| Nat.zero_le _;
      grind +locals

/-
PROBLEM
**Claim 8: Multiple batches between snapshots align to the same snapshot.**
If two trade times both fall between consecutive snapshots, they align to the same index.

PROVIDED SOLUTION
Show both alignIndex S t₁ and alignIndex S t₂ equal some j. For each t ∈ {t₁, t₂}: candidates S t is nonempty (j is in it since S j ≤ t). The max' of candidates is j because: (1) j ∈ candidates, and (2) for any k > j, since S is StrictMono and k ≥ j+1, S k ≥ S ⟨j+1, hjM⟩ > t, so k ∉ candidates. Hence max' = j. Both return some j, so they're equal.
-/
theorem same_alignment_between_snapshots
    (S : Fin M → ℤ) (hS : StrictMono S)
    (t₁ t₂ : ℤ) (j : Fin M)
    (hjM : (j : ℕ) + 1 < M)
    (h₁_lo : S j ≤ t₁) (h₁_hi : t₁ < S ⟨(j : ℕ) + 1, hjM⟩)
    (h₂_lo : S j ≤ t₂) (h₂_hi : t₂ < S ⟨(j : ℕ) + 1, hjM⟩) :
    alignIndex S t₁ = alignIndex S t₂ := by
      -- By definition of `alignIndex`, since both `t₁` and `t₂` are greater than `S j` and less than `S (j + 1)`, they will both align to `j`.
      have h_even : alignIndex S t₁ = some j ∧ alignIndex S t₂ = some j := by
        have h_even : ∀ t : ℤ, S j ≤ t → t < S (⟨j + 1, hjM⟩) → alignIndex S t = some j := by
          intro t ht₁ ht₂
          unfold alignIndex
          unfold candidates
          simp [ht₁, ht₂];
          refine' ⟨ ⟨ j, _ ⟩, _ ⟩ <;> simp_all +decide [ Finset.max' ];
          refine' le_antisymm _ _ <;> simp_all +decide [ Finset.sup'_le_iff ];
          · exact fun k hk => not_lt.1 fun contra => by linarith [ hS.monotone ( show k ≥ ⟨ j + 1, hjM ⟩ from Nat.succ_le_of_lt contra ) ] ;
          · exact ⟨ j, ht₁, le_rfl ⟩;
        exact ⟨ h_even t₁ h₁_lo h₁_hi, h_even t₂ h₂_lo h₂_hi ⟩
      aesop

/-
PROBLEM
**Claim 8b: No lookahead bias.**
The aligned snapshot timestamp is ≤ both trade times (immediate from Claim 2).

PROVIDED SOLUTION
Apply align_no_leakage to both h₁ and h₂.
-/
theorem no_lookahead_bias
    (S : Fin M → ℤ) (t₁ t₂ : ℤ) (j : Fin M)
    (h₁ : alignIndex S t₁ = some j)
    (h₂ : alignIndex S t₂ = some j) :
    S j ≤ t₁ ∧ S j ≤ t₂ := by
      exact ⟨ align_no_leakage S t₁ j h₁, align_no_leakage S t₂ j h₂ ⟩

/-
PROBLEM
**Claim 9: Snapshot after all batches is never used.**
If the last snapshot is after the trade time, and the alignment returns some index j,
then j is strictly less than the last index.

PROVIDED SOLUTION
By align_no_leakage, S j ≤ t. But t < S ⟨M-1, ...⟩. If j = M-1 (i.e., (j:ℕ) = M-1), then S j = S ⟨M-1,...⟩ ≤ t < S ⟨M-1,...⟩, contradiction. So (j:ℕ) ≠ M-1, and since (j:ℕ) < M we get (j:ℕ) < M-1.
-/
theorem final_snapshot_unused (S : Fin M → ℤ) (hS : StrictMono S)
    (t : ℤ) (j : Fin M)
    (hM : 0 < M)
    (hlast : t < S ⟨M - 1, by omega⟩)
    (hj : alignIndex S t = some j) :
    (j : ℕ) < M - 1 := by
      refine' lt_of_le_of_ne ( Nat.le_sub_one_of_lt j.2 ) fun h => _;
      -- Since $j.val = M - 1$, we have $S j = S ⟨M - 1, by sorry⟩$.
      have hSJ : S j = S ⟨M - 1, Nat.sub_lt hM zero_lt_one⟩ := by
        exact congr_arg _ ( Fin.ext h );
      linarith [ align_no_leakage S t j hj ]

/-! ## Part D: Cache Consistency -/

/-- Abstract model of a deterministic hash function. -/
structure HashFunction (α β : Type*) where
  hash : α → β

/-
PROBLEM
**Claim 10a: Cache key determinism.**
Two calls with the same input produce the same key.

PROVIDED SOLUTION
rfl
-/
theorem cache_key_deterministic {α β : Type*} (H : HashFunction α β)
    (x : α) : H.hash x = H.hash x := by
      rfl

/-
PROBLEM
**Claim 10b: Parameter sensitivity.**
If the hash function is injective, changing any parameter changes the key.

PROVIDED SOLUTION
This follows directly from Function.Injective applied to hne: hinj.ne hne.
-/
theorem cache_key_injective {α β : Type*} (H : HashFunction α β)
    (hinj : Function.Injective H.hash)
    (x y : α) (hne : x ≠ y) : H.hash x ≠ H.hash y := by
      exact hinj.ne hne

/-- A cache key type for the trading system. -/
structure CacheParams where
  symbol : String
  start : ℤ
  stop : ℤ
  trade_batch : ℕ
  feature_version : ℕ
deriving DecidableEq

/-
PROBLEM
**Claim 10c: Bumping feature_version changes all cache keys.**
If only feature_version differs, the cache params are different.

PROVIDED SOLUTION
The two CacheParams structs differ in the feature_version field. Use intro h, then show v₁ = v₂ from h by congruence, contradicting hv.
-/
theorem version_bump_invalidates
    (p : CacheParams) (v₁ v₂ : ℕ) (hv : v₁ ≠ v₂) :
    { p with feature_version := v₁ } ≠ { p with feature_version := v₂ } := by
                                          grind +ring

end TimestampAlignment