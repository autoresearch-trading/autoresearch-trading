import Mathlib

/-!
# Microprice as Optimal Efficient Price Estimator

Based on Gatheral & Oomen (2010), "Zero-intelligence realized variance estimation."

We formalize the microprice in a limit order book and prove several properties:
1. Microprice as weighted midprice
2. Microprice deviation identity
3. Optimality under uniform fill probability
4. Microprice strictly dominates midprice as estimator
5. Information content of microprice deviation
-/

noncomputable section

open scoped BigOperators

/-! ## Definitions -/

/-- Best bid price, best ask price, best bid quantity, best ask quantity. -/
structure BookState where
  B : ℝ  -- best bid price
  A : ℝ  -- best ask price
  qB : ℝ  -- best bid quantity
  qA : ℝ  -- best ask quantity
  hqB : 0 < qB
  hqA : 0 < qA
  hSpread : B < A

namespace BookState

variable (s : BookState)

/-- Midprice -/
def midprice : ℝ := (s.A + s.B) / 2

/-- Spread -/
def spread : ℝ := s.A - s.B

/-- Microprice -/
def microprice : ℝ := (s.B * s.qA + s.A * s.qB) / (s.qB + s.qA)

/-- Imbalance ratio -/
def imbalance : ℝ := s.qB / (s.qB + s.qA)

/-- Microprice deviation from midprice -/
def microprice_dev : ℝ := s.microprice - s.midprice

lemma qB_add_qA_pos : 0 < s.qB + s.qA := by linarith [s.hqB, s.hqA]

lemma qB_add_qA_ne_zero : s.qB + s.qA ≠ 0 := ne_of_gt s.qB_add_qA_pos

lemma spread_pos : 0 < s.spread := by unfold spread; linarith [s.hSpread]

lemma imbalance_pos : 0 < s.imbalance := by
  unfold imbalance; exact div_pos s.hqB s.qB_add_qA_pos

lemma imbalance_lt_one : s.imbalance < 1 := by
  unfold imbalance
  rw [div_lt_one s.qB_add_qA_pos]
  linarith [s.hqA]

/-! ## Claim 1: Microprice as weighted midprice -/

/-
PROBLEM
The microprice equals the midprice plus an adjustment proportional to
the imbalance and the spread: P_micro = M + (I - 1/2) * S

PROVIDED SOLUTION
Expand all definitions (microprice, midprice, imbalance, spread) and use field_simp to clear denominators, then ring. Use s.qB_add_qA_ne_zero for the denominator.
-/
theorem microprice_eq_midprice_plus_imbalance_spread :
    s.microprice = s.midprice + (s.imbalance - 1/2) * s.spread := by
  unfold BookState.midprice BookState.microprice BookState.imbalance BookState.spread; ring;
  linarith [ inv_mul_cancel_left₀ ( show s.qA + s.qB ≠ 0 by linarith [ s.hqA, s.hqB ] ) s.B ]

/-
PROBLEM
When qB = qA (balanced book), I = 1/2

PROVIDED SOLUTION
Unfold imbalance, substitute qB = qA, then simplify: qA / (qA + qA) = qA / (2*qA) = 1/2.
-/
theorem balanced_imbalance (h : s.qB = s.qA) : s.imbalance = 1/2 := by
  rw [ BookState.imbalance, h ] ; ring ; norm_num [ s.hqA.ne' ] ;

/-
PROBLEM
When qB = qA, microprice = midprice

PROVIDED SOLUTION
Use microprice_eq_midprice_plus_imbalance_spread, then balanced_imbalance h to get I = 1/2, so (1/2 - 1/2) * S = 0.
-/
theorem balanced_microprice_eq_midprice (h : s.qB = s.qA) :
    s.microprice = s.midprice := by
  rw [BookState.microprice_eq_midprice_plus_imbalance_spread];
  rw [ show s.imbalance = 1 / 2 by exact balanced_imbalance s h ] ; ring

/-
PROBLEM
When qB > qA, I > 1/2

PROVIDED SOLUTION
Unfold imbalance. We need 1/2 < qB/(qB+qA). This is equivalent to (qB+qA)/2 < qB, i.e. qA < qB, which is the hypothesis. Use div_lt_div and rw [one_div, div_lt_div_iff].
-/
theorem imbalance_gt_half_of_qB_gt_qA (h : s.qA < s.qB) :
    1/2 < s.imbalance := by
  rw [ BookState.imbalance, div_lt_div_iff₀ ] <;> linarith [ s.hqA, s.hqB ]

/-
PROBLEM
When qB > qA, microprice > midprice

PROVIDED SOLUTION
Use microprice_eq_midprice_plus_imbalance_spread, then show (I - 1/2) * S > 0. I > 1/2 by imbalance_gt_half_of_qB_gt_qA, and S > 0 by spread_pos. Product of positives is positive.
-/
theorem microprice_gt_midprice_of_qB_gt_qA (h : s.qA < s.qB) :
    s.midprice < s.microprice := by
  rw [ BookState.midprice, BookState.microprice ] ; rw [ div_lt_div_iff₀ ] <;> nlinarith [ s.hqA, s.hqB, s.hSpread ] ;

/-! ## Claim 2: Microprice deviation identity -/

/-
PROBLEM
The deviation from midprice equals (qB - qA) / (2 * (qB + qA)) * S

PROVIDED SOLUTION
Expand microprice_dev, microprice, midprice, spread. Use field_simp with s.qB_add_qA_ne_zero to clear denominators, then ring.
-/
theorem microprice_dev_eq :
    s.microprice_dev = (s.qB - s.qA) / (2 * (s.qB + s.qA)) * s.spread := by
  -- By definition of microprice_dev, we have microprice_dev = s.microprice - s.midprice.
  rw [show s.microprice_dev = s.microprice - s.midprice from rfl];
  rw [ div_mul_eq_mul_div, eq_div_iff ] <;> norm_num [ BookState.microprice, BookState.midprice, BookState.spread ] <;> ring;
  · linarith [ mul_inv_cancel_left₀ ( show s.qA + s.qB ≠ 0 by linarith [ s.hqA, s.hqB ] ) ( s.B * s.qA ), mul_inv_cancel_left₀ ( show s.qA + s.qB ≠ 0 by linarith [ s.hqA, s.hqB ] ) ( s.A * s.qB ) ];
  · linarith [ s.hqB, s.hqA ]

/-
PROBLEM
The deviation from midprice equals (2*I - 1) * S / 2

PROVIDED SOLUTION
Expand microprice_dev, microprice, midprice, imbalance, spread. Use field_simp with s.qB_add_qA_ne_zero to clear denominators, then ring.
-/
theorem microprice_dev_eq' :
    s.microprice_dev = (2 * s.imbalance - 1) * s.spread / 2 := by
  unfold BookState.microprice_dev BookState.imbalance BookState.spread BookState.microprice BookState.midprice; ring;
  linarith [ mul_inv_cancel_left₀ ( by linarith [ s.hqA, s.hqB ] : ( s.qA + s.qB ) ≠ 0 ) s.B ]

/-! ## Claim 3: Optimality under uniform fill probability -/

/-
PROBLEM
Under the zero-intelligence model, the expected next trade price equals the microprice.
The next trade hits the ask with probability qB/(qB+qA) and the bid with probability qA/(qB+qA).

PROVIDED SOLUTION
Unfold microprice. Use field_simp with s.qB_add_qA_ne_zero, then ring.
-/
theorem expected_next_trade_eq_microprice :
    s.A * (s.qB / (s.qB + s.qA)) + s.B * (s.qA / (s.qB + s.qA)) = s.microprice := by
  unfold BookState.microprice; ring;

/-! ## Claim 4: Microprice strictly dominates midprice -/

/-
PROBLEM
Under the zero-intelligence model where P* = P_micro, MSE_micro = 0.

PROVIDED SOLUTION
sub_self then sq of zero.
-/
theorem mse_microprice_zero :
    (s.microprice - s.microprice)^2 = 0 := by
  norm_num

/-
PROBLEM
Under the zero-intelligence model, MSE_mid = ((I - 1/2) * S)^2

PROVIDED SOLUTION
Rewrite using microprice_eq_midprice_plus_imbalance_spread: midprice - microprice = -(imbalance - 1/2) * spread. Then (-(x))^2 = x^2. Ring should close it after the rewrite.
-/
theorem mse_midprice_eq :
    (s.midprice - s.microprice)^2 = ((s.imbalance - 1/2) * s.spread)^2 := by
  rw [ ← neg_sub, neg_sq, microprice_eq_midprice_plus_imbalance_spread ];
  ring

/-
PROBLEM
MSE_mid >= MSE_micro (= 0)

PROVIDED SOLUTION
sq_nonneg
-/
theorem mse_midprice_ge_mse_microprice :
    0 ≤ (s.midprice - s.microprice)^2 := by
  apply sq_nonneg

/-
PROBLEM
MSE_mid = 0 iff I = 1/2 (balanced book)

PROVIDED SOLUTION
Rewrite using mse_midprice_eq. Then ((I - 1/2) * S)^2 = 0 iff (I - 1/2) * S = 0 (by sq_eq_zero_iff). Since S > 0 (spread_pos), this is iff I - 1/2 = 0, i.e. I = 1/2. Use mul_eq_zero and spread_pos to eliminate the S=0 case.
-/
theorem mse_midprice_eq_zero_iff :
    (s.midprice - s.microprice)^2 = 0 ↔ s.imbalance = 1/2 := by
  -- By definition of $imbalance$, we know that $imbalance = \frac{qB}{qB + qA}$.
  rw [mse_midprice_eq];
  norm_num [ sub_eq_iff_eq_add, s.spread_pos.ne' ]

/-! ## Claim 5: Information content of microprice_dev -/

/-
PROBLEM
The squared microprice deviation equals (I - 1/2)^2 * S^2,
which is I-dependent * S^2.

PROVIDED SOLUTION
Rewrite microprice_dev using the identity microprice_dev = (imbalance - 1/2) * spread (from microprice_eq_midprice_plus_imbalance_spread, since microprice_dev = microprice - midprice). Then (x * y)^2 = x^2 * y^2 by mul_pow.
-/
theorem microprice_dev_sq :
    s.microprice_dev ^ 2 = (s.imbalance - 1/2)^2 * s.spread^2 := by
  -- By definition of microprice_dev, we have microprice_dev = (不平衡 - 1/2) * spread.
  have h_def : s.microprice_dev = (s.imbalance - 1 / 2) * s.spread := by
    unfold BookState.microprice_dev BookState.imbalance BookState.spread BookState.microprice BookState.midprice; ring;
    linarith [ inv_mul_cancel_left₀ ( show s.qA + s.qB ≠ 0 by linarith [ s.hqA, s.hqB ] ) s.B ];
  rw [ h_def, mul_pow ]

/-
PROBLEM
Wider spread means larger absolute microprice deviation
(for the same imbalance level).

PROVIDED SOLUTION
Rewrite both sides using microprice_dev_sq. Since s.imbalance = t.imbalance (by hI), we get (I - 1/2)^2 * s.spread^2 ≤ (I - 1/2)^2 * t.spread^2. This follows by mul_le_mul_of_nonneg_left (sq_le_sq' ... from hS and spread nonneg) (sq_nonneg _).
-/
theorem microprice_dev_sq_mono_spread (t : BookState)
    (hI : s.imbalance = t.imbalance) (hS : s.spread ≤ t.spread) :
    s.microprice_dev ^ 2 ≤ t.microprice_dev ^ 2 := by
  rw [ microprice_dev_sq, microprice_dev_sq ];
  rw [ hI ];
  exact mul_le_mul_of_nonneg_left ( pow_le_pow_left₀ ( by linarith [ s.spread_pos ] ) hS 2 ) ( sq_nonneg _ )

end BookState
end