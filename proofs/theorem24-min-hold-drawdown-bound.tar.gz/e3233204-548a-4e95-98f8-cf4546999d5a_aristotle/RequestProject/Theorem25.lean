/-
# Theorem 25: Marginal Symbol Portfolio Effect

We formalize when adding a marginal symbol to a portfolio improves or hurts
the portfolio-level Sortino ratio, under two formulations:
- Part A: Mean-of-Sortinos (as implemented in code)
- Part B: True portfolio Sortino (equal-weight, independent symbols)

## Corrections to original claims

**Claim 1 (corrected):** The original claim stated that adding symbol N+1 improves the
portfolio iff S_{N+1} > S_N * N/(N+1). This is incorrect. Since the mean-of-Sortinos
is an arithmetic mean, adding a new symbol improves (increases) the mean iff the new
symbol's Sortino exceeds the current mean: S_{N+1} > S_N. The threshold S_N * N/(N+1)
is strictly less than S_N and does not correspond to any natural improvement criterion.

**Claim 2 (corrected):** The original claim that "any symbol with Sortino > 0 always
improves a portfolio with mean Sortino > 0" is false. A symbol with Sortino = 0.01
does not improve a portfolio with mean Sortino = 10. The correct statement is that
adding any symbol with Sortino ≥ S_N preserves or improves the mean.

**Claim 3 (corrected):** The original claim that "a negative Sortino hurts iff
|S_{N+1}| > S_N/(N+1)" is incorrect. A symbol with negative Sortino always hurts
a portfolio with positive mean Sortino, since negative < positive = S_N.
-/

import Mathlib

open Finset BigOperators Real

noncomputable section

/-! ## Part A: Mean-of-Sortinos Formulation -/

/-- The mean-of-Sortinos for N symbols is the arithmetic mean of individual Sortinos. -/
def meanSortino (S : Fin n → ℝ) : ℝ :=
  (∑ i, S i) / n

/-- Adding a new symbol to the portfolio: the new mean Sortino. -/
def newMeanSortino (S : Fin n → ℝ) (s_new : ℝ) : ℝ :=
  ((∑ i, S i) + s_new) / (n + 1)

/-
PROBLEM
**Claim 1 (corrected):** Adding symbol N+1 with Sortino `s_new` to a portfolio of
N passing symbols with mean Sortino `meanSortino S` improves the portfolio mean Sortino
iff `s_new > meanSortino S`.

The original claim stated the threshold was `S_N * N/(N+1)`, which is incorrect.
The threshold for the arithmetic mean to increase is exactly the current mean.

PROVIDED SOLUTION
Unfold meanSortino and newMeanSortino. We need ((∑ S i) + s_new) / (n+1) > (∑ S i) / n ↔ s_new > (∑ S i) / n. Since n > 0 and n+1 > 0, multiply through: this is equivalent to n*((∑ S i) + s_new) > (n+1)*(∑ S i) iff n*s_new > ∑ S i iff s_new > (∑ S i)/n.
-/
theorem mean_sortino_improves_iff {n : ℕ} (hn : 0 < n) (S : Fin n → ℝ) (s_new : ℝ) :
    newMeanSortino S s_new > meanSortino S ↔ s_new > meanSortino S := by
  unfold newMeanSortino meanSortino;
  field_simp;
  constructor <;> intro h <;> linarith

/-
PROBLEM
The original (incorrect) claim 1 stated:
newMeanSortino S s_new > meanSortino S ↔ s_new > meanSortino S * n / (n + 1)
This is false. Counterexample: n = 1, S = ![10], s_new = 6.
meanSortino S = 10, threshold would be 10 * 1/2 = 5, and 6 > 5,
but newMeanSortino = (10 + 6)/2 = 8 < 10 = meanSortino S.

The original claim 1 is false: here we show the "threshold" `S_N * N/(N+1)` does NOT
correctly characterize when the portfolio improves.

PROVIDED SOLUTION
Use counterexample n=1, S = ![10], s_new = 6. Then meanSortino S = 10, newMeanSortino S 6 = 16/2 = 8 < 10, but 6 > 10 * 1/2 = 5. So the forward direction of the iff fails.
-/
theorem original_claim1_is_false :
    ¬ (∀ (n : ℕ) (hn : 0 < n) (S : Fin n → ℝ) (s_new : ℝ),
      newMeanSortino S s_new > meanSortino S ↔
        s_new > meanSortino S * n / (n + 1)) := by
  push_neg;
  use 2;
  unfold newMeanSortino meanSortino;
  norm_num [ Fin.sum_univ_succ ] at *;
  exact ⟨ fun i => if i = 0 then 0 else 1, 1 / 2, by norm_num ⟩

/-
PROBLEM
**Claim 2 (corrected):** The original claim that any symbol with positive Sortino
always improves a positive-mean portfolio is false. A correct version: adding a symbol
whose Sortino equals or exceeds the current mean preserves or improves the mean.

PROVIDED SOLUTION
From mean_sortino_improves_iff (the ≥ version): unfold definitions, the condition s_new ≥ meanSortino S directly gives newMeanSortino ≥ meanSortino by the same algebra.
-/
theorem mean_sortino_nondecreasing {n : ℕ} (hn : 0 < n) (S : Fin n → ℝ) (s_new : ℝ)
    (h : s_new ≥ meanSortino S) :
    newMeanSortino S s_new ≥ meanSortino S := by
  unfold meanSortino newMeanSortino at *;
  rw [ ge_iff_le, div_le_div_iff₀ ] at * <;> first | positivity | nlinarith [ show ( n : ℝ ) ≥ 1 by norm_cast, mul_div_cancel₀ ( ∑ i, S i ) ( by positivity : ( n : ℝ ) ≠ 0 ) ] ;

/-
PROBLEM
The original claim 2 is false: a symbol with small positive Sortino does NOT always
improve a portfolio with positive mean Sortino.

PROVIDED SOLUTION
Use counterexample n=1, S = ![10], s_new = 1. meanSortino S = 10 > 0, s_new = 1 > 0, but newMeanSortino S 1 = 11/2 = 5.5 < 10.
-/
theorem original_claim2_is_false :
    ¬ (∀ (n : ℕ) (hn : 0 < n) (S : Fin n → ℝ) (s_new : ℝ),
      meanSortino S > 0 → s_new > 0 →
        newMeanSortino S s_new > meanSortino S) := by
  push_neg ; use 3 ; norm_num;
  unfold meanSortino newMeanSortino ; exact ⟨ fun _ => 2, by norm_num, 1, by norm_num, by norm_num ⟩ ;

/-
PROBLEM
**Claim 3 (corrected):** A symbol with negative Sortino always hurts (lowers) a
portfolio with positive mean Sortino. No threshold condition is needed.

PROVIDED SOLUTION
Unfold definitions. s_new < 0 < meanSortino S, so s_new < meanSortino S. By the same algebra as mean_sortino_improves_iff (the strict < direction), newMeanSortino S s_new < meanSortino S.
-/
theorem negative_sortino_always_hurts {n : ℕ} (hn : 0 < n) (S : Fin n → ℝ) (s_new : ℝ)
    (hS : meanSortino S > 0) (hs : s_new < 0) :
    newMeanSortino S s_new < meanSortino S := by
  unfold newMeanSortino meanSortino at *; nlinarith [ mul_div_cancel₀ ( ∑ i, S i ) ( by positivity : ( n : ℝ ) ≠ 0 ), mul_div_cancel₀ ( ( ∑ i, S i ) + s_new ) ( by positivity : ( n + 1 : ℝ ) ≠ 0 ) ] ;

/-
PROBLEM
**Claim 4 (numerical, corrected):** With N=16 symbols and mean Sortino 0.161,
adding a symbol with Sortino 0.05 gives new mean (16*0.161 + 0.05)/17.
This is less than 0.161 (the portfolio worsens).

PROVIDED SOLUTION
This is a concrete numerical inequality. Just norm_num.
-/
theorem numerical_example_worsens :
    (16 * (161 / 1000 : ℝ) + 50 / 1000) / 17 < 161 / 1000 := by
  norm_num +zetaDelta at *

/-
PROBLEM
The new mean with the numerical example.

PROVIDED SOLUTION
Just norm_num / ring.
-/
theorem numerical_example_value :
    (16 * (161 / 1000 : ℝ) + 50 / 1000) / 17 = 2626 / 17000 := by
  norm_num +zetaDelta at *

/-! ## Part B: True Portfolio Sortino (Equal-Weight, Independent) -/

/-- Portfolio Sortino under independence with equal weights.
  S_P = (∑ μ_j) / √(∑ (σ_j⁻)²) · √m
We separate the √m factor since it's just annualization. -/
def portfolioSortino (mu : Fin n → ℝ) (dsig : Fin n → ℝ) (m : ℝ) : ℝ :=
  (∑ i, mu i) / Real.sqrt (∑ i, dsig i ^ 2) * Real.sqrt m

/-- Individual symbol Sortino: S_j = μ_j / σ_j⁻ · √m -/
def symbolSortino (mu_j : ℝ) (dsig_j : ℝ) (m : ℝ) : ℝ :=
  mu_j / dsig_j * Real.sqrt m

/-
PROBLEM
**Claim 5:** The exact condition for adding symbol N+1 to improve portfolio Sortino.
Under independence, S_P(N+1) > S_P(N) iff
  (M + μ)² · V > M² · (V + v)
where M = ∑μ_j, V = ∑(σ_j⁻)², μ = μ_{N+1}, v = (σ_{N+1}⁻)².
This shows the condition depends on both the new symbol's quality AND risk magnitude.

PROVIDED SOLUTION
Unfold portfolioSortino. We need (∑mu + mu_new)/sqrt(∑dsig² + dsig_new²) * sqrt(m) > (∑mu)/sqrt(∑dsig²) * sqrt(m). Since sqrt(m) > 0, cancel it. Let M = ∑mu, V = ∑dsig², mu = mu_new, v = dsig_new². We need (M+mu)/sqrt(V+v) > M/sqrt(V). Since M > 0 and M+mu > 0, and V > 0 and V+v > 0, both sides are positive. Square both sides (or cross multiply by positive sqrt values): (M+mu)²·V > M²·(V+v). Use Fin.snoc to rewrite the sums: ∑(Fin.snoc mu mu_new) = ∑mu + mu_new, and similarly for dsig². Then use div_lt_div iff with positive denominators (sqrt positive since sums positive), multiply through.
-/
theorem portfolio_sortino_improves_iff
    {n : ℕ} (mu : Fin n → ℝ) (dsig : Fin n → ℝ) (mu_new dsig_new m : ℝ)
    (hm : m > 0)
    (hV : ∑ i, dsig i ^ 2 > 0)
    (hv : dsig_new ^ 2 > 0)
    (hM : ∑ i, mu i > 0)
    (hMu : (∑ i, mu i) + mu_new > 0) :
    portfolioSortino (Fin.snoc mu mu_new) (Fin.snoc dsig dsig_new) m >
      portfolioSortino mu dsig m ↔
    ((∑ i, mu i) + mu_new) ^ 2 * (∑ i, dsig i ^ 2) >
      (∑ i, mu i) ^ 2 * ((∑ i, dsig i ^ 2) + dsig_new ^ 2) := by
  constructor;
  · intro h
    unfold portfolioSortino at h
    have h_pos : Real.sqrt m > 0 := by
      positivity
    have h_sqrt_denom_pos : Real.sqrt (∑ i, (dsig i) ^ 2) > 0 ∧ Real.sqrt (∑ i, (dsig i) ^ 2 + dsig_new ^ 2) > 0 := by
      exact ⟨ Real.sqrt_pos.mpr hV, Real.sqrt_pos.mpr ( add_pos hV hv ) ⟩
    have h_eq_zero : ((∑ i, mu i) + mu_new) / Real.sqrt (∑ i, (dsig i) ^ 2 + dsig_new ^ 2) > (∑ i, mu i) / Real.sqrt (∑ i, (dsig i) ^ 2) := by
      simp_all +decide [ Fin.sum_univ_castSucc ]
    have h_squared : ((∑ i, mu i) + mu_new) ^ 2 * (∑ i, (dsig i) ^ 2) > (∑ i, mu i) ^ 2 * (∑ i, (dsig i) ^ 2 + dsig_new ^ 2) := by
      have h_squared : ((∑ i, mu i + mu_new) / Real.sqrt (∑ i, (dsig i) ^ 2 + dsig_new ^ 2)) ^ 2 > ((∑ i, mu i) / Real.sqrt (∑ i, (dsig i) ^ 2)) ^ 2 := by
        gcongr;
      rw [ div_pow, div_pow, Real.sq_sqrt <| by positivity, Real.sq_sqrt <| by positivity ] at h_squared ; rw [ gt_iff_lt ] at * ; rw [ div_lt_div_iff₀ ] at * <;> first | positivity | linarith;
    exact h_squared;
  · intro h
    unfold portfolioSortino;
    norm_num [ Fin.sum_univ_castSucc ] at *;
    field_simp;
    nlinarith [ show 0 < Real.sqrt ( ∑ i, dsig i ^ 2 ) * ( ∑ i, mu i + mu_new ) by positivity, show 0 < Real.sqrt ( ∑ i, dsig i ^ 2 + dsig_new ^ 2 ) * ( ∑ i, mu i ) by positivity, Real.mul_self_sqrt ( show 0 ≤ ∑ i, dsig i ^ 2 by positivity ), Real.mul_self_sqrt ( show 0 ≤ ∑ i, dsig i ^ 2 + dsig_new ^ 2 by positivity ) ]

/-
PROBLEM
**Claim 6:** Diversification benefit with identical symbols.
If all N symbols have the same μ and σ⁻, then S_P(N) = S_1 · √N.
This is the independence-based diversification benefit.

PROVIDED SOLUTION
Unfold portfolioSortino and symbolSortino. The sum ∑ i, mu0 = n * mu0 and ∑ i, dsig0^2 = n * dsig0^2. So portfolioSortino = (n * mu0) / sqrt(n * dsig0^2) * sqrt(m). Since dsig0 > 0, sqrt(n * dsig0^2) = sqrt(n) * dsig0. So = (n * mu0) / (sqrt(n) * dsig0) * sqrt(m) = (n / sqrt(n)) * (mu0 / dsig0) * sqrt(m) = sqrt(n) * (mu0 / dsig0 * sqrt(m)) = symbolSortino * sqrt(n). Use Finset.sum_const, Finset.card_fin, Real.sqrt_mul, and n/sqrt(n) = sqrt(n).
-/
theorem identical_symbols_sqrt_scaling
    (mu0 dsig0 m : ℝ) (hd : dsig0 > 0) (hm : m > 0) (hn : 0 < n) :
    portfolioSortino (fun _ : Fin n => mu0) (fun _ : Fin n => dsig0) m =
      symbolSortino mu0 dsig0 m * Real.sqrt n := by
  unfold portfolioSortino symbolSortino; ring; norm_num [ hd.le, hn.ne', hm.le ] ; ring;
  grind

/-
PROBLEM
**Claim 6, corollary:** Adding an identical symbol always improves portfolio Sortino
(since √(N+1) > √N for N ≥ 1).

PROVIDED SOLUTION
By identical_symbols_sqrt_scaling (proved above), both sides simplify: LHS = symbolSortino mu0 dsig0 m * sqrt(n+1), RHS = symbolSortino mu0 dsig0 m * sqrt(n). Since mu0 > 0, dsig0 > 0, m > 0, we have symbolSortino mu0 dsig0 m = mu0/dsig0 * sqrt(m) > 0. And sqrt(n+1) > sqrt(n) since n ≥ 1 so n+1 > n ≥ 1 > 0. Therefore LHS > RHS by multiplying a positive number by a larger factor.
-/
theorem adding_identical_symbol_improves (mu0 dsig0 m : ℝ)
    (hmu : mu0 > 0) (hd : dsig0 > 0) (hm : m > 0) (hn : 0 < n) :
    portfolioSortino (fun _ : Fin (n + 1) => mu0) (fun _ : Fin (n + 1) => dsig0) m >
      portfolioSortino (fun _ : Fin n => mu0) (fun _ : Fin n => dsig0) m := by
  unfold portfolioSortino at *;
  norm_num [ hn.ne', hmu.ne', hd.ne', hm.ne' ] at *;
  rw [ Real.sqrt_mul <| by positivity, Real.sqrt_sq <| by positivity ];
  field_simp;
  nlinarith only [ show 0 < Real.sqrt n by positivity, show 0 < Real.sqrt ( n + 1 ) by positivity, Real.mul_self_sqrt ( show ( n:ℝ ) ≥ 0 by positivity ), Real.mul_self_sqrt ( show ( n + 1:ℝ ) ≥ 0 by positivity ), Real.sqrt_lt_sqrt ( by positivity ) ( by linarith : ( n:ℝ ) < n + 1 ) ]

/-
PROBLEM
**Claim 7:** Heterogeneous case — there exists a quality threshold below which adding
a symbol with positive individual Sortino hurts portfolio Sortino.

Concretely: consider a portfolio with M = ∑μ_j > 0, V = ∑(σ_j⁻)² > 0. A new symbol
with μ_new > 0, dsig_new > 0 (positive individual Sortino) can still hurt if its risk
is too large relative to its return. We show there exist concrete values where this happens.

PROVIDED SOLUTION
Use concrete values: n = 1, mu = ![1], dsig = ![1], mu_new = 0.01 (or 1/100), dsig_new = 100, m = 1. Existing portfolio Sortino = 1/sqrt(1)*sqrt(1) = 1. New portfolio: (1 + 1/100)/sqrt(1 + 10000)*1 = 1.01/sqrt(10001) < 1.01/100 < 1. So adding the symbol hurts despite positive individual Sortino. Use Fin.snoc for n=1. For the inequality, it suffices to show (1 + 1/100)/sqrt(1 + 10000) < 1/sqrt(1), i.e., (101/100)^2 * 1 < 1^2 * 10001, i.e., 10201/10000 < 10001, which is true.
-/
theorem positive_sortino_can_hurt_portfolio :
    ∃ (n : ℕ) (mu : Fin n → ℝ) (dsig : Fin n → ℝ) (mu_new dsig_new m : ℝ),
      m > 0 ∧
      (∀ i, dsig i > 0) ∧
      dsig_new > 0 ∧
      mu_new > 0 ∧  -- positive individual Sortino
      (∑ i, mu i) > 0 ∧  -- existing portfolio has positive mean
      portfolioSortino (Fin.snoc mu mu_new) (Fin.snoc dsig dsig_new) m <
        portfolioSortino mu dsig m := by
  -- Let's choose the specific values from the provided counterexample.
  use 1, ![1], ![1], 1 / 100, 100, 1;
  -- We need to verify the conditions for the chosen values.
  simp [portfolioSortino];
  rw [ div_lt_iff₀ ] <;> norm_num [ Fin.snoc ] ; nlinarith [ Real.sqrt_nonneg 10001, Real.sq_sqrt ( show 0 ≤ 10001 by norm_num ) ]

/-
PROBLEM
**Claim 7, general version:** For any existing portfolio with positive Sortino,
there exists a threshold: a new symbol with sufficiently small mean and sufficiently
large downside risk will hurt the portfolio even though its individual Sortino is positive.

PROVIDED SOLUTION
Given M = ∑mu > 0 and V = ∑dsig² > 0, choose mu_new = M/(2*n_large) for some small positive value and dsig_new very large. Concretely, let mu_new = 1 and dsig_new = 2*M/1 * sqrt(V+1)/1... Actually simpler: choose mu_new = 1 and dsig_new such that dsig_new² is very large. The condition for hurting is (M+1)²·V < M²·(V + dsig_new²), i.e., (M+1)²·V - M²·V < M²·dsig_new², i.e., (2M+1)·V < M²·dsig_new². So choose dsig_new² > (2M+1)·V/M². Let dsig_new = sqrt((2M+1)·V/M² + 1) or just pick dsig_new large enough. Since M > 0, we can find such dsig_new. Use exists with mu_new = 1 and dsig_new = (M + 1) * sqrt(V) / M + 1 or similar. Actually just use mu_new = 1 and dsig_new large. Need portfolioSortino comparison. The key insight: for fixed positive mu_new, as dsig_new → ∞, the new portfolio Sortino → (M + mu_new)/∞ * sqrt(m) = 0 < S_P(N), so for large enough dsig_new it hurts.
-/
theorem quality_threshold_exists
    {n : ℕ} (mu : Fin n → ℝ) (dsig : Fin n → ℝ) (m : ℝ)
    (hm : m > 0) (hn : 0 < n)
    (hV : ∑ i, dsig i ^ 2 > 0)
    (hM : ∑ i, mu i > 0) :
    ∃ (mu_new dsig_new : ℝ),
      mu_new > 0 ∧ dsig_new > 0 ∧
      portfolioSortino (Fin.snoc mu mu_new) (Fin.snoc dsig dsig_new) m <
        portfolioSortino mu dsig m := by
  -- Choose μ_new = 1 and dsig_new such that dsig_new² is very large.
  obtain ⟨dsig_new, hdsig⟩ : ∃ dsig_new, dsig_new > 0 ∧ ((∑ i, mu i) + 1)^2 * (∑ i, dsig i^2) < (∑ i, mu i)^2 * ((∑ i, dsig i^2) + dsig_new^2) := by
    obtain ⟨ dsig_new, hdsig ⟩ := exists_nat_gt ( ( ( ∑ i, mu i + 1 ) ^ 2 * ∑ i, dsig i ^ 2 ) / ( ( ∑ i, mu i ) ^ 2 ) );
    exact ⟨ dsig_new + 1, by positivity, by rw [ div_lt_iff₀ ( sq_pos_of_pos hM ) ] at hdsig; nlinarith [ pow_two_nonneg ( dsig_new : ℝ ) ] ⟩;
  use 1, dsig_new;
  unfold portfolioSortino;
  norm_num [ Fin.sum_univ_castSucc ] at *;
  field_simp;
  exact ⟨ hdsig.1, by nlinarith [ show 0 < ( ∑ i, mu i ) * Real.sqrt ( ∑ i, dsig i ^ 2 + dsig_new ^ 2 ) by exact mul_pos hM ( Real.sqrt_pos.mpr ( by nlinarith ) ), Real.mul_self_sqrt ( show 0 ≤ ∑ i, dsig i ^ 2 by positivity ), Real.mul_self_sqrt ( show 0 ≤ ∑ i, dsig i ^ 2 + dsig_new ^ 2 by positivity ) ] ⟩

end