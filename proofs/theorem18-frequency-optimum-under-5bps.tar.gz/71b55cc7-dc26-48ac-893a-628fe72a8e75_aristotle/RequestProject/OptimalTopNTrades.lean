import Mathlib

open Real Finset Filter Topology
open scoped BigOperators

noncomputable section

/-! ## Definitions -/

/-- Cumulative expected net return of the first n candidate trades.
    R_n = ∑_{i=1}^{n} (e_i - 2c) -/
def cumReturn (e : ℕ → ℝ) (c : ℝ) (n : ℕ) : ℝ :=
  ∑ i ∈ Finset.range n, (e (i + 1) - 2 * c)

/-- Sortino score: S(n) = R_n / (d * √n * √(m/n)) -/
def sortinoScore (e : ℕ → ℝ) (c d m : ℝ) (n : ℕ) : ℝ :=
  cumReturn e c n / (d * Real.sqrt (↑n) * Real.sqrt (m / ↑n))

/-! ## Part 1: Sortino Simplification -/

/-
PROBLEM
Key algebraic identity: √n * √(m/n) = √m for n ≥ 1 and m ≥ 0

PROVIDED SOLUTION
sqrt(n) * sqrt(m/n) = sqrt(n * (m/n)) = sqrt(m). Use Real.sqrt_mul (since n ≥ 0 as a nat cast) and then simplify n * (m/n) = m using mul_div_cancel₀ with n ≠ 0 (from 0 < n).
-/
lemma sqrt_mul_sqrt_div {m : ℝ} {n : ℕ} (hn : 0 < n) (hm : 0 ≤ m) :
    Real.sqrt (↑n) * Real.sqrt (m / ↑n) = Real.sqrt m := by
      rw [ ← Real.sqrt_mul ( Nat.cast_nonneg _ ), mul_div_cancel₀ _ ( Nat.cast_ne_zero.mpr hn.ne' ) ]

/-
PROBLEM
**Part 1**: S(n) = R_n / (d * √m).
    Under the assumption downside_std(n) = d * √n, the Sortino score simplifies
    so that maximizing S(n) over n is equivalent to maximizing R_n over n.

PROVIDED SOLUTION
Unfold sortinoScore. Use sqrt_mul_sqrt_div to replace sqrt(n) * sqrt(m/n) with sqrt(m). Then use mul_assoc to simplify d * sqrt(n) * sqrt(m/n) = d * (sqrt(n) * sqrt(m/n)) = d * sqrt(m).
-/
theorem sortino_eq_cumReturn_div (e : ℕ → ℝ) (c d m : ℝ) (hd : d ≠ 0) (hm : 0 ≤ m)
    (n : ℕ) (hn : 0 < n) :
    sortinoScore e c d m n = cumReturn e c n / (d * Real.sqrt m) := by
      unfold sortinoScore;
      rw [ mul_assoc, ← Real.sqrt_mul ( by positivity ), mul_div_cancel₀ _ ( by positivity ) ]

/-! ## Auxiliary lemmas -/

/-
PROBLEM
cumReturn satisfies the recurrence R_{n+1} = R_n + (e_{n+1} - 2c)

PROVIDED SOLUTION
Unfold cumReturn and use Finset.sum_range_succ.
-/
lemma cumReturn_succ (e : ℕ → ℝ) (c : ℝ) (n : ℕ) :
    cumReturn e c (n + 1) = cumReturn e c n + (e (n + 1) - 2 * c) := by
      exact Finset.sum_range_succ _ _

/-
PROBLEM
For a strictly decreasing sequence tending to 0, once e_{k} ≤ threshold,
    all subsequent terms are strictly below the threshold

PROVIDED SOLUTION
Since k < n and 1 ≤ k, we have 1 ≤ k and k < n. By he_dec, e n < e k ≤ 2c. So e n < 2c.
-/
lemma strict_dec_below_threshold (e : ℕ → ℝ)
    (he_dec : ∀ i j : ℕ, 1 ≤ i → i < j → e j < e i)
    {k : ℕ} (hk : 1 ≤ k) (hek : e k ≤ 2 * c)
    {n : ℕ} (hn : k < n) :
    e n < 2 * c := by
      linarith [ he_dec k n hk hn ]

/-! ## Part 2: Existence and Uniqueness of n★ -/

/-
PROBLEM
**Part 2**: There exists a unique n★ ≥ 1 such that e_{n★} > 2c and e_{n★+1} ≤ 2c.
    This n★ is the unique maximizer of the Sortino score.

PROVIDED SOLUTION
Since e tends to 0 and 2c > 0, eventually e n < 2c. So the set {n ≥ 1 | e n > 2c} is nonempty (contains 1 by he1) and finite (bounded by the eventual bound). Let n_star be the maximum element. Then e n_star > 2c. Since n_star is the maximum, e(n_star+1) ≤ 2c (if e(n_star+1) > 2c, then n_star+1 would be in the set, contradicting maximality). For uniqueness: if n1 and n2 both satisfy the conditions with n1 < n2, then e(n1+1) ≤ 2c, but since e is strictly decreasing and n2 ≥ n1+1, we have e(n2) ≤ e(n1+1) ≤ 2c, contradicting e(n2) > 2c (using he_dec when n2 > n1+1, and directly when n2 = n1+1).
-/
theorem exists_unique_nstar (e : ℕ → ℝ) (c : ℝ)
    (he_dec : ∀ i j : ℕ, 1 ≤ i → i < j → e j < e i)
    (he_lim : Tendsto e atTop (nhds 0))
    (he1 : e 1 > 2 * c) (hc : c > 0) :
    ∃! n : ℕ, n ≥ 1 ∧ e n > 2 * c ∧ e (n + 1) ≤ 2 * c := by
      obtain ⟨n, hn_max⟩ : ∃ n ≥ 1, e n > 2 * c ∧ ∀ m ≥ 1, e m > 2 * c → m ≤ n := by
        have hSet_finite : Set.Finite {n | 1 ≤ n ∧ e n > 2 * c} := by
          exact Set.finite_iff_bddAbove.2 ( by rcases ( Filter.eventually_atTop.1 ( he_lim.eventually ( gt_mem_nhds <| show 0 < 2 * c by linarith ) ) ) with ⟨ N, hN ⟩ ; exact ⟨ N, fun n hn => not_lt.1 fun contra => not_lt_of_ge ( le_of_lt <| hN n contra.le ) hn.2 ⟩ )
        generalize_proofs at *; (
        exact ⟨ Finset.max' ( hSet_finite.toFinset ) ⟨ 1, hSet_finite.mem_toFinset.mpr ⟨ by norm_num, he1 ⟩ ⟩, hSet_finite.mem_toFinset.mp ( Finset.max'_mem _ _ ) |>.1, hSet_finite.mem_toFinset.mp ( Finset.max'_mem _ _ ) |>.2, fun m hm hm' => Finset.le_max' _ _ ( hSet_finite.mem_toFinset.mpr ⟨ hm, hm' ⟩ ) ⟩)
      generalize_proofs at *; (
      -- To prove uniqueness, assume there exists another $n' \geq 1$ such that $e n' > 2c$ and $e (n' + 1) \leq 2c$.
      have h_unique : ∀ n' ≥ 1, e n' > 2 * c → e (n' + 1) ≤ 2 * c → n' = n := by
        intros n' hn'_ge_1 hn'_gt hn'_le
        by_cases hn'_lt_n : n' < n
        generalize_proofs at *; (
        linarith [ he_dec _ _ hn'_ge_1 hn'_lt_n, show e n ≤ e ( n' + 1 ) from by exact Nat.le_induction ( by linarith ) ( fun k hk ih => by linarith [ he_dec _ _ ( by linarith ) ( Nat.lt_succ_self k ) ] ) _ hn'_lt_n ]);
        exact le_antisymm ( hn_max.2.2 n' hn'_ge_1 hn'_gt ) ( not_lt.mp hn'_lt_n ) ▸ rfl
      generalize_proofs at *; (
      use n; have := hn_max.2.2 n hn_max.1 hn_max.2.1; simp +decide [ * ] ; (
      exact ⟨ not_lt.1 fun h => not_lt_of_ge ( hn_max.2.2 ( n + 1 ) ( by linarith ) h ) ( by linarith ), fun y hy hy' hy'' => h_unique y hy hy' hy'' ⟩)))

/-
PROBLEM
R_n is strictly increasing for n ≤ n★

PROVIDED SOLUTION
Since 1 ≤ n ≤ nstar, we have e n > 2c by hnstar_all. So e n - 2c > 0. By cumReturn_succ applied to n-1, cumReturn e c n = cumReturn e c (n-1) + (e n - 2c). Since e n - 2c > 0, cumReturn e c (n-1) < cumReturn e c n. Note: n ≥ 1 so (n-1)+1 = n in ℕ.
-/
lemma cumReturn_increasing (e : ℕ → ℝ) (c : ℝ) (nstar : ℕ)
    (hnstar1 : nstar ≥ 1)
    (hnstar_all : ∀ k : ℕ, 1 ≤ k → k ≤ nstar → e k > 2 * c)
    (n : ℕ) (hn1 : 1 ≤ n) (hn2 : n ≤ nstar) :
    cumReturn e c (n - 1) < cumReturn e c n := by
      -- By definition of cumReturn, we have:
      have h_diff : cumReturn e c n = cumReturn e c (n - 1) + (e n - 2 * c) := by
        convert cumReturn_succ e c ( n - 1 ) using 1 ; cases n <;> trivial;
        rw [ Nat.sub_add_cancel hn1 ];
      linarith [ hnstar_all n hn1 hn2 ]

/-
PROBLEM
For n ≤ n★, R_n ≤ R_{n★}

PROVIDED SOLUTION
By induction on the gap nstar - n. Base case: n = nstar, trivial (≤ is reflexive). Inductive step: if cumReturn e c (n+1) ≤ cumReturn e c nstar and n+1 ≤ nstar, then cumReturn e c n < cumReturn e c (n+1) ≤ cumReturn e c nstar by cumReturn_increasing. Actually, simpler: just use repeated application of cumReturn_increasing to get cumReturn e c n ≤ cumReturn e c (n+1) ≤ ... ≤ cumReturn e c nstar.
-/
lemma cumReturn_le_nstar (e : ℕ → ℝ) (c : ℝ) (nstar : ℕ)
    (hnstar1 : nstar ≥ 1)
    (hnstar_all : ∀ k : ℕ, 1 ≤ k → k ≤ nstar → e k > 2 * c)
    (n : ℕ) (hn1 : 1 ≤ n) (hn2 : n ≤ nstar) :
    cumReturn e c n ≤ cumReturn e c nstar := by
      exact Finset.sum_le_sum_of_subset_of_nonneg ( Finset.range_mono hn2 ) fun x hx _ => sub_nonneg.2 ( le_of_lt ( hnstar_all _ ( by linarith [ Finset.mem_range.1 hx ] ) ( by linarith [ Finset.mem_range.1 hx ] ) ) )

/-
PROBLEM
For n > n★, R_n < R_{n★} (assuming no e_k = 2c)

PROVIDED SOLUTION
By induction on n starting from nstar+1. Base case n = nstar+1: cumReturn e c (nstar+1) = cumReturn e c nstar + (e(nstar+1) - 2c). Since e(nstar+1) ≤ 2c and e(nstar+1) ≠ 2c (by he_ne, since nstar+1 ≥ 1), we have e(nstar+1) < 2c, so cumReturn e c (nstar+1) < cumReturn e c nstar. Inductive step: if cumReturn e c n < cumReturn e c nstar for some n > nstar, then cumReturn e c (n+1) = cumReturn e c n + (e(n+1) - 2c). Since n+1 > nstar+1 and e is strictly decreasing, e(n+1) < e(nstar+1) ≤ 2c, so e(n+1) - 2c < 0. Thus cumReturn e c (n+1) < cumReturn e c n < cumReturn e c nstar.
-/
lemma cumReturn_lt_nstar (e : ℕ → ℝ) (c : ℝ) (nstar : ℕ)
    (he_dec : ∀ i j : ℕ, 1 ≤ i → i < j → e j < e i)
    (hnstar1 : nstar ≥ 1)
    (hnstar3 : e (nstar + 1) ≤ 2 * c)
    (he_ne : ∀ n : ℕ, n ≥ 1 → e n ≠ 2 * c)
    (n : ℕ) (hn : n > nstar) :
    cumReturn e c n < cumReturn e c nstar := by
      induction hn <;> simp_all +decide [ Finset.sum_range_succ, cumReturn ];
      · cases lt_or_gt_of_ne ( he_ne ( nstar + 1 ) ( by linarith ) ) <;> linarith;
      · linarith [ he_dec ( nstar + 1 ) ( ‹_› + 1 ) ( by linarith ) ( by linarith ), show e ( ‹_› + 1 ) < 2 * c from lt_of_le_of_ne ( by linarith [ he_dec ( nstar + 1 ) ( ‹_› + 1 ) ( by linarith ) ( by linarith ) ] ) ( he_ne _ ( by linarith ) ) ]

/-
PROBLEM
n★ is the unique maximizer of R_n (and hence of S(n))

PROVIDED SOLUTION
Split on n < nstar vs n > nstar. For n < nstar: use cumReturn_le_nstar to get cumReturn e c n ≤ cumReturn e c nstar, but we need strict. Since n < nstar, n+1 ≤ nstar, so by cumReturn_increasing applied to n+1, cumReturn e c n < cumReturn e c (n+1) ≤ cumReturn e c nstar. For n > nstar: use cumReturn_lt_nstar directly. We also need hnstar_all, which says ∀ k, 1 ≤ k → k ≤ nstar → e k > 2c. This follows from: if k ≤ nstar and e k ≤ 2c, then since e is strictly decreasing, e nstar < e k ≤ 2c (if k < nstar), contradicting hnstar2. If k = nstar, e nstar > 2c by hnstar2.
-/
theorem nstar_is_unique_maximizer (e : ℕ → ℝ) (c : ℝ) (nstar : ℕ)
    (he_dec : ∀ i j : ℕ, 1 ≤ i → i < j → e j < e i)
    (hnstar1 : nstar ≥ 1)
    (hnstar2 : e nstar > 2 * c)
    (hnstar3 : e (nstar + 1) ≤ 2 * c)
    (he_ne : ∀ n : ℕ, n ≥ 1 → e n ≠ 2 * c)
    (hnstar_all : ∀ k : ℕ, 1 ≤ k → k ≤ nstar → e k > 2 * c)
    (n : ℕ) (hn1 : n ≥ 1) (hn2 : n ≠ nstar) :
    cumReturn e c n < cumReturn e c nstar := by
      cases lt_or_gt_of_ne hn2 <;> simp_all +decide [ cumReturn_succ ];
      · -- By induction on $k$, we can show that $cumReturn e c (n+k) > cumReturn e c n$ for any $k > 0$.
        have h_ind : ∀ k, 0 < k → k ≤ nstar - n → cumReturn e c (n + k) > cumReturn e c n := by
          intros k hk_pos hk_le
          induction' hk_pos with k hk ih;
          · simp [cumReturn];
            simpa [ Finset.sum_range_succ ] using by linarith [ hnstar_all ( n + 1 ) ( by linarith ) ( by linarith ) ] ;
          · rw [ Nat.add_succ, cumReturn_succ ];
            linarith [ ih ( Nat.le_of_succ_le hk_le ), hnstar_all ( n + k + 1 ) ( by linarith ) ( by omega ) ];
        simpa only [ add_tsub_cancel_of_le ( le_of_lt ‹_› ) ] using h_ind ( nstar - n ) ( Nat.sub_pos_of_lt ‹_› ) le_rfl;
      · expose_names; exact cumReturn_lt_nstar e c nstar he_dec hnstar1 hnstar3 he_ne n h

/-! ## Part 3: Adding Unprofitable Trades Reduces Sortino -/

/-
PROBLEM
**Part 3**: For n > n★, S(n) < S(n-1).
    Once the marginal edge of a newly added trade falls below 2c,
    adding that trade strictly reduces Sortino.

PROVIDED SOLUTION
By sortino_eq_cumReturn_div, sortinoScore e c d m n = cumReturn e c n / (d * sqrt m) and similarly for n-1 (since n > nstar ≥ 1, both n and n-1 are ≥ 1). So we need cumReturn e c n / (d * sqrt m) < cumReturn e c (n-1) / (d * sqrt m). Since d > 0 and m > 0, d * sqrt m > 0, so we just need cumReturn e c n < cumReturn e c (n-1). This follows from cumReturn_succ: cumReturn e c n = cumReturn e c (n-1) + (e n - 2c). Since n > nstar, and nstar ≥ 1, so n ≥ 2. If n = nstar + 1, e n = e(nstar+1) ≤ 2c and e n ≠ 2c (by he_ne), so e n < 2c. If n > nstar + 1, e n < e(nstar+1) ≤ 2c by strict decrease. Either way e n - 2c < 0.
-/
theorem sortino_decreasing_past_nstar (e : ℕ → ℝ) (c d m : ℝ)
    (he_dec : ∀ i j : ℕ, 1 ≤ i → i < j → e j < e i)
    (hd : d > 0) (hm : m > 0)
    (nstar : ℕ) (hnstar1 : nstar ≥ 1)
    (hnstar3 : e (nstar + 1) ≤ 2 * c)
    (he_ne : ∀ n : ℕ, n ≥ 1 → e n ≠ 2 * c)
    (n : ℕ) (hn : n > nstar) :
    sortinoScore e c d m n < sortinoScore e c d m (n - 1) := by
      rcases n with ( _ | _ |n ) <;> simp_all +decide [ sortinoScore ];
      -- Using the simplification from `sortino_eq_cumReturn_div`, we can rewrite the inequality.
      suffices h_suff : cumReturn e c (n + 2) < cumReturn e c (n + 1) by
        rw [ div_lt_div_iff₀ ] <;> try positivity;
        refine' lt_of_lt_of_le ( mul_lt_mul_of_pos_right h_suff _ ) _;
        · positivity;
        · rw [ mul_assoc, mul_assoc, ← Real.sqrt_mul ( by positivity ), ← Real.sqrt_mul ( by positivity ) ];
          rw [ mul_div_cancel₀ _ ( by positivity ), mul_div_cancel₀ _ ( by positivity ) ];
      rw [ cumReturn_succ, add_comm ];
      cases hn.eq_or_lt <;> simp_all +decide [ sub_lt_iff_lt_add' ];
      · exact lt_of_le_of_ne hnstar3 ( he_ne _ ( by linarith ) );
      · linarith [ he_dec ( nstar + 1 ) ( n + 1 + 1 ) ( by linarith ) ( by linarith ) ]

/-! ## Part 4: Numerical Verification -/

/-- The specific edge function for the numerical example -/
def e_numerical (n : ℕ) : ℝ := 0.003 * Real.exp (-0.05 * (↑n - 1))

/-
PROBLEM
exp(11/10) ≥ 3 (lower bound from Taylor series)

PROVIDED SOLUTION
Use Real.sum_le_exp_of_nonneg with x = 11/10 and n = 6 terms (k=0..5). The partial sum S_5(11/10) = 1 + 11/10 + (11/10)^2/2 + (11/10)^3/6 + (11/10)^4/24 + (11/10)^5/120 = 36015101/12000000. Since 36015101/12000000 > 3 (equivalently 36015101 > 36000000), we get exp(11/10) ≥ S_5(11/10) > 3. The key Mathlib lemma is Real.sum_le_exp_of_nonneg which says for x ≥ 0, the partial sums of the Taylor series are ≤ exp(x).
-/
lemma exp_eleven_tenths_ge_three : Real.exp (11 / 10 : ℝ) ≥ 3 := by
  -- We can raise both sides to the power of 10 to remove the fraction.
  have h_exp : (3 : ℝ) ^ 10 ≤ Real.exp 11 := by
    have := Real.exp_one_gt_d9.le ; norm_num at * ; rw [ show Real.exp 11 = ( Real.exp 1 ) ^ 11 by rw [ ← Real.exp_nat_mul ] ; norm_num ] ; exact le_trans ( by norm_num ) ( pow_le_pow_left₀ ( by positivity ) this _ );
  contrapose! h_exp;
  exact lt_of_le_of_lt ( by norm_num [ ← Real.exp_nat_mul ] ) ( pow_lt_pow_left₀ h_exp ( by positivity ) ( by norm_num ) )

/-
PROBLEM
exp(21/20) < 3 (upper bound)

PROVIDED SOLUTION
Use exp(21/20) = exp(1) * exp(1/20) via Real.exp_add. For exp(1): use Real.exp_bound with x=1 (|1|≤1) and n=10 to get |exp(1) - S_10(1)| ≤ 1^10 * 11/(10!*10) = 11/36288000. So exp(1) ≤ S_10(1) + 11/36288000 = 9864101/3628800 + 11/36288000 = 98641021/36288000. For exp(1/20): use Real.exp_bound with x=1/20 (|1/20|≤1) and n=3 to get |exp(1/20) - S_3(1/20)| ≤ (1/20)^3 * 4/(3!*3) = 1/36000. So exp(1/20) ≤ S_3(1/20) + 1/36000 = 50461/48000 + 1/36000. Then exp(21/20) = exp(1)*exp(1/20) ≤ product of upper bounds. Verify this product < 3 by rational arithmetic (norm_num).
-/
lemma exp_twentyone_twentieths_lt_three : Real.exp (21 / 20 : ℝ) < 3 := by
  rw [ ← Real.log_lt_log_iff ( by positivity ) ] <;> norm_num;
  rw [ div_lt_iff₀' ] <;> norm_num [ ← Real.log_rpow, Real.lt_log_iff_exp_lt ];
  have := Real.exp_one_lt_d9;
  rw [ show Real.exp 21 = ( Real.exp 1 ) ^ 21 by rw [ ← Real.exp_nat_mul ] ; norm_num ] ; exact lt_of_lt_of_le ( pow_lt_pow_left₀ this ( by positivity ) ( by norm_num ) ) ( by norm_num )

/-
PROBLEM
e_22 > 0.001 in the numerical example

PROVIDED SOLUTION
Unfold e_numerical. We need 0.003 * exp(-0.05 * (22 - 1)) > 0.001. Simplify: -0.05 * 21 = -1.05 = -(21/20). So we need 0.003 * exp(-21/20) > 0.001, i.e., exp(-21/20) > 1/3. Since exp(21/20) < 3 by exp_twentyone_twentieths_lt_three, we get exp(-21/20) = 1/exp(21/20) > 1/3.
-/
lemma e_numerical_22_gt : e_numerical 22 > 0.001 := by
  norm_num [ e_numerical ];
  rw [ ← div_lt_iff₀' ] <;> norm_num [ Real.exp_neg ];
  rw [ lt_inv_comm₀ ] <;> norm_num [ Real.exp_pos ];
  exact exp_twentyone_twentieths_lt_three

/-
PROBLEM
e_23 ≤ 0.001 in the numerical example

PROVIDED SOLUTION
Unfold e_numerical. We need 0.003 * exp(-0.05 * (23 - 1)) ≤ 0.001. Simplify: -0.05 * 22 = -1.1 = -(11/10). So we need 0.003 * exp(-11/10) ≤ 0.001, i.e., exp(-11/10) ≤ 1/3. Since exp(11/10) ≥ 3 by exp_eleven_tenths_ge_three, we get exp(-11/10) = 1/exp(11/10) ≤ 1/3.
-/
lemma e_numerical_23_le : e_numerical 23 ≤ 0.001 := by
  -- We'll use the fact that $e^{11/10} \geq 3$ to show that $e^{-11/10} \leq 1/3$.
  have h_exp_bound : (Real.exp (11 / 10) : ℝ) ≥ 3 := by
    exact exp_eleven_tenths_ge_three;
  unfold e_numerical; norm_num; nlinarith [ Real.exp_neg ( 11 / 10 ), mul_inv_cancel₀ ( ne_of_gt ( Real.exp_pos ( 11 / 10 ) ) ) ] ;

/-- **Part 4**: With c = 0.0005 and e_n = 0.003 * exp(-0.05 * (n-1)),
    we have 2c = 0.001 and the unique maximizer is n★ = 22. -/
theorem numerical_nstar_eq_22 :
    e_numerical 22 > 0.001 ∧ e_numerical 23 ≤ 0.001 := by
  exact ⟨e_numerical_22_gt, e_numerical_23_le⟩

end