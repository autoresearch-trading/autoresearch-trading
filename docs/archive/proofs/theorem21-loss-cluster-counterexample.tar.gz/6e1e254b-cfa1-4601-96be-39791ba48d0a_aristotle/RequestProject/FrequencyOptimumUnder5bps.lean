import Mathlib

noncomputable section

open Real Filter Topology

/-! # Sortino Ratio Improvement Under Transaction Costs

We formalize the theory of when adding an extra trade improves the (unannualized)
Sortino ratio S_n = A_n / √V_n, where A_n is the cumulative net edge and V_n is
the cumulative downside variance.

## Main results

* `sortino_improvement_iff` — Claims 1 & 2: S_{n+1} > S_n iff a_{n+1} > correction term
* `sortino_improvement_mu` — Restated in terms of gross return μ and cost c
* `correction_term_strictMono` — Claim 3: break-even edge is strictly increasing in n
* `correction_term_tendsto` — Claim 3: break-even edge converges to a/2
* `breakeven_lt_125bps` — Claim 4: break-even < 12.5 bps under 5 bps per side
* `always_improves` — Claim 4: μ = 15 bps always exceeds break-even
-/

/-- The correction term for adding a new trade:
    `correctionTerm An Vn vn1 = An * (√(1 + vn1/Vn) - 1)` -/
def correctionTerm (An Vn vn1 : ℝ) : ℝ :=
  An * (Real.sqrt (1 + vn1 / Vn) - 1)

/-- The Sortino score of the portfolio: `S = A / √V` -/
def sortinoScore (A V : ℝ) : ℝ := A / Real.sqrt V

-- ============================================================================
-- Claims 1 & 2: Sortino improvement criterion
-- ============================================================================

/-- **Claims 1 & 2.** The Sortino ratio improves when adding trade n+1 if and only if
    the net edge `a_{n+1}` exceeds the correction term `A_n * (√(1 + v_{n+1}/V_n) - 1)`. -/
theorem sortino_improvement_iff (An Vn an1 vn1 : ℝ)
    (hVn : 0 < Vn) (hvn1 : 0 < vn1) :
    sortinoScore (An + an1) (Vn + vn1) > sortinoScore An Vn ↔
    an1 > correctionTerm An Vn vn1 := by
  unfold sortinoScore correctionTerm
  field_simp
  rw [Real.sqrt_div (by positivity), mul_sub]; ring_nf
  norm_num [hVn.le, hvn1.le, hVn.ne', hvn1.ne']
  field_simp [hVn.ne']

/-- **Claims 1 & 2 (gross return form).** Restated with gross return μ and per-side cost c:
    S_{n+1} > S_n ↔ μ_{n+1} > 2c + A_n * (√(1 + v_{n+1}/V_n) - 1). -/
theorem sortino_improvement_mu (An Vn mu c vn1 : ℝ)
    (hVn : 0 < Vn) (hvn1 : 0 < vn1) :
    sortinoScore (An + (mu - 2 * c)) (Vn + vn1) > sortinoScore An Vn ↔
    mu > 2 * c + correctionTerm An Vn vn1 := by
  have h := sortino_improvement_iff An Vn (mu - 2 * c) vn1 hVn hvn1
  unfold correctionTerm at *
  constructor
  · intro h1; linarith [h.mp h1]
  · intro h1; exact h.mpr (by linarith)

-- ============================================================================
-- Rationalization identity
-- ============================================================================

/-- **Rationalization identity.** For n > 0,
    `n * (√(1 + 1/n) - 1) = 1 / (√(1 + 1/n) + 1)`.
    This follows from multiplying the LHS by `(√(1+1/n) + 1)/(√(1+1/n) + 1)`
    and using the difference-of-squares identity `(√x - 1)(√x + 1) = x - 1`. -/
theorem rationalize_sqrt_identity (n : ℝ) (hn : 0 < n) :
    n * (Real.sqrt (1 + 1 / n) - 1) = 1 / (Real.sqrt (1 + 1 / n) + 1) := by
  rw [eq_div_iff] <;>
    nlinarith [Real.mul_self_sqrt (show 0 ≤ 1 + 1 / n by positivity),
      Real.sqrt_nonneg (1 + 1 / n), one_div_mul_cancel hn.ne']

-- ============================================================================
-- Claim 3: Monotonicity and convergence
-- ============================================================================

/-- The rationalized form g(x) = 1/(√(1 + 1/x) + 1) is strictly increasing for x > 0. -/
lemma inv_sqrt_succ_strictMono :
    StrictMonoOn (fun x : ℝ => 1 / (Real.sqrt (1 + 1 / x) + 1)) (Set.Ioi 0) := by
  norm_num [StrictMonoOn]
  intros; gcongr

/-- **Claim 3 (monotonicity).** The break-even edge `n * a * (√(1+1/n) - 1)` is strictly
    increasing in n for n ≥ 1.

    *Proof sketch.* Via the rationalization identity, the expression equals
    `a / (√(1+1/n) + 1)`, which is increasing because the denominator decreases. -/
theorem correction_term_strictMono (a : ℝ) (ha : 0 < a) (n : ℕ) (hn : 1 ≤ n) :
    (n : ℝ) * a * (Real.sqrt (1 + 1 / (n : ℝ)) - 1) <
    ((n : ℝ) + 1) * a * (Real.sqrt (1 + 1 / ((n : ℝ) + 1)) - 1) := by
  have h_rat : (n : ℝ) * (Real.sqrt (1 + 1 / n) - 1) =
      1 / (Real.sqrt (1 + 1 / n) + 1) := by
    field_simp [hn]; ring_nf
    rw [Real.sq_sqrt] <;>
      nlinarith [mul_inv_cancel₀ (by positivity : (n : ℝ) ≠ 0)]
  have h_rat_succ : ((n : ℝ) + 1) * (Real.sqrt (1 + 1 / (n + 1)) - 1) =
      1 / (Real.sqrt (1 + 1 / (n + 1)) + 1) := by
    rw [eq_div_iff] <;>
      nlinarith [Real.mul_self_sqrt (show 0 ≤ 1 + 1 / (n + 1 : ℝ) by positivity),
        Real.sqrt_nonneg (1 + 1 / (n + 1 : ℝ)),
        one_div_mul_cancel (by positivity : (n + 1 : ℝ) ≠ 0)]
  rw [mul_right_comm, mul_right_comm ((n : ℝ) + 1) a]
  exact mul_lt_mul_of_pos_right
    (by rw [h_rat, h_rat_succ]; gcongr; norm_num) ha

/-- **Claim 3 (convergence).** The break-even edge converges to `a/2` as n → ∞.

    *Proof sketch.* By rationalization, the expression equals `a / (√(1+1/n) + 1)`.
    As n → ∞, 1/n → 0, so √(1+1/n) → 1, and the expression → a/2. -/
theorem correction_term_tendsto (a : ℝ) :
    Tendsto (fun n : ℕ => (n : ℝ) * a * (Real.sqrt (1 + 1 / (n : ℝ)) - 1))
      atTop (𝓝 (a / 2)) := by
  suffices h : Tendsto (fun n : ℕ => a * (1 / (Real.sqrt (1 + 1 / (n : ℝ)) + 1)))
      atTop (nhds (a / 2)) by
    refine h.congr' ?_
    filter_upwards [Filter.eventually_gt_atTop 0] with n hn
    field_simp [hn]; ring_nf
    rw [Real.sq_sqrt <| by positivity]; norm_num [hn.ne']; ring_nf
    norm_num [hn.ne']
  exact le_trans
    (tendsto_const_nhds.mul
      (tendsto_const_nhds.div
        (Tendsto.add (Tendsto.sqrt <| tendsto_const_nhds.add <|
          tendsto_one_div_atTop_nhds_zero_nat) tendsto_const_nhds)
        <| by positivity))
    <| by ring_nf; norm_num

-- ============================================================================
-- Claim 4: Numerical bound under 5 bps per side
-- ============================================================================

/-- For n > 0 (real), `1/(√(1+1/n) + 1) < 1/2` since `√(1+1/n) > 1`. -/
lemma rationalized_lt_half (n : ℝ) (hn : 0 < n) :
    1 / (Real.sqrt (1 + 1 / n) + 1) < 1 / 2 := by
  gcongr
  nlinarith [Real.sqrt_nonneg (1 + 1 / n),
    Real.sq_sqrt (by positivity : 0 ≤ 1 + 1 / n), one_div_pos.2 hn]

/-- For n ≥ 1 (natural), `n * (√(1+1/n) - 1) < 1/2`.
    Follows from rationalization and `rationalized_lt_half`. -/
lemma correction_factor_lt_half (n : ℕ) (hn : 1 ≤ n) :
    (n : ℝ) * (Real.sqrt (1 + 1 / (n : ℝ)) - 1) < 1 / 2 := by
  have := rationalized_lt_half n (Nat.cast_pos.mpr hn)
  convert this using 1
  rw [rationalize_sqrt_identity _ (by positivity)]

/-- **Claim 4 (break-even bound).** Under 5 bps per side (c = 0.0005), with a = 0.0005,
    the break-even gross edge `μ_break(n) = 0.001 + 0.0005 * n * (√(1+1/n) - 1)`
    is strictly below 0.00125 = 12.5 bps for every n ≥ 1.

    *Proof.* Since `n * (√(1+1/n) - 1) < 1/2`, we get
    `0.0005 * n * (√(1+1/n) - 1) < 0.00025`, so the total is < 0.00125. -/
theorem breakeven_lt_125bps (n : ℕ) (hn : 1 ≤ n) :
    0.001 + 0.0005 * ((n : ℝ) * (Real.sqrt (1 + 1 / (n : ℝ)) - 1)) < 0.00125 := by
  linarith [correction_factor_lt_half n hn]

/-- **Claim 4 (no finite optimum).** With μ = 0.0015 (15 bps gross) and c = 0.0005
    (5 bps per side), the gross return exceeds the break-even for every n ≥ 1.
    Hence every additional trade improves Sortino, and there is no finite maximum
    profitable trade count. -/
theorem always_improves (n : ℕ) (hn : 1 ≤ n) :
    (0.0015 : ℝ) > 0.001 + 0.0005 * ((n : ℝ) * (Real.sqrt (1 + 1 / (n : ℝ)) - 1)) := by
  linarith [breakeven_lt_125bps n hn]

end
