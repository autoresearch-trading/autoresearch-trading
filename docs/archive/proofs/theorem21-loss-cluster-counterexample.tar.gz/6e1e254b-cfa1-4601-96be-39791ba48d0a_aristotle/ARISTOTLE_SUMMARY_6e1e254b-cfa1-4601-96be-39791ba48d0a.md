# Summary of changes
All four claims have been formalized and proved in Lean 4 in `RequestProject/FrequencyOptimumUnder5bps.lean`. The file builds cleanly with no `sorry` and uses only standard axioms (`propext`, `Classical.choice`, `Quot.sound`).

## Summary of formalized results

### Claims 1 & 2 — Sortino improvement criterion (`sortino_improvement_iff`, `sortino_improvement_mu`)
Proved that S_{n+1} > S_n if and only if a_{n+1} > A_n · (√(1 + v_{n+1}/V_n) - 1), and equivalently μ_{n+1} > 2c + A_n · (√(1 + v_{n+1}/V_n) - 1). The proof clears fractions using positivity of the sqrt denominators and applies the Mathlib `sqrt_div` identity.

### Rationalization identity (`rationalize_sqrt_identity`)
Proved that n · (√(1 + 1/n) - 1) = 1/(√(1 + 1/n) + 1) for n > 0, via the difference-of-squares identity (√x - 1)(√x + 1) = x - 1. This identity is the key technical tool for Claims 3 and 4.

### Claim 3 — Monotonicity and convergence (`correction_term_strictMono`, `correction_term_tendsto`)
- **Monotonicity**: The break-even edge n·a·(√(1+1/n) - 1) is strictly increasing in n for n ≥ 1. Via rationalization, this reduces to showing 1/(√(1+1/n) + 1) is increasing, which follows because the denominator decreases.
- **Convergence**: The break-even edge converges to a/2 as n → ∞. Via rationalization, this reduces to 1/(√(1+1/n) + 1) → 1/2, which follows from continuity of sqrt and 1/n → 0.

### Claim 4 — Numerical bound under 5 bps (`breakeven_lt_125bps`, `always_improves`)
- Proved that μ_break(n) < 0.00125 for all n ≥ 1 by showing n·(√(1+1/n) - 1) < 1/2 (since √(1+1/n) > 1 implies the denominator exceeds 2).
- Proved that μ = 0.0015 exceeds the break-even for every n ≥ 1, confirming there is no finite maximum profitable trade count in the homogeneous model.