import Mathlib

/-!
# Theorem 20: MinHoldBarrierWinRateSurface

We formalize four claims about a symmetric triple-barrier trading strategy
driven by a one-dimensional Brownian motion with drift.

## Setup

Let X_t = μt + σW_t be Brownian motion with drift μ ∈ ℝ, volatility σ > 0,
starting at X₀ = 0. Fix barrier width B > 0, maximum holding time M > 0,
and minimum holding time H with 0 < H ≤ M.

The strategy ignores barriers before time H, then exits at the first barrier
hit after H, or at time M if no barrier is hit. The take-profit event is
{τ_B ≤ M ∧ X_{τ_B} = B}.

## Part 1: Frequency Bound
If every open trade must be held for at least H > 0 time units, and trades
are non-overlapping, then the long-run trade frequency f satisfies f ≤ 1/H.

## Part 2: Strong Markov Representation
The conditional win probability p(H; μ, σ, B) = E[q(X_H) | τ_B ≥ H] via
the strong Markov property.

## Part 3: Brownian Scaling
The win probability depends only on two dimensionless parameters
α = μB/σ² and β = σ²H/B². In the zero-drift case the difference
p(800) - p(200) = 0.

## Part 4: Sortino Ratio Maximizer
Existence and uniqueness (under strict concavity) of the optimal
minimum holding time.
-/

open scoped NNReal

noncomputable section

/-
PROBLEM
============================================================================
Part 1: Frequency Bound
============================================================================

If `n` non-overlapping trades each take at least `H > 0` time within
a total time window `T`, then the frequency `n / T ≤ 1 / H`.

PROVIDED SOLUTION
We have n * H ≤ T with H > 0, T > 0. We need n/T ≤ 1/H, equivalently n * H ≤ T * 1 = T (after clearing denominators). This is exactly the hypothesis h_total. Use div_le_div or rearrange using positivity of H and T.
-/
theorem frequency_bound
    {n : ℕ} {T H : ℝ}
    (hH : 0 < H) (hT : 0 < T)
    (h_total : (n : ℝ) * H ≤ T) :
    (n : ℝ) / T ≤ 1 / H := by
  rw [ div_le_div_iff₀ ] <;> linarith

-- ============================================================================
-- Part 2: Strong Markov Representation of Win Probability
-- ============================================================================

/-- The two-barrier hitting-probability function q(x) for drift μ ≠ 0. -/
def q_nonzero (mu sigma B x : ℝ) : ℝ :=
  (1 - Real.exp (-2 * mu * (x + B) / sigma ^ 2)) /
  (1 - Real.exp (-4 * mu * B / sigma ^ 2))

/-- The two-barrier hitting-probability function q(x) for drift μ = 0. -/
def q_zero (B x : ℝ) : ℝ :=
  (x + B) / (2 * B)

/-- The combined hitting-probability function. -/
def q_barrier (mu sigma B x : ℝ) : ℝ :=
  if mu = 0 then q_zero B x else q_nonzero mu sigma B x

/-
PROBLEM
q(B) = 1: starting at the upper barrier, probability of hitting it is 1.

PROVIDED SOLUTION
Unfold q_barrier. Case split on mu = 0. If mu = 0: q_zero B B = (B + B)/(2*B) = 1. If mu ≠ 0: q_nonzero mu sigma B B = (1 - exp(-2*mu*(B+B)/sigma^2)) / (1 - exp(-4*mu*B/sigma^2)). Note B+B = 2B so the exponent in numerator is -4*mu*B/sigma^2, same as denominator. So numerator = denominator, ratio = 1.
-/
theorem q_barrier_at_B {mu sigma B : ℝ} (hB : 0 < B) (hsigma : 0 < sigma) :
    q_barrier mu sigma B B = 1 := by
  -- We'll use the fact that if the denominator is non-zero, then the fraction simplifies to 1.
  by_cases hmu : mu = 0;
  · -- Substitute $x = B$ into the definition of $q_zero$ and simplify.
    simp [hmu, q_zero]
    field_simp [hB];
    unfold q_barrier q_zero; norm_num [ hB.ne' ] ;
    rw [ div_eq_iff ] <;> linarith;
  · unfold q_barrier q_nonzero;
    rw [ if_neg hmu, div_eq_iff ] <;> ring ; norm_num [ hmu, hsigma.ne', hB.ne' ];
    rw [ sub_eq_zero, eq_comm, Real.exp_eq_one_iff ] ; aesop

/-
PROBLEM
q(-B) = 0: starting at the lower barrier, probability of hitting
the upper barrier first is 0.

PROVIDED SOLUTION
Unfold q_barrier. Case split on mu = 0. If mu = 0: q_zero B (-B) = (-B + B)/(2*B) = 0/(2*B) = 0. If mu ≠ 0: q_nonzero mu sigma B (-B) = (1 - exp(-2*mu*(-B+B)/sigma^2)) / (1 - exp(-4*mu*B/sigma^2)) = (1 - exp(0)) / denom = (1 - 1)/denom = 0/denom = 0.
-/
theorem q_barrier_at_neg_B {mu sigma B : ℝ} (hB : 0 < B) (_hsigma : 0 < sigma) :
    q_barrier mu sigma B (-B) = 0 := by
  unfold q_barrier;
  unfold q_zero q_nonzero; aesop;

/-- **Strong Markov Representation.**
The conditional win probability equals the conditional expectation
E[q(X_H) | τ_B ≥ H] by the strong Markov property of Brownian motion.

Since full Brownian motion infrastructure is beyond current Mathlib, we
axiomatize the strong Markov property and derive the conclusion. The key
insight is that conditional on {τ_B ≥ H}, the process restarts at position
X_H, and from position x ∈ (-B, B) the probability of hitting B before -B
is exactly q(x). Taking conditional expectations gives p = E[q(X_H) | τ_B ≥ H]. -/
theorem strong_markov_representation
    (p_win cond_exp_q : ℝ)
    (h_markov : p_win = cond_exp_q) :
    p_win = cond_exp_q :=
  h_markov

/-
PROBLEM
============================================================================
Part 3: Brownian Scaling
============================================================================

**Brownian Scaling.** There exists a deterministic function F such that
the win probability p(H; μ, σ, B) = F(μB/σ², σ²H/B²).

The proof uses two scaling properties of Brownian motion:
1. **Spatial scaling**: multiplying the process by a > 0 scales μ, σ, B by a.
2. **Temporal scaling**: speeding up time by c > 0 scales H by 1/c,
   μ by c, and σ by √c.

Using spatial scaling with a = 1/B normalizes B = 1.
Then temporal scaling with c = B²/σ² normalizes σ = 1.
The result is p = F(μB/σ², σ²H/B²) where F(α,β) = p(β, α, 1, 1).

PROVIDED SOLUTION
Define F(α, β) := p β α 1 1. We show p H mu sigma B = p (sigma^2*H/B^2) (mu*B/sigma^2) 1 1.

Step 1: Apply h_spatial with a = 1/B (positive since B > 0):
p H mu sigma B = p H ((1/B)*mu) ((1/B)*sigma) ((1/B)*B) = p H (mu/B) (sigma/B) 1

Step 2: Apply h_temporal with c = (sigma/B)^2 (positive since sigma > 0, B > 0).
Note sigma/B > 0, so (sigma/B)^2 > 0. Also sigma/B > 0 so h_temporal applies.
sqrt((sigma/B)^2) = sigma/B (since sigma/B > 0, use Real.sqrt_sq).

p H (mu/B) (sigma/B) 1 = p (H / (sigma/B)^2) ((mu/B) * (sigma/B)^2) ((sigma/B) * (sigma/B)) 1
= p (H * B^2/sigma^2) (mu * sigma^2 / B^3 ...

Wait, let me redo this. After step 1 we have p H (mu/B) (sigma/B) 1.

h_temporal says: p H' mu' sigma' B' c = p (H'/c) (mu'*c) (sigma' * sqrt(c)) B' when sigma' > 0 and c > 0.

With H' = H, mu' = mu/B, sigma' = sigma/B, B' = 1, c = B^2/sigma^2:
- H'/c = H / (B^2/sigma^2) = H*sigma^2/B^2 = sigma^2*H/B^2 ✓
- mu'*c = (mu/B) * (B^2/sigma^2) = mu*B/sigma^2 ✓
- sigma' * sqrt(c) = (sigma/B) * sqrt(B^2/sigma^2) = (sigma/B) * (B/sigma) = 1 ✓
- B' = 1 ✓

So p H mu sigma B = p (sigma^2*H/B^2) (mu*B/sigma^2) 1 1 = F(mu*B/sigma^2, sigma^2*H/B^2). QED.

For sqrt(B^2/sigma^2) = B/sigma: use Real.sqrt_div_self' or Real.sqrt_sq with B/sigma > 0.
Actually, sqrt(B^2/sigma^2) = sqrt((B/sigma)^2) = |B/sigma| = B/sigma since B > 0, sigma > 0.
-/
theorem brownian_scaling_existence
    (p : ℝ → ℝ → ℝ → ℝ → ℝ)
    (h_spatial : ∀ (H mu sigma B a : ℝ), 0 < a →
      p H mu sigma B = p H (a * mu) (a * sigma) (a * B))
    (h_temporal : ∀ (H mu sigma B c : ℝ), 0 < sigma → 0 < c →
      p H mu sigma B = p (H / c) (mu * c) (sigma * Real.sqrt c) B) :
    ∃ F : ℝ → ℝ → ℝ,
      ∀ (H mu sigma B : ℝ), 0 < sigma → 0 < B → 0 < H →
        p H mu sigma B = F (mu * B / sigma ^ 2) (sigma ^ 2 * H / B ^ 2) := by
  use fun x y => p ( y ) ( x ) 1 1;
  intros H mu sigma B hsigma hB hH
  have := h_spatial H mu sigma B (1 / B) (by positivity)
  have := h_temporal H (mu / B) (sigma / B) 1 (B^2 / sigma^2) (by positivity) (by positivity);
  simp_all +decide [ ne_of_gt, division_def ];
  convert this using 1 <;> norm_num [ hsigma.le, hB.le, ne_of_gt hsigma, ne_of_gt hB, ne_of_gt hH, mul_assoc, mul_comm, mul_left_comm, sq ] ; ring;
  norm_num [ sq, mul_assoc, hsigma.ne', hB.ne' ]

/-
PROBLEM
In the zero-drift case μ = 0, the win probability is 1/2 for all H
by symmetry of Brownian motion, so the difference p(800) - p(200) = 0.

PROVIDED SOLUTION
Apply h_sym twice: p 800 = 1/2 (using 800 > 0) and p 200 = 1/2 (using 200 > 0). Then 1/2 - 1/2 = 0.
-/
theorem zero_drift_win_prob_difference
    (p : ℝ → ℝ)
    (h_sym : ∀ H : ℝ, 0 < H → p H = 1 / 2) :
    p 800 - p 200 = 0 := by
  norm_num [ h_sym ]

/-
PROBLEM
============================================================================
Part 4: Sortino Ratio Maximizer
============================================================================

**Existence of Sortino ratio maximizer.** Any real-valued function
on a nonempty finite type attains its maximum.

PROVIDED SOLUTION
Use Finite.exists_max. Fin M is nonempty since M > 0, and ℝ has a linear order. So there exists x₀ : Fin M such that for all x, S x ≤ S x₀.
-/
theorem sortino_maximizer_exists
    (M : ℕ) (hM : 0 < M)
    (S : Fin M → ℝ) :
    ∃ H_star : Fin M, ∀ H : Fin M, S H ≤ S H_star := by
  simpa using Finset.exists_max_image Finset.univ ( fun x => S x ) ⟨ ⟨ 0, hM ⟩, Finset.mem_univ _ ⟩ ;

/-- A function on `Fin M` is strictly concave (as a function of the
natural number index) if for all i < j < k in range,
S(j) > weighted average of S(i) and S(k). -/
def StrictlyConcaveOnFin (M : ℕ) (S : Fin M → ℝ) : Prop :=
  ∀ (i j k : Fin M),
    i < j → j < k →
    S j > ((k.val - j.val : ℝ) * S i + (j.val - i.val : ℝ) * S k) /
           (k.val - i.val : ℝ)

/-
PROBLEM
**Uniqueness of Sortino ratio maximizer under strict concavity.**
If S is strictly concave on Fin M and injective (no ties), then the
maximizer is unique. Injectivity rules out adjacent equal maxima, which
strict concavity on a discrete set cannot prevent on its own.

PROVIDED SOLUTION
Step 1 (Existence): Use sortino_maximizer_exists (or Finite.exists_max) to get H_star with S H ≤ S H_star for all H.

Step 2 (Uniqueness): Suppose H1 and H2 are both global maximizers with H1 ≠ H2. WLOG assume H1 < H2 (using the linear order on Fin M).

Case 1: H2.val - H1.val ≥ 2. Then there exists j : Fin M with H1 < j < H2 (take j = ⟨H1.val + 1, ...⟩). By strict concavity (h_concave H1 j H2), S j > weighted average of S(H1) and S(H2). Since S(H1) = S(H2) = max value, the weighted average equals max. So S(j) > max, contradicting that S(H_star) is the maximum.

Case 2: H2.val = H1.val + 1 (adjacent). Since h_inj is Function.Injective S and H1 ≠ H2, we have S(H1) ≠ S(H2). But both are maximizers so S(H1) = S(H2) = max. Contradiction.

So no two distinct maximizers exist, proving uniqueness.
-/
theorem sortino_maximizer_unique
    (M : ℕ) (hM : 1 < M)
    (S : Fin M → ℝ)
    (_h_concave : StrictlyConcaveOnFin M S)
    (h_inj : Function.Injective S) :
    ∃! H_star : Fin M, ∀ H : Fin M, S H ≤ S H_star := by
  obtain ⟨ H_star, hH_star ⟩ := sortino_maximizer_exists M (by omega) S
  exact ⟨H_star, hH_star, fun H hH => h_inj (le_antisymm (hH_star H) (hH H_star))⟩

end