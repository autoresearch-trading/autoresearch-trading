import Mathlib

/-!
# Min-Hold Drawdown Bound (Theorem 24)

We formalize the relationship between minimum holding period, trade frequency, win rate,
and the probability of exceeding a maximum drawdown threshold.

## Main Definitions

- `equityProcess`: The equity process E_k = init + Σ_{i<k} X_i
- `maxDrawdown`: Maximum drawdown MDD_T = max_{0 ≤ i ≤ j ≤ T} (E_i - E_j)
- `hasConsecRun`: Predicate for existence of a consecutive run
- `tMax`: Maximum number of trades T_max = ⌊N / H⌋

## Main Results

1. MDD ≥ L · k for any consecutive losing streak of length k (deterministic)
2. MDD is non-decreasing in T (deterministic monotonicity)
3. Existence of bad outcome sequences for large T (T_safe finiteness)
4. Numerical T_max computations
5. Sortino-drawdown tradeoff and optimal T*
-/

open Finset

noncomputable section

/-! ## Part 0: Basic Definitions -/

/-- Maximum number of trades given N total steps and minimum holding period H -/
def tMax (N H : ℕ) : ℕ := N / H

/-- Equity process: E_k = init + Σ_{i<k} outcomes(i).
    `outcomes i` is the P&L of the i-th trade. -/
def equityProcess (outcomes : ℕ → ℝ) (init : ℝ) (k : ℕ) : ℝ :=
  init + ∑ i ∈ Finset.range k, outcomes i

/-- Partial sum of the first k outcomes (equity without initial value). -/
def partialSum (outcomes : ℕ → ℝ) (k : ℕ) : ℝ :=
  ∑ i ∈ Finset.range k, outcomes i

/-- Maximum drawdown over the first T trades.
    MDD_T = max_{0 ≤ i ≤ j ≤ T} (partialSum(i) - partialSum(j)). -/
def maxDrawdown (outcomes : ℕ → ℝ) (T : ℕ) : ℝ :=
  Finset.sup' (Finset.range (T + 1) ×ˢ Finset.range (T + 1))
    ⟨(0, 0), Finset.mem_product.mpr ⟨Finset.mem_range.mpr (by omega),
                                       Finset.mem_range.mpr (by omega)⟩⟩
    (fun p => if p.1 ≤ p.2 then partialSum outcomes p.1 - partialSum outcomes p.2 else 0)

/-- Predicate: there is a consecutive run of `true` values of length k starting at position s,
    within the first T positions. -/
def hasConsecRun (f : ℕ → Bool) (T k s : ℕ) : Prop :=
  s + k ≤ T ∧ ∀ i, s ≤ i → i < s + k → f i = true

/-! ## Part 1: MDD and Consecutive Run Bound -/

/-
PROBLEM
If there is a consecutive run of k losses starting at position s (within T trades),
    then the maximum drawdown is at least k · L.

    This is the core deterministic bound: a block of k consecutive losses creates
    a drawdown of exactly k · L.

PROVIDED SOLUTION
Given a consecutive run of k losses starting at position s (with s+k ≤ T), we have:
- partialSum outcomes s = Σ_{i<s} X_i
- partialSum outcomes (s+k) = Σ_{i<s+k} X_i = (Σ_{i<s} X_i) + Σ_{i=s}^{s+k-1} X_i
- The terms from s to s+k-1 are all -L (since isWin i = false for these i), so Σ_{i=s}^{s+k-1} X_i = -k·L
- Therefore partialSum(s) - partialSum(s+k) = k·L
- The pair (s, s+k) has s ≤ s+k and both are ≤ T, so it's in the index set
- By Finset.le_sup', maxDrawdown ≥ k·L

Key steps: Use Finset.sum_Ico_eq_sub to split partialSum(s+k) - partialSum(s) = Σ over Ico s (s+k). Show each term in this sum is -L using hrun. Then partialSum(s) - partialSum(s+k) = k*L. Use Finset.le_sup' with witness (s, s+k).
-/
theorem mdd_ge_consec_losses (W L : ℝ) (_hL : 0 < L) (T k s : ℕ)
    (isWin : ℕ → Bool)
    (hrun : hasConsecRun (fun i => !isWin i) T k s) :
    let outcomes := fun i => if isWin i then W else -L
    maxDrawdown outcomes T ≥ L * k := by
  -- Use the fact that the drawdown at position s is L * k.
  have hdrawdown_s : let outcomes : ℕ → ℝ := fun i => if isWin i then W else -L; partialSum outcomes s - partialSum outcomes (s + k) ≥ L * k := by
    -- By definition of `hasConsecRun`, we know that `isWin i = false` for all `i` in the range `s` to `s + k - 1`.
    have h_run_false : ∀ i ∈ Finset.Ico s (s + k), ¬isWin i := by
      have := hrun.2; aesop;
    -- By definition of `partialSum`, we can split the sum into the sum up to `s` and the sum from `s` to `s + k`.
    have h_split_sum : partialSum (fun i => if isWin i then W else -L) (s + k) = partialSum (fun i => if isWin i then W else -L) s + ∑ i ∈ Finset.Ico s (s + k), (if isWin i then W else -L) := by
      unfold partialSum; rw [ Finset.sum_range_add_sum_Ico _ ( by linarith ) ] ;
    simp_all +decide;
    rw [ Finset.sum_congr rfl fun i hi => by rw [ h_run_false i ( Finset.mem_Ico.mp hi |>.1 ) ( Finset.mem_Ico.mp hi |>.2 ) ] ] ; norm_num ; linarith;
  refine' le_trans hdrawdown_s _;
  refine' le_trans _ ( Finset.le_sup' _ _ );
  rotate_left;
  exacts [ ⟨ s, s + k ⟩, Finset.mem_product.mpr ⟨ Finset.mem_range.mpr ( by linarith [ hrun.1 ] ), Finset.mem_range.mpr ( by linarith [ hrun.1 ] ) ⟩, by rw [ if_pos ( by linarith [ hrun.1 ] ) ] ]

/-! ## Part 2: Monotonicity of MDD in T -/

/-- The maximum drawdown is monotonically non-decreasing as we add more trades.
    This is because we take the maximum over a larger index set. -/
theorem maxDrawdown_mono (outcomes : ℕ → ℝ) (T₁ T₂ : ℕ) (h : T₁ ≤ T₂) :
    maxDrawdown outcomes T₁ ≤ maxDrawdown outcomes T₂ := by
  unfold maxDrawdown
  simp +zetaDelta at *
  obtain ⟨a, b, h_max⟩ : ∃ a b, a ≤ T₁ ∧ b ≤ T₁ ∧ ∀ a' b', a' ≤ T₁ → b' ≤ T₁ →
      (if a' ≤ b' then partialSum outcomes a' - partialSum outcomes b' else 0) ≤
      (if a ≤ b then partialSum outcomes a - partialSum outcomes b else 0) := by
    have h_max : ∃ p ∈ Finset.product (Finset.range (T₁ + 1)) (Finset.range (T₁ + 1)),
        ∀ q ∈ Finset.product (Finset.range (T₁ + 1)) (Finset.range (T₁ + 1)),
        (if p.1 ≤ p.2 then partialSum outcomes p.1 - partialSum outcomes p.2 else 0) ≥
        (if q.1 ≤ q.2 then partialSum outcomes q.1 - partialSum outcomes q.2 else 0) := by
      exact Finset.exists_max_image _ _ ⟨(0, 0), Finset.mem_product.mpr
        ⟨Finset.mem_range.mpr (Nat.succ_pos _), Finset.mem_range.mpr (Nat.succ_pos _)⟩⟩
    obtain ⟨p, hp₁, hp₂⟩ := h_max; use p.1, p.2; erw [Finset.mem_product] at hp₁; aesop
  exact ⟨a, b, ⟨by linarith, by linarith⟩, h_max.2.2⟩

/-- Corollary: If MDD exceeds D for fewer trades, it also exceeds D for more trades. -/
theorem prob_mdd_exceeds_mono {T₁ T₂ : ℕ} (h : T₁ ≤ T₂) (D : ℝ)
    (outcomes : ℕ → ℝ) :
    maxDrawdown outcomes T₁ > D → maxDrawdown outcomes T₂ > D := by
  intro hD
  exact lt_of_lt_of_le hD (maxDrawdown_mono outcomes T₁ T₂ h)

/-! ## Part 3: T_safe is finite -/

/-
PROBLEM
If T ≥ n, then the all-loss outcome sequence has max drawdown ≥ n·L.

PROVIDED SOLUTION
Use mdd_ge_consec_losses with isWin = (fun _ => false), W = L, k = T, s = 0. Then hasConsecRun (fun i => !(fun _ => false) i) T T 0 holds because 0 + T ≤ T and all values are true (since !false = true). The conclusion gives maxDrawdown (fun i => if false then L else -L) T ≥ L * T. But the outcomes simplify: (fun i => if (fun _ => false) i then L else -L) = (fun _ => -L). So we're done.
-/
theorem maxDrawdown_all_losses (L : ℝ) (hL : 0 < L) (T : ℕ) :
    maxDrawdown (fun _ => -L) T ≥ L * T := by
  have := @mdd_ge_consec_losses L L hL T T 0;
  convert this ( fun _ => Bool.false ) _ using 2 ; norm_num [ hasConsecRun ]

/-- T_safe is finite: for any D > 0 and L > 0, there exists an outcome sequence
    with bounded trades that exceeds drawdown D when T is large enough. -/
theorem t_safe_finite (L D : ℝ) (hL : 0 < L) (_hD : 0 < D) (T : ℕ)
    (hT : ↑T ≥ D / L) :
    maxDrawdown (fun _ => -L) T ≥ D := by
  have := maxDrawdown_all_losses L hL T
  nlinarith [mul_div_cancel₀ D hL.ne']

/-! ## Part 4: tMax computation -/

example : tMax 28000 200 = 140 := by native_decide
example : tMax 28000 400 = 70 := by native_decide
example : tMax 28000 800 = 35 := by native_decide

/-! ## Numerical Analysis (Part 4)

With symmetric wins/losses of ±0.003 and win rate w = 0.60 (loss rate q = 0.40):
- A drawdown of 0.20 requires ~67 consecutive losses (0.20/0.003 ≈ 67)
- Expected longest run of losses in T trials ≈ log(T·q)/log(1/q)

For T = 140 (H=200): E[longest_run] ≈ log(56)/log(2.5) ≈ 4.4
For T = 70  (H=400): E[longest_run] ≈ log(28)/log(2.5) ≈ 3.6
For T = 35  (H=800): E[longest_run] ≈ log(14)/log(2.5) ≈ 2.9

These are far below 67, so P(MDD > 0.20) is very small for all cases.
However, the probability is exponentially sensitive to T through the tail:
P(run ≥ k) ≈ T·q^k for large k.

For k = 67: P(run ≥ 67) ≈ T · 0.4^67
- T = 140: ≈ 140 · 4.7e-27 ≈ 6.6e-25
- T = 70:  ≈ 70 · 4.7e-27 ≈ 3.3e-25
- T = 35:  ≈ 35 · 4.7e-27 ≈ 1.6e-25

With symmetric payoffs (W = L), drawdown requires MANY consecutive losses,
making P(MDD > 0.20) negligible. With asymmetric payoffs (L > W),
the drawdown can accumulate faster and the probabilities become non-trivial.

For the H* computation with more realistic parameters where P(MDD > 0.20) = 0.20,
one would need asymmetric payoffs or a different model. In the symmetric case,
even H = 1 gives negligible drawdown probability for these parameters.
-/

/-! ## Part 5: Sortino grows as sqrt(T) -/

/-- The Sortino ratio scaling: μ√T/σ_d -/
def sortinoScaling (mu sigma_d : ℝ) (T : ℕ) : ℝ :=
  mu * Real.sqrt T / sigma_d

/-- Sortino scaling is non-decreasing in T (for positive mu, sigma_d) -/
theorem sortino_increasing (mu sigma_d : ℝ) (hmu : 0 < mu) (hsd : 0 < sigma_d)
    (T₁ T₂ : ℕ) (hT : T₁ ≤ T₂) :
    sortinoScaling mu sigma_d T₁ ≤ sortinoScaling mu sigma_d T₂ := by
  unfold sortinoScaling; gcongr

/-- The optimal T* under a drawdown constraint is the largest feasible T.

    Since Sortino is non-decreasing in T and the feasible set is downward-closed
    (if T is feasible, so is T' ≤ T), the maximum Sortino is achieved at the
    largest element of the feasible set. -/
theorem optimal_T_is_T_safe
    (mu sigma_d : ℝ) (hmu : 0 < mu) (hsd : 0 < sigma_d)
    (S : Finset ℕ) (hS : S.Nonempty)
    (_hfeas : ∀ T ∈ S, ∀ T', T' ≤ T → T' ∈ S)
    : ∃ T_star ∈ S, ∀ T ∈ S,
        sortinoScaling mu sigma_d T ≤ sortinoScaling mu sigma_d T_star := by
  exact ⟨S.max' hS, S.max'_mem hS, fun T hT => by
    simpa only [sortinoScaling] using div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt <| Nat.cast_le.mpr <| Finset.le_max' _ _ hT)
        hmu.le) hsd.le⟩

end