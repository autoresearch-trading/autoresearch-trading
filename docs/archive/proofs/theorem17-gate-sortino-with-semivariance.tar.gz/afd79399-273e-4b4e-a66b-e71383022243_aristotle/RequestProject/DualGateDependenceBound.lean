import Mathlib

/-!
# Theorem 22: DualGateDependenceBound

We formalize claims about Bernoulli gate indicators G1, G2 ∈ {0,1} with:
- p1 = P(G1 = 1), p2 = P(G2 = 1), p12 = P(G1 = 1 ∧ G2 = 1)
- 0 < p1 < 1, 0 < p2 < 1
- ρ = Corr(G1, G2) defined by
    ρ = (p12 - p1 * p2) / √(p1 * (1 - p1) * p2 * (1 - p2))

All claims are formalized as algebraic statements about real numbers.
-/

noncomputable section

open Real

/-! ## Claim 1: Exact Bernoulli correlation identity -/

/-
PROBLEM
The correlation for Bernoulli variables is defined as
  ρ = (p12 - p1 * p2) / √(p1 * (1 - p1) * p2 * (1 - p2)).
Rearranging gives p12 = p1 * p2 + ρ * √(p1 * (1 - p1) * p2 * (1 - p2)).

PROVIDED SOLUTION
Substitute h_rho into the RHS: p1*p2 + ((p12 - p1*p2) / sqrt(...)) * sqrt(...) = p1*p2 + (p12 - p1*p2) = p12. The key step is that sqrt(p1*(1-p1)*p2*(1-p2)) > 0 since 0 < p1 < 1 and 0 < p2 < 1, so div_mul_cancel works.
-/
theorem claim1_bernoulli_correlation_identity
    (p1 p2 p12 rho : ℝ)
    (hp1_pos : 0 < p1) (hp1_lt : p1 < 1)
    (hp2_pos : 0 < p2) (hp2_lt : p2 < 1)
    (h_rho : rho = (p12 - p1 * p2) / Real.sqrt (p1 * (1 - p1) * p2 * (1 - p2))) :
    p12 = p1 * p2 + rho * Real.sqrt (p1 * (1 - p1) * p2 * (1 - p2)) := by
  rw [ h_rho, div_mul_cancel₀ _ ( ne_of_gt ( Real.sqrt_pos.mpr ( mul_pos ( mul_pos ( mul_pos hp1_pos ( sub_pos.mpr hp1_lt ) ) hp2_pos ) ( sub_pos.mpr hp2_lt ) ) ) ), add_sub_cancel ]

/-! ## Claim 2: Covariance identity and positivity -/

/-
PROBLEM
The covariance Cov(G1, G2) = p12 - p1 * p2 equals
  ρ * √(p1 * (1 - p1) * p2 * (1 - p2)).

PROVIDED SOLUTION
From h_rho, rho = (p12 - p1*p2)/sqrt(...), so rho * sqrt(...) = p12 - p1*p2. Use div_mul_cancel since sqrt(...) > 0.
-/
theorem claim2_covariance_identity
    (p1 p2 p12 rho : ℝ)
    (hp1_pos : 0 < p1) (hp1_lt : p1 < 1)
    (hp2_pos : 0 < p2) (hp2_lt : p2 < 1)
    (h_rho : rho = (p12 - p1 * p2) / Real.sqrt (p1 * (1 - p1) * p2 * (1 - p2))) :
    p12 - p1 * p2 = rho * Real.sqrt (p1 * (1 - p1) * p2 * (1 - p2)) := by
  rw [ h_rho, div_mul_cancel₀ _ ( ne_of_gt ( Real.sqrt_pos.mpr ( mul_pos ( mul_pos ( mul_pos hp1_pos ( sub_pos.mpr hp1_lt ) ) hp2_pos ) ( sub_pos.mpr hp2_lt ) ) ) ) ]

/-
PROBLEM
If ρ > 0 then p12 > p1 * p2.

PROVIDED SOLUTION
From h_rho and h_rho_pos: rho > 0 and sqrt(...) > 0 (since 0 < pi < 1), so (p12 - p1*p2)/sqrt(...) > 0, hence p12 - p1*p2 > 0, hence p12 > p1*p2. Use div_pos_iff or positivity.
-/
theorem claim2_positive_correlation_implies
    (p1 p2 p12 rho : ℝ)
    (hp1_pos : 0 < p1) (hp1_lt : p1 < 1)
    (hp2_pos : 0 < p2) (hp2_lt : p2 < 1)
    (h_rho : rho = (p12 - p1 * p2) / Real.sqrt (p1 * (1 - p1) * p2 * (1 - p2)))
    (h_rho_pos : rho > 0) :
    p12 > p1 * p2 := by
  contrapose! h_rho_pos; rw [ h_rho, div_eq_mul_inv ] at *; nlinarith [ inv_nonneg.mpr ( Real.sqrt_nonneg ( p1 * ( 1 - p1 ) * p2 * ( 1 - p2 ) ) ) ] ;

/-! ## Claim 3: Redundancy from a shared latent factor (nested gates) -/

/-
PROBLEM
If events are nested (A₂ ⊆ A₁), then their intersection equals the smaller event.

PROVIDED SOLUTION
Set.inter_eq_right.mpr h_nested, or ext and use h_nested.
-/
theorem claim3_nested_intersection {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ]
    (A₁ A₂ : Set Ω) (h_nested : A₂ ⊆ A₁) :
    A₁ ∩ A₂ = A₂ := by
  exact Set.inter_eq_right.mpr h_nested

/-
PROBLEM
For nested gates, p12 = p2.

PROVIDED SOLUTION
Rewrite using Set.inter_eq_right.mpr h_nested (or claim3_nested_intersection) to get μ A₂ = μ A₂.
-/
theorem claim3_nested_joint_eq {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ]
    (A₁ A₂ : Set Ω) (h_nested : A₂ ⊆ A₁)
    (hA₁ : MeasurableSet A₁) (hA₂ : MeasurableSet A₂) :
    μ (A₁ ∩ A₂) = μ A₂ := by
  rw [ Set.inter_eq_right.mpr h_nested ]

/-
PROBLEM
For threshold gates with t2 ≤ t1, the events are nested: {T ≤ t2} ⊆ {T ≤ t1}.

PROVIDED SOLUTION
intro ω hω; exact le_trans hω h.
-/
theorem claim3_threshold_nested {Ω : Type*} [MeasurableSpace Ω]
    (T : Ω → ℝ) (t1 t2 : ℝ) (h : t2 ≤ t1) :
    {ω | T ω ≤ t2} ⊆ {ω | T ω ≤ t1} := by
  exact fun x hx => le_trans hx h

/-
PROBLEM
Conditioning on both nested gates is equivalent to conditioning on G2 alone:
  if A₂ ⊆ A₁ then for any event B,
  P(B | A₁ ∩ A₂) = P(B | A₂).

PROVIDED SOLUTION
Rewrite A₁ ∩ A₂ = A₂ using Set.inter_eq_right.mpr h_nested, then reflexivity.
-/
theorem claim3_conditioning_equivalence {Ω : Type*} [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ]
    (A₁ A₂ : Set Ω) (h_nested : A₂ ⊆ A₁) :
    μ.restrict (A₁ ∩ A₂) = μ.restrict A₂ := by
  rw [ Set.inter_eq_right.mpr h_nested ]

/-! ## Claim 4: Sortino redundancy threshold -/

/-
PROBLEM
The second gate improves Sortino over the first gate iff
  k2_eff * √(p12 / p1) > 1.

PROVIDED SOLUTION
The LHS k1*k2_eff*sqrt(p12)*S0 > k1*sqrt(p1)*S0 can be divided by k1*S0 > 0 to get k2_eff*sqrt(p12) > sqrt(p1). Then divide by sqrt(p1) > 0 to get k2_eff*sqrt(p12)/sqrt(p1) > 1. Use sqrt_div to rewrite sqrt(p12)/sqrt(p1) = sqrt(p12/p1). Key lemmas: mul_lt_mul_right, Real.sqrt_div_self, Real.sqrt_div.
-/
theorem claim4_sortino_improvement_iff
    (S0 k1 k2_eff p1 p12 : ℝ)
    (hS0 : S0 > 0) (hk1 : k1 > 0)
    (hp1 : p1 > 0) (hp12 : p12 ≥ 0) :
    k1 * k2_eff * Real.sqrt p12 * S0 > k1 * Real.sqrt p1 * S0 ↔
    k2_eff * Real.sqrt (p12 / p1) > 1 := by
  field_simp;
  rw [ Real.sqrt_div ( by positivity ), mul_div, lt_div_iff₀' ] <;> first | positivity | ring;

/-
PROBLEM
In the nested same-factor case: k2_eff = 1 and p12 = p2 ≤ p1
  implies S12 ≤ S1.

PROVIDED SOLUTION
Since p2 ≤ p1, sqrt(p2) ≤ sqrt(p1) by Real.sqrt_le_sqrt. Then multiply both sides by k1 * S0 > 0. Use mul_le_mul_of_nonneg_left or similar.
-/
theorem claim4_nested_redundancy
    (S0 k1 p1 p2 : ℝ)
    (hS0 : S0 > 0) (hk1 : k1 > 0)
    (hp1 : p1 > 0) (hp2 : p2 ≥ 0)
    (h_le : p2 ≤ p1) :
    k1 * Real.sqrt p2 * S0 ≤ k1 * Real.sqrt p1 * S0 := by
  gcongr

/-
PROBLEM
Redundancy threshold: if k2_eff is nonincreasing in ρ and there exists ρ_critical
  where k2_eff(ρ_critical) * √(p12(ρ_critical) / p1) = 1, then for ρ ≥ ρ_critical
  the second gate gives no Sortino improvement.

  We formalize: given a nonincreasing function f(ρ) = k2_eff(ρ) * √(p12(ρ) / p1)
  that equals 1 at ρ_critical, and p12 nondecreasing in ρ (from Claim 1),
  f(ρ) ≤ 1 for ρ ≥ ρ_critical.

PROVIDED SOLUTION
Since f is antitone (nonincreasing) and rho ≥ rho_c, f(rho) ≤ f(rho_c) = 1. Use h_anti h_ge and h_eq.
-/
theorem claim4_redundancy_threshold
    (f : ℝ → ℝ) (rho_c : ℝ)
    (h_anti : Antitone f)
    (h_eq : f rho_c = 1)
    (rho : ℝ) (h_ge : rho ≥ rho_c) :
    f rho ≤ 1 := by
  exact h_eq ▸ h_anti h_ge

end