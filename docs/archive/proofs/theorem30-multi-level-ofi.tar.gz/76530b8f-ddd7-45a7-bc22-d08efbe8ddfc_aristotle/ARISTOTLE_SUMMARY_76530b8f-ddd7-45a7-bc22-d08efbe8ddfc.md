# Summary of changes
## Completed Formalization: Roll Measure and Amihud Illiquidity

All 8 claims from the problem statement have been formalized and machine-verified in Lean 4 across **14 theorems** in `RequestProject/RollAmihud.lean`. The file builds cleanly with no `sorry`, no warnings, and only standard axioms (propext, Classical.choice, Quot.sound).

### Part A: Roll Measure (Claims 1–4)

1. **`roll_return_decomposition`** — Under the Roll model (p_t = m_t + c·q_t, m_t = m_{t-1} + u_t), the return r_t = p_t - p_{t-1} equals u_t + c·(q_t - q_{t-1}).

2. **`roll_autocovariance_eq_neg_c_sq`** + **`iid_diff_covariance`** — The autocovariance Cov(r_t, r_{t-1}) = c²·Cov(q_t−q_{t-1}, q_{t-1}−q_{t-2}) = −c². The helper theorem proves that adjacent differences of iid zero-mean unit-variance variables have covariance −1.

3. **`roll_estimator_recovers_c`** — If Cov = −c², then ĉ = √(−Cov) = √(c²) = c for c ≥ 0, proving consistency of the Roll spread estimator.

4. **`roll_negative_autocov`** + **`roll_positive_autocov_vanishes_statement`** — When c > 0, the population autocovariance −c² < 0, so by the law of large numbers the sample autocovariance converges to a negative value, making the probability of observing positive sample autocovariance vanish with sample size.

### Part B: Amihud Illiquidity (Claims 5–8)

5. **`amihud_kyle_relationship`** — Under Kyle's model where |r| = λ·V + |ε|, dividing by V yields ILLIQ = λ + |ε|/V, showing ILLIQ is proportional to Kyle's price impact coefficient λ.

6. **`amihud_zero_iff`** + **`amihud_nonneg`** — ILLIQ = |r|/V is non-negative by construction, and equals zero if and only if r = 0 (no price change despite trading).

7. **`amihud_increasing_in_c_pointwise`** + **`abs_linear_increasing`** — |u + c·d|/V is increasing in c (for c ≥ 0, d > 0, u ≥ 0), proving that higher spread implies higher Amihud illiquidity, connecting the Roll and Amihud measures.

8. **`amihud_numerical_example`** + **`roll_effective_spread`** + **`amihud_price_impact_interpretation`** — Numerical verification: with c = 0.0005 (5 bps half-spread), |r| = 0.001 (10 bps), V = $10,000: ILLIQ = 0.001/10000 = 1×10⁻⁷, consistent with typical crypto market Kyle's lambda estimates. Also verified: effective spread = 2c = 10 bps, and the price impact interpretation (ILLIQ × V = price change).