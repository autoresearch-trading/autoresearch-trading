/-
# Theorem 32: Roll Measure and Amihud Illiquidity — Spread Estimators from Trade Data

Formalization of key results from Roll (1984) and Amihud (2002) on market microstructure
spread estimators.
-/
import Mathlib

open Real

/-! ## Part A: Roll Measure -/

/-! ### Claim 1: Return decomposition under the Roll model

Under the Roll model:
- p_t = m_t + c * q_t  (observed price = efficient price + half-spread × direction)
- m_t = m_{t-1} + u_t   (efficient price is a random walk)

The return r_t = p_t - p_{t-1} = u_t + c * (q_t - q_{t-1}).
-/

/-
PROVIDED SOLUTION
Introduce the let bindings with simp only, substitute h_rw, then ring.
-/
theorem roll_return_decomposition
    (m_prev m_curr : ℝ) (q_prev q_curr : ℝ) (c u : ℝ)
    (h_rw : m_curr = m_prev + u)           -- random walk: m_t = m_{t-1} + u_t
    : let p_prev := m_prev + c * q_prev    -- p_{t-1} = m_{t-1} + c * q_{t-1}
      let p_curr := m_curr + c * q_curr    -- p_t = m_t + c * q_t
      p_curr - p_prev = u + c * (q_curr - q_prev) := by
  simpa only [ h_rw ] using by ring;

/-! ### Claim 2: Autocovariance of returns equals -c²

Under the Roll model, with independence of u_t and q_t, and q_t iid with variance 1:

  Cov(r_t, r_{t-1}) = -c²

We formalize this as: given that the cross terms involving u vanish (independence)
and Cov(q_t - q_{t-1}, q_{t-1} - q_{t-2}) = -Var(q_{t-1}) = -1,
the autocovariance equals -c².

The key algebraic fact: if r_t = u_t + c*(q_t - q_{t-1}), the covariance structure
is determined by the q terms since u is independent of everything. The only overlapping
q term between r_t and r_{t-1} is q_{t-1}, appearing with opposite signs, giving -c².
-/

/-
PROVIDED SOLUTION
Substitute h_cov_q : cov_q_diff = -1 and use ring.
-/
theorem roll_autocovariance_eq_neg_c_sq (c : ℝ)
    (cov_q_diff : ℝ)   -- Cov(q_t - q_{t-1}, q_{t-1} - q_{t-2})
    (h_cov_q : cov_q_diff = -1)  -- From iid q_t with Var(q_t) = 1
    -- By independence of u and q, and E[u] = 0:
    -- Cov(r_t, r_{t-1}) = c² * Cov(q_t - q_{t-1}, q_{t-1} - q_{t-2})
    : c ^ 2 * cov_q_diff = -(c ^ 2) := by
  rw [ h_cov_q, mul_neg_one ]

/-! ### Claim 2b: The cross-covariance of adjacent differences of iid variables

For iid q_t with Var(q_t) = 1, Cov(q_t - q_{t-1}, q_{t-1} - q_{t-2}) = -1.

This follows because q_{t-1} appears in both terms with opposite signs, and
cross terms vanish by independence.

Algebraically: E[(q_t - q_{t-1})(q_{t-1} - q_{t-2})]
  = E[q_t q_{t-1}] - E[q_t q_{t-2}] - E[q_{t-1}²] + E[q_{t-1} q_{t-2}]
  = 0 - 0 - 1 + 0 = -1
(using E[q_i q_j] = 0 for i ≠ j by independence and zero mean, E[q_i²] = 1)
-/

/-
PROVIDED SOLUTION
Substitute all hypotheses and use linarith or ring.
-/
theorem iid_diff_covariance
    (E_q0_sq E_q1_sq : ℝ)          -- E[q_{t-2}²], E[q_{t-1}²]
    (E_q0q1 E_q1q2 E_q0q2 : ℝ)    -- cross expectations
    (_h_var0 : E_q0_sq = 1)         -- Var(q_{t-2}) = E[q_{t-2}²] = 1 (zero mean)
    (h_var1 : E_q1_sq = 1)         -- Var(q_{t-1}) = E[q_{t-1}²] = 1
    (h_ind01 : E_q0q1 = 0)         -- E[q_{t-2} q_{t-1}] = 0 (independent, zero mean)
    (h_ind12 : E_q1q2 = 0)         -- E[q_{t-1} q_t] = 0
    (h_ind02 : E_q0q2 = 0)         -- E[q_{t-2} q_t] = 0
    -- E[(q_t - q_{t-1})(q_{t-1} - q_{t-2})]
    --   = E[q_t q_{t-1}] - E[q_t q_{t-2}] - E[q_{t-1}²] + E[q_{t-1} q_{t-2}]
    : E_q1q2 - E_q0q2 - E_q1_sq + E_q0q1 = -1 := by
  grind +locals

/-! ### Claim 3: Roll spread estimator recovers c

If Cov(r_t, r_{t-1}) = -c² (negative autocovariance from bid-ask bounce),
then c_hat = sqrt(-Cov(r_t, r_{t-1})) = sqrt(c²) = c (for c ≥ 0).
-/

/-
PROVIDED SOLUTION
Substitute h_cov, simplify -(-c^2) = c^2, then use Real.sqrt_sq hc.
-/
theorem roll_estimator_recovers_c (c : ℝ) (hc : 0 ≤ c)
    (cov : ℝ) (h_cov : cov = -(c ^ 2))
    : Real.sqrt (-cov) = c := by
  rw [ h_cov, neg_neg, Real.sqrt_sq hc ]

/-! ### Claim 4: Sample autocovariance converges to -c² < 0

Under the Roll model with c > 0, the population autocovariance is -c² < 0.
By the law of large numbers, the sample autocovariance converges to -c².
Therefore, for sufficiently large T, the probability of observing positive
sample autocovariance becomes arbitrarily small.

We formalize the core algebraic fact: c > 0 implies -c² < 0.
-/

/-
PROVIDED SOLUTION
c > 0 implies c^2 > 0 implies -c^2 < 0. Use neg_neg_of_neg or nlinarith [sq_nonneg c].
-/
theorem roll_negative_autocov (c : ℝ) (hc : 0 < c) : -(c ^ 2) < 0 := by
  nlinarith

/-! The full probabilistic statement: as sample size T → ∞, the sample
autocovariance converges in probability to -c² < 0, so the probability
of positive sample autocovariance goes to 0. -/

/-
PROVIDED SOLUTION
Split into two goals. First: -(c^2) < 0 by nlinarith [sq_pos_of_pos c hc]. Second: 0 ≤ c by linarith.
-/
theorem roll_positive_autocov_vanishes_statement (c : ℝ) (hc : 0 < c) :
    -(c ^ 2) < 0 ∧ 0 ≤ c := by
  exact ⟨ neg_neg_of_pos ( sq_pos_of_pos hc ), le_of_lt hc ⟩

/-! ## Part B: Amihud Illiquidity -/

/-! ### Claim 5: Amihud ILLIQ proportional to Kyle's lambda

Under Kyle's model: r_t = λ · V_t · sign(q_t) + ε_t, with V_t independent of sign(q_t).

If we define ILLIQ_t = |r_t| / V_t, then:
  E[ILLIQ_t] = λ + E[|ε_t|] / E[V_t]

We formalize this as: given |r_t| = λ · V_t + |ε_t| (in expectation, when
ε_t is independent and has mean contribution |ε_t|), dividing by V_t gives
λ + |ε_t|/V_t in expectation.

The key algebraic identity: |λ · V + ε| / V = λ + ε/V when λ,V > 0 and we
take expectations appropriately.
-/

/-
PROVIDED SOLUTION
Substitute hr, then use field_simp to clear V denominator, then ring. Or: rw [hr, add_div, mul_div_cancel_of_imp] using hV.ne'.
-/
theorem amihud_kyle_relationship
    (lam V eps : ℝ) (hV : 0 < V) (_hlam : 0 ≤ lam)
    -- Under simplifying assumptions |r| = lam * V + |eps|
    (r_abs : ℝ) (hr : r_abs = lam * V + |eps|)
    : r_abs / V = lam + |eps| / V := by
  rw [ hr, add_div, mul_div_cancel_right₀ _ hV.ne' ]

/-! ### Claim 6: ILLIQ = 0 iff r = 0

ILLIQ_t = |r_t| / V_t, where V_t > 0. Then ILLIQ = 0 ↔ r = 0.
-/

/-
PROVIDED SOLUTION
Use div_eq_zero_iff, then since V > 0 we have V ≠ 0, so |r|/V = 0 ↔ |r| = 0 ↔ r = 0. Use abs_eq_zero.
-/
theorem amihud_zero_iff (r V : ℝ) (hV : 0 < V) :
    |r| / V = 0 ↔ r = 0 := by
  rw [ div_eq_iff ] <;> aesop

/-! ### Claim 6b: ILLIQ is non-negative -/

/-
PROVIDED SOLUTION
Use div_nonneg (abs_nonneg r) (le_of_lt hV).
-/
theorem amihud_nonneg (r V : ℝ) (hV : 0 < V) :
    0 ≤ |r| / V := by
  positivity

/-! ### Claim 7: E[ILLIQ] is increasing in the half-spread c

Under the Roll model, r_t = u_t + c*(q_t - q_{t-1}), so
ILLIQ = |u_t + c*(q_t - q_{t-1})| / V_t.

We show: for a fixed realization of (u, q_diff, V) with q_diff ≠ 0 and V > 0,
the ILLIQ function is convex (and specifically increasing) in c when the
direction term dominates.

More precisely, |u + c * d| / V is increasing in c when c ≥ 0 and d > 0
(i.e., the signed direction contribution is positive).
-/

/-
PROVIDED SOLUTION
Use div_le_div_of_nonneg_right with the result from abs_linear_increasing. Both |u + c₁*d| ≤ |u + c₂*d| (from abs_linear_increasing) and V > 0, so dividing preserves the inequality. Use div_le_div_right hV and apply abs_linear_increasing.
-/
theorem amihud_increasing_in_c_pointwise
    (u d V : ℝ) (hV : 0 < V) (hd : 0 < d)
    (c₁ c₂ : ℝ) (hc₁ : 0 ≤ c₁) (_hc₂ : 0 ≤ c₂) (h_le : c₁ ≤ c₂)
    (hu : 0 ≤ u)  -- WLOG u ≥ 0 case
    : |u + c₁ * d| / V ≤ |u + c₂ * d| / V := by
  gcongr

/-! ### Claim 7b: Higher spread implies higher expected ILLIQ (general version)

The absolute value |u + c * d| is increasing in c for c ≥ 0 when d > 0 and u ≥ 0.
-/

/-
PROVIDED SOLUTION
Since u ≥ 0, d > 0, c₁ ≤ c₂, and c₁ ≥ 0, both u + c₁*d ≥ 0 and u + c₂*d ≥ 0. So |u + c₁*d| = u + c₁*d and |u + c₂*d| = u + c₂*d. Then u + c₁*d ≤ u + c₂*d follows from c₁*d ≤ c₂*d. Use abs_of_nonneg for both sides, then linarith or nlinarith.
-/
theorem abs_linear_increasing
    (u d : ℝ) (hd : 0 < d) (hu : 0 ≤ u)
    (c₁ c₂ : ℝ) (hc₁ : 0 ≤ c₁) (hc₂ : c₁ ≤ c₂)
    : |u + c₁ * d| ≤ |u + c₂ * d| := by
  rw [ abs_of_nonneg, abs_of_nonneg ] <;> nlinarith

/-! ### Claim 8: Numerical verification

With c = 0.0005 (5 bps half-spread), |r| = 0.001 (10 bps), V = 10000:
  ILLIQ = |r| / V = 0.001 / 10000 = 1e-7 = 0.0000001

This is consistent with typical Kyle's lambda estimates for crypto markets.
-/

/-
PROBLEM
We verify the computation: 0.001 / 10000 = 1/10000000

PROVIDED SOLUTION
norm_num
-/
theorem amihud_numerical_example :
    (0.001 : ℝ) / 10000 = 1 / 10000000 := by
  norm_num at *

/-
PROBLEM
Effective spread = 2c = 0.001 (10 bps) when c = 0.0005

PROVIDED SOLUTION
norm_num
-/
theorem roll_effective_spread :
    2 * (0.0005 : ℝ) = 0.001 := by
  norm_num +zetaDelta at *

/-
PROBLEM
ILLIQ = 1e-7 means: to move the price by 1 bp (0.0001), need volume of 1000
This is the price impact interpretation

PROVIDED SOLUTION
norm_num
-/
theorem amihud_price_impact_interpretation :
    (1 : ℝ) / 10000000 * 10000 = 0.001 := by
  grind

/-! ## Summary of Cross-Metric Relationships

The Roll measure captures the **bid-ask spread** through serial correlation in returns:
- Negative autocorrelation → bid-ask bounce → spread = 2 * sqrt(-Cov)

The Amihud measure captures **price impact** per unit volume:
- ILLIQ = |Δp| / Volume ≈ Kyle's λ (market depth parameter)

Both measure illiquidity but from different angles:
- Roll: transaction cost dimension (tighter spread = more liquid)
- Amihud: price impact dimension (less impact per dollar = more liquid)

Formally, higher c (half-spread) implies higher E[ILLIQ], connecting the two
measures (Claim 7).
-/