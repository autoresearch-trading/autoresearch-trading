import Mathlib

/-!
# Theorem 17: Gate–Sortino with Semivariance

We formalize the relationship between ungated and gated Sortino ratios for a trading
strategy filtered by a binary gate.

## Setup

- `m > 0`: steps per day
- `mu > 0`: ungated mean return
- `sigma_down > 0`: ungated downside deviation
- `Sortino_all = (mu / sigma_down) * sqrt(m)`
- Gate keeps fraction `phi` of trades, `0 < phi ≤ 1`
- `mu_pass`: conditional mean return given gate passes
- `sigma_down_pass`: conditional downside deviation given gate passes
- `k = mu_pass / mu`, `d = sigma_down_pass / sigma_down`
- `Sortino_gated = (mu_pass / sigma_down_pass) * sqrt(phi * m)`

## Main results

1. `sortino_ratio_identity`: Sortino_gated / Sortino_all = k * sqrt(phi) / d
2. `sortino_gate_improves_iff`: Gate improves Sortino iff k * sqrt(phi) > d
3. `gate_raises_edge_but_lowers_sortino`: Explicit example with k > 1 but Sortino decreasing
4. `portfolio_sortino_gate_iff`: Portfolio-level characterization
-/

noncomputable section

open Real Finset

/-! ## Part 1: The Sortino ratio identity -/

/-- The ungated Sortino ratio. -/
def SortinoAll (mu sigma_down m : ℝ) : ℝ :=
  (mu / sigma_down) * Real.sqrt m

/-- The gated Sortino ratio. -/
def SortinoGated (mu_pass sigma_down_pass phi m : ℝ) : ℝ :=
  (mu_pass / sigma_down_pass) * Real.sqrt (phi * m)

/-- The ratio k = mu_pass / mu. -/
def kRatio (mu_pass mu : ℝ) : ℝ := mu_pass / mu

/-- The ratio d = sigma_down_pass / sigma_down. -/
def dRatio (sigma_down_pass sigma_down : ℝ) : ℝ := sigma_down_pass / sigma_down

/-
PROBLEM
**Part 1**: The exact Sortino ratio identity:
  `Sortino_gated / Sortino_all = k * sqrt(phi) / d`.

PROVIDED SOLUTION
Unfold SortinoGated, SortinoAll, kRatio, dRatio.
The LHS is: [(mu_pass / sigma_down_pass) * sqrt(phi * m)] / [(mu / sigma_down) * sqrt(m)].
Use Real.sqrt_mul (le_of_lt hphi) to rewrite sqrt(phi * m) = sqrt(phi) * sqrt(m).
Then the sqrt(m) factors cancel (since m > 0 so sqrt(m) ≠ 0).
The remaining expression is (mu_pass / sigma_down_pass) * sqrt(phi) / (mu / sigma_down).
Rearranging: (mu_pass / mu) * sqrt(phi) * (sigma_down / sigma_down_pass) = (mu_pass/mu) * sqrt(phi) / (sigma_down_pass/sigma_down) = k * sqrt(phi) / d.
The key is to use field_simp to clear all denominators (all positive), then ring.
-/
theorem sortino_ratio_identity
    (mu sigma_down mu_pass sigma_down_pass phi m : ℝ)
    (hmu : mu > 0) (hsd : sigma_down > 0)
    (hmp : mu_pass > 0) (hsdp : sigma_down_pass > 0)
    (hphi : phi > 0) (hm : m > 0) :
    SortinoGated mu_pass sigma_down_pass phi m / SortinoAll mu sigma_down m =
    kRatio mu_pass mu * Real.sqrt phi / dRatio sigma_down_pass sigma_down := by
  unfold SortinoGated SortinoAll kRatio dRatio; field_simp; ring;
  rw [ mul_comm, Real.sqrt_mul hm.le ]

/-! ## Part 2: Gate improves Sortino iff k * sqrt(phi) > d -/

/-
PROBLEM
**Part 2**: The gate improves Sortino if and only if `k * sqrt(phi) > d`.

PROVIDED SOLUTION
Unfold SortinoGated, SortinoAll, kRatio, dRatio.
Use Real.sqrt_mul to split sqrt(phi * m) = sqrt(phi) * sqrt(m).
Since mu, sigma_down, mu_pass, sigma_down_pass, sqrt(m) are all positive, we can use field_simp to clear denominators. After clearing denominators, both sides become polynomial inequalities that can be resolved with ring_nf and positivity/nlinarith. The key insight is that dividing both sides by the common positive factor (mu / sigma_down) * sqrt(m) / sigma_down_pass reduces to k * sqrt(phi) > d. Try: constructor; intro h; all goals (unfold SortinoGated SortinoAll kRatio dRatio at *; rw [Real.sqrt_mul (le_of_lt hphi)] at *; ... use positivity for pos facts, then nlinarith or field reasoning).
-/
theorem sortino_gate_improves_iff
    (mu sigma_down mu_pass sigma_down_pass phi m : ℝ)
    (hmu : mu > 0) (hsd : sigma_down > 0)
    (hmp : mu_pass > 0) (hsdp : sigma_down_pass > 0)
    (hphi : phi > 0) (hm : m > 0) :
    SortinoGated mu_pass sigma_down_pass phi m > SortinoAll mu sigma_down m ↔
    kRatio mu_pass mu * Real.sqrt phi > dRatio sigma_down_pass sigma_down := by
  unfold SortinoGated SortinoAll kRatio dRatio;
  field_simp;
  constructor <;> intro <;> rw [ Real.sqrt_mul hphi.le ] at * <;> nlinarith [ Real.sqrt_pos.2 hm ]

/-! ## Part 3: Gate can raise conditional edge while hurting Sortino -/

/-
PROBLEM
**Part 3a**: Explicit example: phi = 1/4, k = 2, d = 3.
  We have 0 < phi < 1, k > 1, and d > k * sqrt(phi),
  so the gate raises conditional mean return (k > 1) but lowers Sortino.

PROVIDED SOLUTION
This is a numeric verification. phi = 1/4, k = 2, d = 3. We need:
- 0 < 1/4: norm_num
- 1/4 < 1: norm_num
- 2 > 1: norm_num
- 3 > 2 * sqrt(1/4): Since sqrt(1/4) = 1/2, we need 3 > 1. For the sqrt computation, note Real.sqrt (1/4) = 1/2. Use rw [show (1:ℝ)/4 = (1/2)^2 from by ring, Real.sqrt_sq (by norm_num : (0:ℝ) ≤ 1/2)] to get sqrt(1/4) = 1/2, then norm_num.
-/
theorem gate_raises_edge_but_lowers_sortino :
    let phi : ℝ := 1 / 4
    let k : ℝ := 2
    let d : ℝ := 3
    (0 < phi) ∧ (phi < 1) ∧ (k > 1) ∧ (d > k * Real.sqrt phi) := by
  norm_num +zetaDelta at *

/-
PROBLEM
**Part 3b**: Two-symbol example showing gating can increase the number of symbols
  whose Sortino exceeds a threshold tau while decreasing the average Sortino.

  Symbol 1 (ungated): Sortino = 0.8 (below tau = 1)
  Symbol 1 (gated):   Sortino = 1.2 (above tau = 1)
  Symbol 2 (ungated): Sortino = 3.0 (above tau = 1)
  Symbol 2 (gated):   Sortino = 1.5 (above tau = 1)

  Ungated: 1 symbol above tau, average Sortino = 1.9
  Gated:   2 symbols above tau, average Sortino = 1.35
  More symbols above threshold, but average Sortino decreased.

PROVIDED SOLUTION
Pure numeric verification with rational numbers. All goals reduce to rational inequalities. Use norm_num for everything. The key facts: ¬(4/5 > 1), 3 > 1, 6/5 > 1, 3/2 > 1, and (6/5 + 3/2)/2 < (4/5 + 3)/2 which is 27/20 < 19/10.
-/
theorem gate_threshold_paradox :
    let s1_ungated : ℝ := 4 / 5   -- 0.8
    let s2_ungated : ℝ := 3       -- 3.0
    let s1_gated : ℝ := 6 / 5     -- 1.2
    let s2_gated : ℝ := 3 / 2     -- 1.5
    let tau : ℝ := 1
    -- More symbols exceed tau after gating
    (¬(s1_ungated > tau) ∧ (s2_ungated > tau)) ∧   -- 1 symbol above tau ungated
    ((s1_gated > tau) ∧ (s2_gated > tau)) ∧         -- 2 symbols above tau gated
    -- But average Sortino decreases
    (s1_gated + s2_gated) / 2 < (s1_ungated + s2_ungated) / 2 := by
  norm_num

/-! ## Part 4: Portfolio characterization -/

/-
PROBLEM
**Part 4**: Portfolio Sortino characterization for N independent symbols.

  Ungated portfolio Sortino:
    S_all  = (∑ j, mu_j) / sqrt(∑ j, sigma_j^2) * sqrt(m)

  Gated portfolio Sortino (with mu_j' = phi_j * k_j * mu_j, sigma_j' = sqrt(phi_j) * d_j * sigma_j):
    S_gate = (∑ j, phi_j * k_j * mu_j) / sqrt(∑ j, phi_j * d_j^2 * sigma_j^2) * sqrt(m)

  Gating improves portfolio Sortino iff:
    (∑ j, phi_j * k_j * mu_j) / sqrt(∑ j, phi_j * d_j^2 * sigma_j^2)
    > (∑ j, mu_j) / sqrt(∑ j, sigma_j^2)

PROVIDED SOLUTION
The goal is S_gate > S_all ↔ RHS > LHS where S_gate = RHS * sqrt(m) and S_all = LHS * sqrt(m). Since sqrt(m) > 0 (because m > 0), multiplying/dividing by sqrt(m) preserves the inequality. So S_gate > S_all ↔ RHS * sqrt(m) > LHS * sqrt(m) ↔ RHS > LHS.
Use mul_lt_mul_right (Real.sqrt_pos_of_pos hm) to reduce.
-/
theorem portfolio_sortino_gate_iff
    {N : ℕ} (hN : N > 0)
    (mu sigma phi k d : Fin N → ℝ)
    (hmu : ∀ j, mu j > 0) (hsigma : ∀ j, sigma j > 0)
    (hphi : ∀ j, 0 < phi j) (hphi_le : ∀ j, phi j ≤ 1)
    (hk : ∀ j, k j > 0) (hd : ∀ j, d j > 0)
    (m : ℝ) (hm : m > 0) :
    let S_all := (∑ j, mu j) / Real.sqrt (∑ j, (sigma j) ^ 2) * Real.sqrt m
    let S_gate := (∑ j, phi j * k j * mu j) /
                  Real.sqrt (∑ j, phi j * (d j) ^ 2 * (sigma j) ^ 2) * Real.sqrt m
    S_gate > S_all ↔
    (∑ j, phi j * k j * mu j) / Real.sqrt (∑ j, phi j * (d j) ^ 2 * (sigma j) ^ 2) >
    (∑ j, mu j) / Real.sqrt (∑ j, (sigma j) ^ 2) := by
  field_simp [mul_comm, mul_assoc, mul_left_comm] at *

end