# Summary of changes
Successfully formalized and proved all four claims from the Buy/Sell VWAP Decomposition and Pressure Asymmetry theorem in `RequestProject/VWAPDecomposition.lean`. All 7 theorems compile without `sorry` and use only standard axioms.

### Theorems proved:

1. **VWAP Decomposition** (`vwap_decomposition` and `vwap_decomposition'`): The overall VWAP - mid decomposes as f · d_buy + (1-f) · d_sell, where f is the buy fraction. Two versions are provided — one starting from raw notionals V_buy/V_sell, and a cleaner version starting directly from VWAP_buy/VWAP_sell.

2. **Variance Inequality / Information Content** (`variance_inequality` and `variance_strict_inequality`): For f ∈ (0,1) and non-negative variances a, b: f²·a + (1-f)²·b ≤ a + b, with strict inequality whenever at least one variance is positive. This shows the decomposed features (d_buy, d_sell) carry higher total variance than the scalar VWAP - mid.

3. **Asymmetric Pressure Detection** (`pressure_asymmetry_iff`): The pressure asymmetry A = d_buy + d_sell equals zero if and only if d_buy = -d_sell (perfectly symmetric pressure).

4. **Relationship to TFI** (`tfi_eq_two_f_minus_one` and `decomposed_to_aggregate_not_injective`): TFI = 2f - 1, and the map (d_buy, d_sell, f) → (VWAP - mid, TFI) is proved to be non-injective, demonstrating that the decomposed features are strictly more informative than the aggregate quantities.