import Mathlib

/-!
# Buy/Sell VWAP Decomposition and Pressure Asymmetry

Based on Bieganowski & Slepaczuk (2026).

We formalize four claims about the decomposition of VWAP into buy-side and sell-side
components, and the information content of this decomposition.
-/

noncomputable section

open Real

/-! ## Claim 1: VWAP Decomposition

The overall VWAP - mid equals f * d_buy + (1 - f) * d_sell,
where f = Q_buy / (Q_buy + Q_sell) is the buy fraction.
-/

/-
PROBLEM
The overall VWAP is a convex combination of buy and sell VWAPs.
    Given VWAP_buy, VWAP_sell, mid, and the buy fraction f = Q_buy/(Q_buy+Q_sell),
    the deviation VWAP - mid decomposes as f * d_buy + (1-f) * d_sell
    where d_buy = VWAP_buy - mid and d_sell = VWAP_sell - mid.

PROVIDED SOLUTION
Expand all the lets. VWAP - mid = (V_buy + V_sell)/(Q_buy + Q_sell) - mid. Since Q_buy > 0 and Q_sell > 0, Q_buy + Q_sell > 0. Use field_simp to clear denominators, then ring.
-/
theorem vwap_decomposition
    (Q_buy Q_sell V_buy V_sell mid : ℝ)
    (hQ_buy_pos : 0 < Q_buy) (hQ_sell_pos : 0 < Q_sell)
    (_hVWAP_buy : V_buy = Q_buy * (V_buy / Q_buy))
    (_hVWAP_sell : V_sell = Q_sell * (V_sell / Q_sell)) :
    let VWAP := (V_buy + V_sell) / (Q_buy + Q_sell)
    let VWAP_buy := V_buy / Q_buy
    let VWAP_sell := V_sell / Q_sell
    let f := Q_buy / (Q_buy + Q_sell)
    let d_buy := VWAP_buy - mid
    let d_sell := VWAP_sell - mid
    VWAP - mid = f * d_buy + (1 - f) * d_sell := by
  -- Combine like terms and simplify the expression.
  field_simp
  ring_nf at *

/-
PROBLEM
Simplified version: the decomposition identity holds directly from the definitions,
    without needing auxiliary hypotheses about V = Q * VWAP.

PROVIDED SOLUTION
Expand all the lets, use field_simp to clear the denominator Q_buy + Q_sell, then ring.
-/
theorem vwap_decomposition' (VWAP_buy VWAP_sell mid Q_buy Q_sell : ℝ)
    (hQ : Q_buy + Q_sell ≠ 0) :
    let f := Q_buy / (Q_buy + Q_sell)
    let d_buy := VWAP_buy - mid
    let d_sell := VWAP_sell - mid
    let VWAP := (Q_buy * VWAP_buy + Q_sell * VWAP_sell) / (Q_buy + Q_sell)
    VWAP - mid = f * d_buy + (1 - f) * d_sell := by
  grind

/-! ## Claim 2: Variance Inequality (Information Content)

The total variance of the decomposed features (d_buy, d_sell) is at least as large
as the variance of the scalar VWAP - mid. We formalize this as a pure algebraic
inequality: for a, b ≥ 0 (representing Var(d_buy), Var(d_sell)) and f ∈ (0, 1),
  a + b ≥ f² * a + (1-f)² * b
with strict inequality when a > 0 or b > 0.
-/

/-
PROBLEM
For f ∈ (0,1) and a, b ≥ 0, we have a + b ≥ f²·a + (1-f)²·b.
    This shows total variance of the pair (d_buy, d_sell) dominates
    the variance of the weighted combination f·d_buy + (1-f)·d_sell.

PROVIDED SOLUTION
We need f²·a + (1-f)²·b ≤ a + b, equivalently (1-f²)·a + (1-(1-f)²)·b ≥ 0. Factor: (1-f)(1+f)·a + f(2-f)·b ≥ 0. Since f ∈ (0,1), all coefficients are positive, and a,b ≥ 0. Use nlinarith with the hypotheses.
-/
theorem variance_inequality (a b f : ℝ)
    (ha : 0 ≤ a) (hb : 0 ≤ b)
    (hf0 : 0 < f) (hf1 : f < 1) :
    f ^ 2 * a + (1 - f) ^ 2 * b ≤ a + b := by
  nlinarith [ mul_le_mul_of_nonneg_left hf1.le ha, mul_le_mul_of_nonneg_left hf0.le hb ]

/-
PROBLEM
Strict inequality when at least one variance is positive.

PROVIDED SOLUTION
Split on hab. Case a > 0: f²·a < a since f² < 1 (because 0 < f < 1), and (1-f)²·b ≤ b. Case b > 0: similar. Use nlinarith.
-/
theorem variance_strict_inequality (a b f : ℝ)
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hab : 0 < a ∨ 0 < b)
    (hf0 : 0 < f) (hf1 : f < 1) :
    f ^ 2 * a + (1 - f) ^ 2 * b < a + b := by
  cases hab <;> nlinarith [ mul_pos hf0 ( sub_pos_of_lt hf1 ) ]

/-! ## Claim 3: Asymmetric Pressure Detection

The pressure asymmetry A = d_buy + d_sell equals zero if and only if
d_buy = -d_sell (perfectly symmetric pressure).
-/

/-
PROBLEM
A = d_buy + d_sell = 0 if and only if d_buy = -d_sell.

PROVIDED SOLUTION
d_buy + d_sell = 0 ↔ d_buy = -d_sell is just linarith/omega style. constructor; intro h; linarith.
-/
theorem pressure_asymmetry_iff (d_buy d_sell : ℝ) :
    d_buy + d_sell = 0 ↔ d_buy = -d_sell := by
  exact add_eq_zero_iff_eq_neg

/-! ## Claim 4: Relationship to TFI

TFI = 2f - 1, and knowing (d_buy, d_sell, f) determines (VWAP - mid, TFI)
but not vice versa.
-/

/-
PROBLEM
TFI equals 2f - 1 where f = Q_buy / (Q_buy + Q_sell).

PROVIDED SOLUTION
Expand the lets. TFI = (Q_buy - Q_sell)/(Q_buy + Q_sell). f = Q_buy/(Q_buy + Q_sell). So 2f - 1 = (2*Q_buy - (Q_buy+Q_sell))/(Q_buy+Q_sell) = (Q_buy - Q_sell)/(Q_buy+Q_sell). Use field_simp and ring.
-/
theorem tfi_eq_two_f_minus_one (Q_buy Q_sell : ℝ) (hQ : Q_buy + Q_sell ≠ 0) :
    let f := Q_buy / (Q_buy + Q_sell)
    let TFI := (Q_buy - Q_sell) / (Q_buy + Q_sell)
    TFI = 2 * f - 1 := by
  grind

/-- Forward map: (d_buy, d_sell, f) ↦ (VWAP - mid, TFI). -/
def decomposed_to_aggregate (d_buy d_sell f : ℝ) : ℝ × ℝ :=
  (f * d_buy + (1 - f) * d_sell, 2 * f - 1)

/-
PROBLEM
The forward map is not injective: different decomposed triples can yield
    the same (VWAP - mid, TFI). This witnesses that the decomposed features
    carry strictly more information.

PROVIDED SOLUTION
We need two different triples mapping to the same pair. Take x₁ = (1, -1, 0.5) and x₂ = (2, -2, 0.5). Both give decomposed_to_aggregate output (0, 0). So the function is not injective. Use intro h, apply absurd (h ...), norm_num or similar. Unfold decomposed_to_aggregate and Function.Injective.
-/
theorem decomposed_to_aggregate_not_injective :
    ¬ Function.Injective (fun x : ℝ × ℝ × ℝ =>
      decomposed_to_aggregate x.1 x.2.1 x.2.2) := by
  norm_num [ Function.Injective, decomposed_to_aggregate ];
  use 0;
  use 1;
  exact ⟨ 1, 0, 0, 1, by norm_num ⟩

end