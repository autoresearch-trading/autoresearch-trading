/-
# Parts C & D: Gaussian VaR/CVaR Formulas and Portfolio Diversification

## Part C: Gaussian Bounds

Under normality R ~ N(μ, σ²):
- VaR_α = -(μ + σ · Φ⁻¹(α))
- CVaR_α = -(μ - σ · φ(Φ⁻¹(α)) / α)

where Φ⁻¹ is the standard normal inverse CDF and φ is the standard normal PDF.

## Part D: Portfolio CVaR Diversification

For an equal-weighted portfolio of N independent assets with returns Rⱼ ~ N(μⱼ, σⱼ²):
- μ_P = (1/N) · Σ μⱼ
- σ_P = (1/N) · √(Σ σⱼ²)
- CVaR_α(portfolio) = -(μ_P - σ_P · φ(Φ⁻¹(α)) / α)

When all assets are identical (μⱼ = μ₀, σⱼ = σ₀):
- σ_P = σ₀ / √N
- Portfolio CVaR decreases as 1/√N
-/
import Mathlib

open Real BigOperators Finset

noncomputable section

/-! ## Part C: Gaussian VaR and CVaR -/

/-- Standard normal PDF: φ(x) = (1/√(2π)) · exp(-x²/2) -/
def stdNormalPDF (x : ℝ) : ℝ := (1 / Real.sqrt (2 * Real.pi)) * Real.exp (-(x ^ 2) / 2)

/-
PROBLEM
Standard normal PDF is always positive

PROVIDED SOLUTION
stdNormalPDF x = (1/sqrt(2π)) * exp(-x²/2). Both factors are positive: 1/sqrt(2π) > 0 since sqrt(2π) > 0, and exp is always positive. Use mul_pos, div_pos, Real.sqrt_pos, Real.exp_pos.
-/
theorem stdNormalPDF_pos (x : ℝ) : stdNormalPDF x > 0 := by
  exact mul_pos ( by positivity ) ( Real.exp_pos _ )

/-- Gaussian VaR at level α for R ~ N(μ, σ²).
    VaR_α = -(μ + σ · Φ⁻¹(α)) where Φ⁻¹(α) is the standard normal inverse CDF value. -/
def gaussianVaR (μ σ : ℝ) (Φinv_α : ℝ) : ℝ := -(μ + σ * Φinv_α)

/-- Gaussian CVaR at level α for R ~ N(μ, σ²).
    CVaR_α = -(μ - σ · φ(Φ⁻¹(α)) / α) -/
def gaussianCVaR (μ σ : ℝ) (Φinv_α : ℝ) (α : ℝ) : ℝ :=
  -(μ - σ * stdNormalPDF Φinv_α / α)

/-
PROBLEM
CVaR - VaR = σ · (φ(Φ⁻¹(α))/α + Φ⁻¹(α)).
    This is the "excess" of CVaR over VaR, which is positive when
    φ(Φ⁻¹(α))/α > -Φ⁻¹(α), a standard property of the normal distribution.

PROVIDED SOLUTION
Unfold gaussianCVaR and gaussianVaR. Direct algebraic computation: -(μ - σ·φ/α) - (-(μ + σ·z)) = -(μ - σ·φ/α) + μ + σ·z = σ·φ/α + σ·z = σ·(φ/α + z). Use ring.
-/
theorem gaussian_cvar_minus_var (μ σ Φinv_α α : ℝ) :
    gaussianCVaR μ σ Φinv_α α - gaussianVaR μ σ Φinv_α =
    σ * (stdNormalPDF Φinv_α / α + Φinv_α) := by
  unfold gaussianCVaR gaussianVaR ; ring

/-
PROBLEM
CVaR ≥ VaR for Gaussian distributions when σ > 0 and 0 < α < 1.
    Uses the Mills' ratio property: φ(z)/α > -z when z = Φ⁻¹(α) < 0.

PROVIDED SOLUTION
Use gaussian_cvar_minus_var to rewrite CVaR - VaR = σ * (φ/α + z). Since σ > 0, φ/α > -z (hMills), we have φ/α + z > 0, so σ * (φ/α + z) > 0, hence CVaR - VaR > 0, i.e., CVaR ≥ VaR. Use sub_nonneg and mul_pos.
-/
theorem gaussian_cvar_ge_var (μ σ : ℝ) (hσ : σ > 0) (Φinv_α α : ℝ)
    (hα : α > 0) (hΦ : Φinv_α < 0)
    (hMills : stdNormalPDF Φinv_α / α > -Φinv_α) :
    gaussianCVaR μ σ Φinv_α α ≥ gaussianVaR μ σ Φinv_α := by
  exact le_of_sub_nonneg ( by rw [ gaussian_cvar_minus_var ] ; nlinarith )

/-! ## Part C: Numerical Verification

With α = 0.05, μ = 0.0001, σ = 0.002, Φ⁻¹(0.05) ≈ -1.6449:
- VaR₀.₀₅ = -(0.0001 + 0.002 × (-1.6449)) = 0.0031898
- φ(-1.6449) ≈ 0.10313 (standard normal PDF value)
- CVaR₀.₀₅ = -(0.0001 - 0.002 × φ(-1.6449) / 0.05)
- CVaR > VaR since φ(-1.6449)/0.05 > 1.6449

The exact VaR value with these parameters:
-/

/-
PROBLEM
VaR with μ = 1/10000, σ = 1/500, Φ⁻¹(0.05) = -16449/10000
    equals 15949/5000000 ≈ 0.0031898

PROVIDED SOLUTION
Unfold gaussianVaR. Then ring or norm_num.
-/
theorem numerical_var_exact :
    gaussianVaR (1/10000 : ℝ) (1/500) (-16449/10000) = 15949 / 5000000 := by
  unfold gaussianVaR; norm_num;

/-
PROBLEM
CVaR > VaR follows from Mills' ratio: φ(z)/α + z > 0 for z < 0, α > 0 small.
    For the specific numerical values, this reduces to verifying
    stdNormalPDF(-1.6449) / 0.05 > 1.6449.

PROVIDED SOLUTION
Unfold gaussianCVaR and gaussianVaR. The inequality CVaR > VaR is equivalent to CVaR - VaR > 0, which by gaussian_cvar_minus_var equals σ * (φ/α + z) > 0. With σ = 1/500 > 0, this reduces to φ/α + z > 0, i.e., (1/500) * (φ/(1/20) + (-16449/10000)) > 0.
-/
theorem numerical_cvar_gt_var_iff :
    gaussianCVaR (1/10000 : ℝ) (1/500) (-16449/10000) (1/20) >
    gaussianVaR (1/10000 : ℝ) (1/500) (-16449/10000) ↔
    (1/500 : ℝ) * (stdNormalPDF (-16449/10000) / (1/20) + (-16449/10000)) > 0 := by
  unfold gaussianCVaR gaussianVaR ; ring ; norm_num;

/-! ## Part D: Portfolio CVaR and Diversification -/

/-- Portfolio mean return for equal-weighted portfolio of N assets -/
def portfolioMean {N : ℕ} (μ : Fin N → ℝ) : ℝ := (∑ j, μ j) / N

/-- Portfolio volatility for equal-weighted portfolio of N independent assets -/
def portfolioVol {N : ℕ} (σ_ : Fin N → ℝ) : ℝ :=
  Real.sqrt (∑ j, (σ_ j) ^ 2) / N

/-- Portfolio Gaussian CVaR -/
def portfolioCVaR {N : ℕ} (μ σ_ : Fin N → ℝ) (Φinv_α α : ℝ) : ℝ :=
  gaussianCVaR (portfolioMean μ) (portfolioVol σ_) Φinv_α α

/-! ### Diversification Result -/

/-
PROBLEM
For N identical independent assets with volatility σ₀ ≥ 0, the portfolio volatility
    equals σ₀ / √N.

PROVIDED SOLUTION
Unfold portfolioVol. The sum ∑ j, σ₀² = N * σ₀². So sqrt(N * σ₀²) / N = sqrt(N) * |σ₀| / N = |σ₀| / sqrt(N). Since σ₀ ≥ 0, |σ₀| = σ₀. And σ₀ / sqrt(N) = σ₀ / sqrt(N). Use Finset.sum_const, Real.sqrt_mul, abs_of_nonneg.
-/
theorem portfolio_vol_identical {N : ℕ} (hN : 0 < N) (σ₀ : ℝ) (hσ₀ : σ₀ ≥ 0) :
    portfolioVol (fun _ : Fin N => σ₀) = σ₀ / Real.sqrt N := by
  unfold portfolioVol;
  norm_num [ hN.ne', hσ₀ ];
  grind +ring

/-
PROBLEM
Diversification reduces volatility: σ₀/√(N+1) < σ₀/√N for σ₀ > 0 and N ≥ 1.

PROVIDED SOLUTION
We need σ₀/sqrt(N+1) < σ₀/sqrt(N). Since σ₀ > 0, this is equivalent to sqrt(N) < sqrt(N+1), which follows from N < N+1. Use div_lt_div_left with sqrt_lt_sqrt.
-/
theorem diversification_reduces_vol (σ₀ : ℝ) (hσ₀ : σ₀ > 0) (N : ℕ) (hN : 0 < N) :
    σ₀ / Real.sqrt (↑(N + 1)) < σ₀ / Real.sqrt (↑N) := by
  gcongr ; aesop

/-
PROBLEM
Portfolio volatility component σ₀/√N → 0 as N → ∞, showing O(1/√N) decay.

PROVIDED SOLUTION
σ₀/sqrt(N) = σ₀ * (1/sqrt(N)). As N → ∞, sqrt(N) → ∞, so 1/sqrt(N) → 0, hence σ₀/sqrt(N) → 0. Use Filter.Tendsto.const_mul (or mul_comm and tendsto_const_smul) with the fact that 1/sqrt(N) → 0. For the latter, use tendsto_one_div_atTop_atTop composed with sqrt tending to infinity, or use a direct Mathlib lemma about sqrt(N) → ∞.
-/
theorem portfolio_vol_tendsto_zero (σ₀ : ℝ) :
    Filter.Tendsto (fun N : ℕ => σ₀ / Real.sqrt (↑N)) Filter.atTop (nhds 0) := by
  simpa using tendsto_const_nhds.mul ( tendsto_inv_atTop_nhds_zero_nat.sqrt )

end