/-
# Part A: VaR-CVaR Ordering

We prove that CVaR ≥ VaR for discrete (sorted) samples.

For a sorted sample a₀ ≤ a₁ ≤ ... ≤ aₙ₋₁ of returns, with tail parameter k (= ⌊α·n⌋):
- VaR = -aₖ₋₁ (negative of the k-th smallest return)
- CVaR = -(a₀ + ... + aₖ₋₁)/k (negative of the average of the k smallest returns)

The key inequality CVaR ≥ VaR follows from: average of k smallest ≤ k-th smallest,
because each of the k smallest values is ≤ the k-th one (by monotonicity/sorting).
-/
import Mathlib

open Finset BigOperators

noncomputable section

/-! ## Definitions -/

/-- Discrete VaR for a sorted return sequence: negative of the (k-1)-th value (0-indexed).
    Here `a` is sorted ascending (monotone) and k = ⌊α·n⌋. -/
def discreteVaR {n : ℕ} (a : Fin n → ℝ) (k : ℕ) (hk : 0 < k) (hkn : k ≤ n) : ℝ :=
  -a ⟨k - 1, by omega⟩

/-- Discrete CVaR (Expected Shortfall) for a sorted return sequence:
    negative of the average of the k smallest values. -/
def discreteCVaR {n : ℕ} (a : Fin n → ℝ) (k : ℕ) (hk : 0 < k) (hkn : k ≤ n) : ℝ :=
  -(∑ i : Fin k, a ⟨i.val, by omega⟩) / k

/-! ## Key Inequality: Sum of monotone sequence ≤ card times last element -/

/-
PROBLEM
For a monotone function a on Fin k, the sum of all values is at most k times the last value.
    This is the core inequality behind CVaR ≥ VaR.

PROVIDED SOLUTION
Each a i ≤ a ⟨k-1, _⟩ by monotonicity (since i.val ≤ k-1). So the sum ≤ k * a ⟨k-1, _⟩. Use Finset.sum_le_sum to bound each term, then simplify using Finset.sum_const and nsmul_eq_mul.
-/
theorem sum_le_card_mul_last {k : ℕ} (hk : 0 < k) (a : Fin k → ℝ)
    (hmono : Monotone a) :
    ∑ i : Fin k, a i ≤ k * a ⟨k - 1, by omega⟩ := by
  simpa using Finset.sum_le_sum fun i ( hi : i ∈ Finset.univ ) => hmono <| show i ≤ ⟨ k - 1, Nat.sub_lt hk zero_lt_one ⟩ from Nat.le_pred_of_lt <| Fin.is_lt i

/-! ## CVaR ≥ VaR -/

/-
PROBLEM
CVaR is at least as severe as VaR: the average tail loss is at least the quantile loss.
    This follows because the average of values ≤ aₖ₋₁ cannot exceed aₖ₋₁.

PROVIDED SOLUTION
Unfold discreteCVaR and discreteVaR. We need -(sum/k) ≥ -a[k-1], i.e., a[k-1] ≥ sum/k. This follows from sum_le_card_mul_last applied to the restriction of a to Fin k (which is monotone since a is). Divide both sides by k > 0.
-/
theorem cvar_ge_var {n : ℕ} (a : Fin n → ℝ) (k : ℕ) (hk : 0 < k) (hkn : k ≤ n)
    (hmono : Monotone a) :
    discreteCVaR a k hk hkn ≥ discreteVaR a k hk hkn := by
  -- By definition of discreteCVaR and discreteVaR, we need to show that -(∑ i : Fin k, a (i.val)) / k ≥ -a (k - 1).
  suffices h_suff : -(∑ i : Fin k, a ⟨i.val, by omega⟩) / k ≥ -a ⟨k - 1, by omega⟩ by
    exact h_suff;
  rw [ ge_iff_le, le_div_iff₀ ] <;> norm_num [ hk ];
  simpa [ mul_comm ] using sum_le_card_mul_last hk ( fun i : Fin k => a ⟨ i.val, by linarith [ Fin.is_lt i ] ⟩ ) ( fun i j hij => hmono hij )

/-! ## Equality condition: CVaR = VaR iff the tail is degenerate -/

/-
PROBLEM
CVaR = VaR if and only if all k tail values are equal (degenerate tail).
    This captures the statement that for any continuous distribution with full support,
    CVaR > VaR strictly.

PROVIDED SOLUTION
Unfold definitions. CVaR = VaR iff -(sum/k) = -a[k-1] iff sum/k = a[k-1] iff sum = k * a[k-1]. Since a is monotone, each a[i] ≤ a[k-1]. Sum = k * a[k-1] iff every a[i] = a[k-1]. Forward: if sum = k * last, then since each term ≤ last and sum = k * last, each must equal last. Backward: if all equal, sum = k * last trivially. Use div_left_inj or similar, and the fact that if sum of terms ≤ M equals n*M then each term = M.
-/
theorem cvar_eq_var_iff {n : ℕ} (a : Fin n → ℝ) (k : ℕ) (hk : 0 < k) (hkn : k ≤ n)
    (hmono : Monotone a) :
    discreteCVaR a k hk hkn = discreteVaR a k hk hkn ↔
    ∀ i : Fin k, a ⟨i.val, by omega⟩ = a ⟨k - 1, by omega⟩ := by
  constructor <;> intro h;
  · intro i; rw [ eq_comm ] ; rw [ @discreteCVaR ] at h; rw [ @discreteVaR ] at h; simp_all +decide [ div_eq_mul_inv ] ;
    contrapose! h;
    -- Since $a$ is monotone, we have $a ⟨i, _⟩ < a ⟨k - 1, _⟩$.
    have h_lt : a ⟨i, by linarith [Fin.is_lt i]⟩ < a ⟨k - 1, by omega⟩ := by
      exact lt_of_le_of_ne ( hmono ( Nat.le_sub_one_of_lt i.2 ) ) h.symm;
    rw [ ← div_eq_mul_inv, Ne.eq_def, div_eq_iff ] <;> try positivity;
    exact ne_of_lt <| lt_of_lt_of_le ( Finset.sum_lt_sum ( fun x _ => hmono <| Fin.le_iff_val_le_val.mpr <| Nat.le_sub_one_of_lt <| Fin.is_lt x ) <| ⟨ i, Finset.mem_univ _, h_lt ⟩ ) <| by norm_num; linarith;
  · unfold discreteCVaR discreteVaR;
    rw [ Finset.sum_congr rfl fun i hi => h i, Finset.sum_const, Finset.card_fin, nsmul_eq_mul, div_eq_iff ] <;> first | positivity | ring;

end