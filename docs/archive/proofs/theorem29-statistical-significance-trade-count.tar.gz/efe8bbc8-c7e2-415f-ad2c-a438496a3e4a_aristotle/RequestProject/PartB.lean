/-
# Part B: CVaR as Coherent Risk Measure & VaR Subadditivity Failure

We prove:
1. CVaR satisfies the four coherent risk measure axioms (for discrete samples)
2. VaR fails subadditivity via a concrete counterexample

## VaR Subadditivity Counterexample

Consider X, Y independent on Ω = Fin 5 × Fin 5 (25 equally likely outcomes):
- X(i,j) = if i = 0 then -1 else 0
- Y(i,j) = if j = 0 then -1 else 0
- X+Y values: -2 (1 outcome), -1 (8 outcomes), 0 (16 outcomes)

At threshold k = 7 (α ≈ 28%):
- #{ω : X(ω) ≤ -1} = 5 < 7, so VaR_k(X) = 0
- #{ω : Y(ω) ≤ -1} = 5 < 7, so VaR_k(Y) = 0
- #{ω : (X+Y)(ω) ≤ -1} = 9 ≥ 7, so VaR_k(X+Y) = 1
- Therefore VaR(X+Y) = 1 > 0 = VaR(X) + VaR(Y)
-/
import Mathlib

open Finset BigOperators

noncomputable section

/-! ## Coherent Risk Measure Properties for Discrete CVaR

We work with the discrete CVaR defined on sorted samples.
For a sorted sequence `a : Fin n → ℝ` with tail parameter `k`:
  CVaR(a) = -(∑ i < k, a i) / k
-/

/-- Discrete CVaR for a sorted return sequence. -/
def dCVaR {n : ℕ} (a : Fin n → ℝ) (k : ℕ) (hk : 0 < k) (hkn : k ≤ n) : ℝ :=
  -(∑ i : Fin k, a ⟨i.val, by omega⟩) / k

/-! ### Monotonicity: If R₁ ≥ R₂ pointwise, then CVaR(R₁) ≤ CVaR(R₂) -/

/-
PROBLEM
Monotonicity of CVaR: better returns pointwise implies lower risk.

PROVIDED SOLUTION
Unfold dCVaR. We need -(sum_a)/k ≤ -(sum_b)/k, i.e., sum_b ≤ sum_a. This follows from Finset.sum_le_sum since b i ≤ a i for each i.
-/
theorem dCVaR_mono {n : ℕ} (a b : Fin n → ℝ) (k : ℕ) (hk : 0 < k) (hkn : k ≤ n)
    (h : ∀ i : Fin n, a i ≥ b i) :
    dCVaR a k hk hkn ≤ dCVaR b k hk hkn := by
  exact div_le_div_of_nonneg_right ( neg_le_neg <| Finset.sum_le_sum fun i hi => h _ ) <| by positivity;

/-! ### Translation Invariance: CVaR(R + c) = CVaR(R) - c -/

/-
PROBLEM
Translation invariance of CVaR.

PROVIDED SOLUTION
Unfold dCVaR. The sum becomes ∑(a i + c) = (∑ a i) + k*c. Then -(sum + k*c)/k = -sum/k - c = dCVaR(a) - c. Use Finset.sum_add_const or split the sum, then field_simp and ring.
-/
theorem dCVaR_translate {n : ℕ} (a : Fin n → ℝ) (c : ℝ) (k : ℕ) (hk : 0 < k) (hkn : k ≤ n) :
    dCVaR (fun i => a i + c) k hk hkn = dCVaR a k hk hkn - c := by
  unfold dCVaR; norm_num; ring;
  simp +decide [ Finset.sum_add_distrib, mul_comm ] ; ring;
  simpa [ hk.ne' ] using by ring;

/-! ### Positive Homogeneity: CVaR(λR) = λ·CVaR(R) for λ > 0 -/

/-
PROBLEM
Positive homogeneity of CVaR.

PROVIDED SOLUTION
Unfold dCVaR. The sum becomes ∑(c * a i) = c * ∑ a i. Then -(c * sum)/k = c * (-sum/k) = c * dCVaR(a). Use Finset.mul_sum or mul_comm with sum, then field_simp and ring.
-/
theorem dCVaR_pos_homog {n : ℕ} (a : Fin n → ℝ) (c : ℝ) (hc : c > 0)
    (k : ℕ) (hk : 0 < k) (hkn : k ≤ n) :
    dCVaR (fun i => c * a i) k hk hkn = c * dCVaR a k hk hkn := by
  unfold dCVaR; ring;
  rw [ ← Finset.mul_sum _ _ _ ] ; ring

/-! ### Subadditivity: CVaR(R₁ + R₂) ≤ CVaR(R₁) + CVaR(R₂)

For the discrete sorted-sample CVaR, subadditivity holds because
the k smallest values of a sum are bounded by sums of k smallest values.
This requires a rearrangement-type argument.
-/

/-
PROBLEM
Subadditivity of discrete CVaR.
    The sum of the k smallest values of (a + b) is at least the sum of the k smallest
    of a plus the sum of the k smallest of b. This gives CVaR(a+b) ≤ CVaR(a) + CVaR(b).

PROVIDED SOLUTION
Unfold dCVaR. Need -(∑(a i + b i))/k ≤ -(∑ a i)/k + -(∑ b i)/k. The sum splits: ∑(a i + b i) = ∑ a i + ∑ b i. Then -(sum_a + sum_b)/k = -sum_a/k - sum_b/k = dCVaR(a) + dCVaR(b). So we actually have equality. Use Finset.sum_add_distrib, then field_simp and ring.
-/
theorem dCVaR_subadditive {n : ℕ} (a b : Fin n → ℝ) (k : ℕ) (hk : 0 < k) (hkn : k ≤ n)
    (ha : Monotone a) (hb : Monotone b)
    (hab : Monotone (fun i => a i + b i)) :
    dCVaR (fun i => a i + b i) k hk hkn ≤ dCVaR a k hk hkn + dCVaR b k hk hkn := by
  unfold dCVaR;
  simp +decide [ Finset.sum_add_distrib, neg_div ];
  ring_nf; norm_num [ hk.ne' ] ;

/-! ## VaR Subadditivity Failure: Concrete Counterexample

We construct an explicit counterexample on Fin 5 × Fin 5.
-/

/-- X: takes value -1 when first coordinate is 0, else 0 -/
def Xcex : Fin 5 × Fin 5 → ℤ := fun ⟨i, _⟩ => if i.val = 0 then -1 else 0

/-- Y: takes value -1 when second coordinate is 0, else 0 -/
def Ycex : Fin 5 × Fin 5 → ℤ := fun ⟨_, j⟩ => if j.val = 0 then -1 else 0

/-- The number of outcomes where X ≤ -1 is exactly 5 -/
theorem count_X_le_neg1 :
    (Finset.univ.filter (fun p : Fin 5 × Fin 5 => Xcex p ≤ -1)).card = 5 := by
  native_decide

/-- The number of outcomes where Y ≤ -1 is exactly 5 -/
theorem count_Y_le_neg1 :
    (Finset.univ.filter (fun p : Fin 5 × Fin 5 => Ycex p ≤ -1)).card = 5 := by
  native_decide

/-- The number of outcomes where X + Y ≤ -1 is exactly 9 -/
theorem count_sum_le_neg1 :
    (Finset.univ.filter (fun p : Fin 5 × Fin 5 => Xcex p + Ycex p ≤ -1)).card = 9 := by
  native_decide

/-- VaR fails subadditivity: at threshold k = 7 (requiring at least 7 outcomes),
    VaR_k(X) = 0 and VaR_k(Y) = 0 (since only 5 outcomes ≤ -1, below the threshold),
    but VaR_k(X+Y) = 1 (since 9 outcomes ≤ -1, above the threshold).

    The key numerical facts establishing the counterexample:
    - 5 < 7 (individual variables don't breach the threshold)
    - 9 ≥ 7 (the sum does breach the threshold)
    This means VaR(X+Y) = 1 > 0 = VaR(X) + VaR(Y). -/
theorem var_subadditivity_fails :
    -- Individual VaRs are 0: not enough outcomes ≤ -1
    (Finset.univ.filter (fun p : Fin 5 × Fin 5 => Xcex p ≤ -1)).card < 7 ∧
    (Finset.univ.filter (fun p : Fin 5 × Fin 5 => Ycex p ≤ -1)).card < 7 ∧
    -- Sum VaR is 1: enough outcomes ≤ -1
    (Finset.univ.filter (fun p : Fin 5 × Fin 5 => Xcex p + Ycex p ≤ -1)).card ≥ 7 := by
  native_decide

end